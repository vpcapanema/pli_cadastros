# 🚀 PLI Login System - Instalador Universal

## Como usar o instalador

### 📋 Opções de Instalação

Você tem **3 formas** de instalar o PLI Login System:

#### 1️⃣ **Windows (Recomendado)**
```batch
# Execute o arquivo batch
INSTALAR.bat
```

#### 2️⃣ **Linux/Mac (Script Bash)**
```bash
# Torne executável e execute
chmod +x instalar.sh
./instalar.sh
```

#### 3️⃣ **Multiplataforma (Python)**
```bash
# Execute com Python 3
python3 instalar.py

# Ou no Windows
python instalar.py
```

---

## 🔧 Requisitos do Sistema

### ✅ **Obrigatórios:**
- **Node.js** v14+ ([Download](https://nodejs.org))
- **npm** v6+ (incluído com Node.js)
- **PostgreSQL** 10+ ([Download](https://postgresql.org))

### ✅ **Opcionais:**
- **Python 3.7+** (para instalador Python)
- **Git** (para versionamento)

---

## 📦 O que será instalado

```
📁 pli-login-system/
├── 🚀 server.js                 # Servidor Express principal
├── 📋 package.json             # Dependências npm
├── ⚙️  .env.example             # Configurações
├── 📂 assets/                  # Sistema PLI completo
├── 🔧 backend/                 # API de autenticação
├── 🗄️  database/               # Scripts SQL
├── 📚 docs/                    # Documentação
├── 🎯 examples/                # Exemplos
├── 🛠️  scripts/                # Utilitários
├── 📝 logs/                    # Logs do sistema
└── 🌐 public/                  # Arquivos estáticos
```

### 🔗 **Atalhos Criados:**

**Windows:**
- `Iniciar PLI Login.bat` - Inicia o servidor
- `Configurar Banco.bat` - Configura PostgreSQL

**Linux/Mac:**
- `iniciar-pli-login.sh` - Inicia o servidor  
- `configurar-banco.sh` - Configura PostgreSQL

---

## ⚡ Instalação Rápida (5 minutos)

### **Passo 1: Execute o Instalador**
```bash
# Windows
INSTALAR.bat

# Linux/Mac
./instalar.sh

# Python (qualquer SO)
python3 instalar.py
```

### **Passo 2: Configure o Banco**
Edite o arquivo `.env` criado:
```env
DB_HOST=localhost
DB_NAME=pli_db
DB_USER=postgres
DB_PASSWORD=SUA_SENHA_AQUI
```

### **Passo 3: Configure o PostgreSQL**
```bash
# Windows
"Configurar Banco.bat"

# Linux/Mac
./configurar-banco.sh
```

### **Passo 4: Inicie o Sistema**
```bash
# Windows  
"Iniciar PLI Login.bat"

# Linux/Mac
./iniciar-pli-login.sh
```

### **Passo 5: Acesse o Sistema**
- **URL:** http://localhost:3000
- **Login:** admin
- **Senha:** admin123

🎉 **Pronto! Sistema funcionando!**

---

## 🔐 Primeira Configuração

### **1. Alterar Senha Padrão**
Acesse http://localhost:3000 e altere a senha do admin.

### **2. Configurar Usuários**
Crie usuários dos 5 tipos disponíveis:
- **ADMIN** - Administrador total
- **GESTOR** - Gerente de equipe  
- **ANALISTA** - Analista de dados
- **OPERADOR** - Operador do sistema
- **VISUALIZADOR** - Apenas visualização

### **3. Configurar Domínio (Produção)**
No arquivo `.env`:
```env
CORS_ORIGINS=https://seudominio.com
NODE_ENV=production
```

---

## 🛠️ Scripts Disponíveis

```bash
# Iniciar servidor
npm start

# Configurar banco de dados  
npm run setup-db

# Testar sistema
npm test

# Modo desenvolvimento
npm run dev
```

---

## 🔍 Verificar Instalação

### **Teste Rápido:**
```bash
curl http://localhost:3000/api/status
```

**Resposta esperada:**
```json
{
  "sistema": "PLI Login System",
  "versao": "1.0.0",
  "status": "ativo"
}
```

### **Logs do Sistema:**
```bash
# Ver logs em tempo real
tail -f logs/pli-login.log

# Windows
type logs\pli-login.log
```

---

## 🚨 Resolução de Problemas

### **❌ "Node.js não encontrado"**
```bash
# Instale Node.js
https://nodejs.org
```

### **❌ "Erro de conexão com banco"**
1. Verifique se PostgreSQL está rodando
2. Confira credenciais no `.env`
3. Teste conexão manual

### **❌ "Porta 3000 em uso"**
Altere no `.env`:
```env
PORT=3001
```

### **❌ "npm install falhou"**
```bash
# Limpe cache e tente novamente
npm cache clean --force
rm -rf node_modules
npm install
```

### **❌ "Permissão negada (Linux/Mac)"**
```bash
# Dê permissão aos scripts
chmod +x *.sh
```

---

## 📋 Checklist Pré-Instalação

- [ ] Node.js v14+ instalado
- [ ] PostgreSQL rodando
- [ ] Porta 3000 disponível
- [ ] Acesso de escrita no diretório
- [ ] npm funcionando

---

## 🎯 Integração Rápida

### **Frontend Simples:**
```html
<script src="http://localhost:3000/assets/pli-login-system.js"></script>
<script>
const pli = new PLILoginInstaller();
pli.install({
    baseUrl: 'http://localhost:3000',
    autoProtect: true
});
</script>
```

### **Backend Express:**
```javascript
const { setupAuthRoutes } = require('./backend/authRoutes');
setupAuthRoutes(app, dbConfig);
```

---

## 📞 Suporte

### **Documentação Completa:**
- `README.md` - Guia principal
- `docs/API.md` - Referência da API
- `docs/INTEGRATION.md` - Guia de integração

### **Exemplos:**
- `examples/express-integration.js` - Servidor completo
- `examples/protected-page.html` - Página protegida
- `examples/custom-styles.css` - Personalização

### **Logs e Debug:**
- `logs/pli-login.log` - Log do sistema
- Console do navegador (F12)
- Network tab para APIs

---

## ✅ Sistema Pronto!

Após seguir estes passos, você terá:

🔐 **Sistema de login completo**
🛡️ **Proteção de páginas automática**  
🎯 **API REST funcional**
📊 **Dashboard administrativo**
🔄 **Controle de sessões**
📝 **Logs de auditoria**
🚀 **Pronto para produção**

**PLI Login System v1.0.0** - Instalação Universal Completa
