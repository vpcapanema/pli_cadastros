#!/bin/bash
# PLI Login System - Empacotador Linux/Mac

echo "==============================================="
echo "   PLI LOGIN SYSTEM - CRIANDO PACOTE FINAL"
echo "==============================================="
echo

echo "[INFO] Criando pacote distribuível..."

# Definir nome do arquivo
PACKAGE_NAME="PLI-Login-System-v1.0.0"

# Lista de arquivos/diretórios para incluir
FILES_TO_PACKAGE=(
    "INSTALAR.bat"
    "instalar.sh" 
    "instalar.py"
    "COMO_USAR.md"
    "README.md"
    "package.json"
    "assets/"
    "backend/"
    "database/"
    "docs/"
    "examples/"
    "scripts/"
)

# Verificar se tar está disponível
if command -v tar &> /dev/null; then
    echo "[INFO] Usando tar para compressão..."
    tar -czf "${PACKAGE_NAME}.tar.gz" "${FILES_TO_PACKAGE[@]}" 2>/dev/null
    
    if [ $? -eq 0 ]; then
        echo "[SUCESSO] Pacote criado: ${PACKAGE_NAME}.tar.gz"
        CREATED_FILE="${PACKAGE_NAME}.tar.gz"
    else
        echo "[ERRO] Falha na criação com tar"
        exit 1
    fi
    
# Verificar se zip está disponível como alternativa
elif command -v zip &> /dev/null; then
    echo "[INFO] Usando zip para compressão..."
    zip -r "${PACKAGE_NAME}.zip" "${FILES_TO_PACKAGE[@]}" > /dev/null
    
    if [ $? -eq 0 ]; then
        echo "[SUCESSO] Pacote criado: ${PACKAGE_NAME}.zip"
        CREATED_FILE="${PACKAGE_NAME}.zip"
    else
        echo "[ERRO] Falha na criação com zip"
        exit 1
    fi
else
    echo "[ERRO] Nenhuma ferramenta de compressão encontrada (tar ou zip)"
    exit 1
fi

# Obter tamanho do arquivo
if command -v du &> /dev/null; then
    FILE_SIZE=$(du -h "$CREATED_FILE" | cut -f1)
else
    FILE_SIZE="N/A"
fi

echo
echo "==============================================="
echo "[SUCESSO] PACOTE DISTRIBUÍVEL CRIADO!"
echo "==============================================="
echo
echo "O PLI Login System foi empacotado e está pronto"
echo "para distribuição!"
echo
echo "ARQUIVO CRIADO:"
echo "  📦 $CREATED_FILE ($FILE_SIZE)"
echo
echo "CONTEÚDO DO PACOTE:"
echo "  🔧 INSTALAR.bat (Instalador Windows)"
echo "  🐧 instalar.sh (Instalador Linux/Mac)"
echo "  🐍 instalar.py (Instalador Python universal)"
echo "  🚀 Sistema PLI Login completo"
echo "  📚 Documentação completa"
echo "  🎯 Exemplos de integração"
echo
echo "INSTRUÇÕES DE USO:"
echo "1. Extraia o arquivo em qualquer diretório"
echo "2. Execute INSTALAR.bat (Windows) ou instalar.sh (Linux/Mac)"
echo "3. Siga as instruções na tela"
echo
echo "REQUISITOS PARA O USUÁRIO FINAL:"
echo "  ✅ Node.js v14+"
echo "  ✅ PostgreSQL 10+"
echo "  ✅ npm v6+"
echo

# Verificar integridade do arquivo (se possível)
if command -v md5sum &> /dev/null; then
    CHECKSUM=$(md5sum "$CREATED_FILE" | cut -d' ' -f1)
    echo "🔐 CHECKSUM MD5: $CHECKSUM"
elif command -v md5 &> /dev/null; then
    CHECKSUM=$(md5 -q "$CREATED_FILE")
    echo "🔐 CHECKSUM MD5: $CHECKSUM"
fi

echo
echo "✅ Pacote pronto para distribuição!"
