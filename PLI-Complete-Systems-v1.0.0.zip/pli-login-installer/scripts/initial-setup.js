/**
 * PLI Login System - Script de Configuração Inicial
 * Configura o sistema após a instalação
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

console.log('🔧 PLI Login System - Configuração Inicial');
console.log('==========================================\n');

async function setupSystem() {
    try {
        // 1. Verificar estrutura de diretórios
        console.log('📁 Verificando estrutura de diretórios...');
        ensureDirectories();
        
        // 2. Configurar variáveis de ambiente
        console.log('⚙️  Configurando variáveis de ambiente...');
        setupEnvironment();
        
        // 3. Criar servidor principal
        console.log('🚀 Criando servidor principal...');
        createMainServer();
        
        // 4. Criar scripts utilitários
        console.log('🛠️  Criando scripts utilitários...');
        createUtilityScripts();
        
        // 5. Configurar logs
        console.log('📝 Configurando sistema de logs...');
        setupLogging();
        
        console.log('\n✅ Configuração inicial concluída com sucesso!');
        console.log('\n📋 Próximos passos:');
        console.log('1. Configure o arquivo .env com suas credenciais');
        console.log('2. Execute npm run setup-db para configurar o banco');
        console.log('3. Execute npm start para iniciar o servidor');
        
    } catch (error) {
        console.error('❌ Erro na configuração:', error.message);
        process.exit(1);
    }
}

function ensureDirectories() {
    const dirs = [
        'logs',
        'public',
        'public/css',
        'public/js',
        'public/images',
        'temp'
    ];
    
    dirs.forEach(dir => {
        const fullPath = path.join(process.cwd(), dir);
        if (!fs.existsSync(fullPath)) {
            fs.mkdirSync(fullPath, { recursive: true });
            console.log(`   ✓ Criado: ${dir}`);
        }
    });
}

function setupEnvironment() {
    const envFile = path.join(process.cwd(), '.env');
    
    if (!fs.existsSync(envFile)) {
        // Gerar chave JWT secreta
        const jwtSecret = crypto.randomBytes(64).toString('hex');
        
        const envContent = `# PLI Login System - Configuração
# Configure estas variáveis antes de executar

# Banco de Dados
DB_HOST=localhost
DB_PORT=5432
DB_NAME=pli_db
DB_USER=postgres
DB_PASSWORD=sua_senha_aqui

# JWT
JWT_SECRET=${jwtSecret}
JWT_EXPIRES_IN=8h

# Servidor
PORT=3000
NODE_ENV=development

# Segurança
BCRYPT_ROUNDS=12
SESSION_MAX_AGE=28800000
MAX_LOGIN_ATTEMPTS=5

# Logs
LOG_LEVEL=info
LOG_FILE=logs/pli-login.log

# Recursos
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
`;
        
        fs.writeFileSync(envFile, envContent);
        console.log('   ✓ Arquivo .env criado com chave JWT segura');
    } else {
        console.log('   ✓ Arquivo .env já existe');
    }
}

function createMainServer() {
    const serverContent = `/**
 * PLI Login System - Servidor Principal
 * Servidor Express com todas as funcionalidades de autenticação
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// Importar módulos do PLI Login System
const { setupAuthRoutes } = require('./backend/authRoutes');
const PLIAuthMiddleware = require('./backend/authMiddleware');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do banco de dados
const dbConfig = {
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'pli_db',
    password: process.env.DB_PASSWORD || 'sua_senha',
    port: process.env.DB_PORT || 5432,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
};

// Middleware global
app.use(cors({
    origin: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000'],
    credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Middleware de logs
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(\`[\${timestamp}] \${req.method} \${req.path}\`);
    next();
});

// Servir arquivos estáticos
app.use(express.static('public'));
app.use('/assets', express.static('assets'));

// Configurar rotas de autenticação do PLI
setupAuthRoutes(app, dbConfig);

// Criar instância do middleware de autenticação
const authMiddleware = new PLIAuthMiddleware(dbConfig);

// Rotas principais
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'assets/index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'assets/index.html'));
});

app.get('/dashboard', authMiddleware.verifyAuth(), (req, res) => {
    res.sendFile(path.join(__dirname, 'assets/dashboard.html'));
});

// Rota de status do sistema
app.get('/api/status', (req, res) => {
    res.json({
        sistema: 'PLI Login System',
        versao: '1.0.0',
        status: 'ativo',
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
});

// Rota protegida de exemplo
app.get('/api/protected', authMiddleware.verifyAuth(), (req, res) => {
    res.json({
        sucesso: true,
        mensagem: 'Acesso autorizado!',
        usuario: req.user,
        timestamp: new Date().toISOString()
    });
});

// Middleware para rotas não encontradas
app.use('*', (req, res) => {
    res.status(404).json({
        erro: 'Rota não encontrada',
        path: req.originalUrl
    });
});

// Middleware para tratamento de erros
app.use((error, req, res, next) => {
    console.error('Erro no servidor:', error);
    
    res.status(500).json({
        erro: 'Erro interno do servidor',
        ...(process.env.NODE_ENV === 'development' && { 
            detalhes: error.message,
            stack: error.stack 
        })
    });
});

// Inicializar servidor
async function startServer() {
    try {
        // Verificar conexão com banco
        const { Pool } = require('pg');
        const pool = new Pool(dbConfig);
        
        await pool.query('SELECT 1');
        console.log('✅ Conexão com banco de dados estabelecida');
        await pool.end();
        
        // Iniciar servidor
        app.listen(PORT, () => {
            console.log(\`
🚀 PLI Login System iniciado com sucesso!

📡 Servidor: http://localhost:\${PORT}
🔐 Login: http://localhost:\${PORT}/login  
📊 Dashboard: http://localhost:\${PORT}/dashboard
📊 Status: http://localhost:\${PORT}/api/status

🛡️  Sistema de autenticação ativo
📁 Arquivos servidos de /public e /assets
            \`);
        });
        
    } catch (error) {
        console.error('❌ Erro ao iniciar servidor:', error.message);
        console.error('💡 Verifique a configuração do banco de dados no arquivo .env');
        process.exit(1);
    }
}

// Tratamento de sinais do sistema
process.on('SIGTERM', () => {
    console.log('\\n🔄 SIGTERM recebido. Encerrando servidor...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('\\n🔄 SIGINT recebido. Encerrando servidor...');
    process.exit(0);
});

process.on('uncaughtException', (error) => {
    console.error('❌ Erro não capturado:', error);
    process.exit(1);
});

// Iniciar aplicação
if (require.main === module) {
    startServer();
}

module.exports = app;
`;

    fs.writeFileSync(path.join(process.cwd(), 'server.js'), serverContent);
    console.log('   ✓ Servidor principal criado');
}

function createUtilityScripts() {
    // Script de configuração do banco
    const dbSetupScript = `/**
 * Script para configuração do banco de dados
 */

require('dotenv').config();
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

async function setupDatabase() {
    console.log('🗄️  Configurando banco de dados PLI...');
    
    const pool = new Pool({
        user: process.env.DB_USER,
        host: process.env.DB_HOST,
        database: process.env.DB_NAME,
        password: process.env.DB_PASSWORD,
        port: process.env.DB_PORT,
    });
    
    try {
        // Ler script SQL
        const sqlScript = fs.readFileSync(
            path.join(__dirname, '..', 'database', 'setup.sql'), 
            'utf8'
        );
        
        // Executar script
        await pool.query(sqlScript);
        
        console.log('✅ Banco de dados configurado com sucesso!');
        console.log('👤 Usuário padrão: admin / admin123');
        
    } catch (error) {
        console.error('❌ Erro ao configurar banco:', error.message);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

setupDatabase();
`;

    fs.writeFileSync(path.join(process.cwd(), 'scripts', 'setup-database.js'), dbSetupScript);
    
    // Script de teste
    const testScript = `/**
 * Script de teste do sistema
 */

require('dotenv').config();
const http = require('http');

async function testSystem() {
    console.log('🧪 Testando PLI Login System...');
    
    const tests = [
        { name: 'Status do servidor', path: '/api/status' },
        { name: 'Página de login', path: '/login' },
        { name: 'API de autenticação', path: '/api/auth/verify', method: 'POST' }
    ];
    
    for (const test of tests) {
        try {
            await runTest(test);
        } catch (error) {
            console.error(\`❌ \${test.name}: \${error.message}\`);
        }
    }
}

function runTest(test) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: process.env.PORT || 3000,
            path: test.path,
            method: test.method || 'GET'
        };
        
        const req = http.request(options, (res) => {
            if (res.statusCode < 400) {
                console.log(\`✅ \${test.name}: OK (status \${res.statusCode})\`);
                resolve();
            } else {
                reject(new Error(\`Status \${res.statusCode}\`));
            }
        });
        
        req.on('error', reject);
        req.setTimeout(5000, () => reject(new Error('Timeout')));
        req.end();
    });
}

testSystem();
`;

    fs.writeFileSync(path.join(process.cwd(), 'scripts', 'test-system.js'), testScript);
    
    console.log('   ✓ Scripts utilitários criados');
}

function setupLogging() {
    const logDir = path.join(process.cwd(), 'logs');
    
    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }
    
    // Criar arquivo de log inicial
    const logFile = path.join(logDir, 'pli-login.log');
    const initialLog = `[${new Date().toISOString()}] PLI Login System - Sistema inicializado\n`;
    
    fs.writeFileSync(logFile, initialLog);
    console.log('   ✓ Sistema de logs configurado');
}

// Executar configuração
setupSystem();
