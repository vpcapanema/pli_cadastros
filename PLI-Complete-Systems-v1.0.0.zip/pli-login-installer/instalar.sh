#!/bin/bash
# PLI Login System - Instalador Universal para Linux/Mac

echo "==============================================="
echo "   PLI LOGIN SYSTEM - INSTALADOR UNIVERSAL"
echo "==============================================="
echo

# Verificar se Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "[ERRO] Node.js não encontrado!"
    echo "[INFO] Por favor, instale o Node.js primeiro: https://nodejs.org"
    exit 1
fi

# Verificar se npm está disponível
if ! command -v npm &> /dev/null; then
    echo "[ERRO] npm não encontrado!"
    echo "[INFO] Por favor, reinstale o Node.js com npm incluído"
    exit 1
fi

echo "[OK] Node.js detectado"
echo "[OK] npm detectado"
echo

# Perguntar diretório de destino
read -p "Digite o diretório de destino (ou pressione Enter para usar o atual): " DEST_DIR
if [ -z "$DEST_DIR" ]; then
    DEST_DIR=$(pwd)
fi

echo
echo "[INFO] Diretório de destino: $DEST_DIR"
echo

# Criar estrutura de diretórios
echo "[INFO] Criando estrutura de diretórios..."
mkdir -p "$DEST_DIR/pli-login-system"
mkdir -p "$DEST_DIR/pli-login-system/backend"
mkdir -p "$DEST_DIR/pli-login-system/database" 
mkdir -p "$DEST_DIR/pli-login-system/docs"
mkdir -p "$DEST_DIR/pli-login-system/examples"
mkdir -p "$DEST_DIR/pli-login-system/scripts"
mkdir -p "$DEST_DIR/pli-login-system/public"

# Copiar arquivos do sistema
echo "[INFO] Copiando arquivos do sistema..."
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

cp -r "$SCRIPT_DIR/assets/"* "$DEST_DIR/pli-login-system/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/backend/"* "$DEST_DIR/pli-login-system/backend/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/database/"* "$DEST_DIR/pli-login-system/database/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/docs/"* "$DEST_DIR/pli-login-system/docs/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/examples/"* "$DEST_DIR/pli-login-system/examples/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/scripts/"* "$DEST_DIR/pli-login-system/scripts/" 2>/dev/null || true

# Criar package.json
echo "[INFO] Criando package.json..."
cat > "$DEST_DIR/pli-login-system/package.json" << 'EOF'
{
  "name": "pli-login-system",
  "version": "1.0.0",
  "description": "Sistema Universal de Login PLI",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "node server.js",
    "setup-db": "node scripts/setup-database.js",
    "test": "node scripts/test-system.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "pg": "^8.11.0",
    "bcrypt": "^5.1.0",
    "jsonwebtoken": "^9.0.0",
    "crypto": "^1.0.1",
    "dotenv": "^16.0.3"
  },
  "keywords": ["login", "authentication", "pli", "jwt", "session"],
  "author": "PLI System",
  "license": "MIT"
}
EOF

# Criar arquivo de configuração .env
echo "[INFO] Criando arquivo de configuração..."
cat > "$DEST_DIR/pli-login-system/.env.example" << 'EOF'
# PLI Login System - Configuração
# Configure estas variáveis antes de executar

# Banco de Dados
DB_HOST=localhost
DB_PORT=5432
DB_NAME=pli_db
DB_USER=postgres
DB_PASSWORD=sua_senha_aqui

# JWT
JWT_SECRET=sua_chave_super_secreta_aqui_mude_em_producao
JWT_EXPIRES_IN=8h

# Servidor
PORT=3000
NODE_ENV=development

# Logs
LOG_LEVEL=info
LOG_FILE=logs/pli-login.log
EOF

# Mudar para o diretório criado
cd "$DEST_DIR/pli-login-system"

# Instalar dependências
echo
echo "[INFO] Instalando dependências npm..."
echo "[INFO] Isso pode levar alguns minutos..."
npm install

if [ $? -ne 0 ]; then
    echo "[ERRO] Falha na instalação das dependências!"
    echo "[INFO] Tente executar 'npm install' manualmente no diretório:"
    echo "[INFO] $DEST_DIR/pli-login-system"
    exit 1
fi

# Executar script de configuração
echo
echo "[INFO] Executando configuração inicial..."
node scripts/initial-setup.js

# Criar scripts de inicialização
echo
echo "[INFO] Criando scripts de inicialização..."

cat > "$DEST_DIR/iniciar-pli-login.sh" << EOF
#!/bin/bash
cd "$DEST_DIR/pli-login-system"
npm start
EOF

cat > "$DEST_DIR/configurar-banco.sh" << EOF
#!/bin/bash
cd "$DEST_DIR/pli-login-system"
node scripts/setup-database.js
EOF

chmod +x "$DEST_DIR/iniciar-pli-login.sh"
chmod +x "$DEST_DIR/configurar-banco.sh"

# Finalização
echo
echo "==============================================="
echo "[SUCESSO] Instalação concluída com sucesso!"
echo "==============================================="
echo
echo "Arquivos instalados em: $DEST_DIR/pli-login-system"
echo
echo "PRÓXIMOS PASSOS:"
echo
echo "1. Configure o arquivo .env com suas credenciais"
echo "2. Execute ./configurar-banco.sh para criar as tabelas"
echo "3. Execute ./iniciar-pli-login.sh para iniciar o servidor"
echo
echo "DOCUMENTAÇÃO:"
echo "- README.md: Guia completo de uso"
echo "- docs/API.md: Documentação da API"  
echo "- examples/: Exemplos de integração"
echo
echo "Login padrão: admin / admin123"
echo "URL: http://localhost:3000"
echo
