/**
 * Exemplo de Integração - Express.js + PLI Login System
 * Demonstra como integrar o sistema de login em uma aplicação Express
 */

const express = require('express');
const path = require('path');
const cors = require('cors');
const { setupAuthRoutes } = require('../backend/authRoutes');
const PLIAuthMiddleware = require('../backend/authMiddleware');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do banco de dados
const dbConfig = {
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'pli_db',
    password: process.env.DB_PASSWORD || 'sua_senha',
    port: process.env.DB_PORT || 5432,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
};

// Middleware global
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
    credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Middleware para logs
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// Servir arquivos estáticos
app.use(express.static('public'));
app.use('/pli-login', express.static(path.join(__dirname, '../')));

// Configurar rotas de autenticação do PLI
setupAuthRoutes(app, dbConfig);

// Criar instância do middleware de autenticação
const authMiddleware = new PLIAuthMiddleware(dbConfig);

// Rotas públicas (sem autenticação)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../index.html'));
});

app.get('/sobre', (req, res) => {
    res.json({
        aplicacao: 'Sistema PLI',
        versao: '1.0.0',
        descricao: 'Sistema de cadastros com autenticação integrada'
    });
});

// Rotas protegidas (requerem autenticação)

// Dashboard principal
app.get('/dashboard', authMiddleware.verifyAuth(), (req, res) => {
    res.sendFile(path.join(__dirname, '../dashboard.html'));
});

// API protegida - dados do usuário
app.get('/api/user/data', authMiddleware.verifyAuth(), (req, res) => {
    res.json({
        sucesso: true,
        usuario: req.user,
        sessao: req.session,
        timestamp: new Date().toISOString()
    });
});

// API para listagem de dados (exemplo)
app.get('/api/cadastros', authMiddleware.verifyAuth(), async (req, res) => {
    try {
        // Exemplo de consulta protegida
        const { page = 1, limit = 20 } = req.query;
        const offset = (page - 1) * limit;

        // Aqui você faria sua consulta real ao banco
        const mockData = {
            sucesso: true,
            dados: [
                { id: 1, nome: 'Cadastro 1', data: '2024-01-01' },
                { id: 2, nome: 'Cadastro 2', data: '2024-01-02' }
            ],
            pagination: {
                total: 2,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: 1
            },
            usuario_consulta: req.user.username
        };

        res.json(mockData);
    } catch (error) {
        console.error('Erro na listagem:', error);
        res.status(500).json({
            sucesso: false,
            mensagem: 'Erro interno no servidor'
        });
    }
});

// Rotas administrativas (apenas admin)
app.get('/admin', 
    authMiddleware.verifyAuth(), 
    authMiddleware.requireAdmin(), 
    (req, res) => {
    res.json({
        sucesso: true,
        mensagem: 'Acesso autorizado à área administrativa',
        usuario: req.user
    });
});

app.get('/api/admin/stats', 
    authMiddleware.verifyAuth(), 
    authMiddleware.requireAdmin(), 
    async (req, res) => {
    try {
        // Estatísticas do sistema (exemplo)
        const stats = {
            usuarios_total: 150,
            usuarios_ativos: 143,
            sessoes_ativas: 25,
            login_ultimo_24h: 89,
            cadastros_mes: 342
        };

        res.json({
            sucesso: true,
            estatisticas: stats,
            consultado_por: req.user.username,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('Erro nas estatísticas:', error);
        res.status(500).json({
            sucesso: false,
            mensagem: 'Erro ao obter estatísticas'
        });
    }
});

// Rotas para gestores e admins
app.get('/api/gestao/*', 
    authMiddleware.verifyAuth(), 
    authMiddleware.requireManager()
);

app.get('/api/gestao/relatorios', (req, res) => {
    res.json({
        sucesso: true,
        relatorios: [
            { id: 1, nome: 'Relatório de Usuários', tipo: 'usuarios' },
            { id: 2, nome: 'Relatório de Acessos', tipo: 'acessos' },
            { id: 3, nome: 'Relatório de Cadastros', tipo: 'cadastros' }
        ],
        gerado_por: req.user.username
    });
});

// Rotas com nível de acesso específico
app.get('/api/config/*', 
    authMiddleware.verifyAuth(), 
    authMiddleware.requireAccessLevel(5)
);

app.get('/api/config/sistema', (req, res) => {
    res.json({
        sucesso: true,
        configuracoes: {
            nome_sistema: 'PLI Cadastros',
            versao: '1.0.0',
            manutencao: false,
            backup_automatico: true
        },
        acessado_por: req.user.username
    });
});

// Middleware para capturar rotas não encontradas
app.use('*', (req, res) => {
    res.status(404).json({
        sucesso: false,
        mensagem: 'Rota não encontrada',
        path: req.path
    });
});

// Middleware para tratamento de erros
app.use((error, req, res, next) => {
    console.error('Erro na aplicação:', error);
    
    res.status(500).json({
        sucesso: false,
        mensagem: 'Erro interno no servidor',
        ...(process.env.NODE_ENV === 'development' && { 
            stack: error.stack 
        })
    });
});

// Função para inicializar servidor
async function startServer() {
    try {
        // Verificar conexão com banco de dados
        const { Pool } = require('pg');
        const pool = new Pool(dbConfig);
        
        await pool.query('SELECT 1');
        console.log('✅ Conexão com banco de dados estabelecida');
        
        await pool.end();

        // Iniciar servidor
        app.listen(PORT, () => {
            console.log(`
🚀 Servidor PLI iniciado com sucesso!

📡 Servidor: http://localhost:${PORT}
🔐 Login: http://localhost:${PORT}/login
📊 Dashboard: http://localhost:${PORT}/dashboard
👑 Admin: http://localhost:${PORT}/admin

🔗 Endpoints da API:
   • POST /api/auth/login
   • GET  /api/auth/profile
   • GET  /api/cadastros
   • GET  /api/admin/stats
   
🛡️  Middleware de Autenticação Ativo
📁 Arquivos estáticos servidos de /public
            `);
        });

    } catch (error) {
        console.error('❌ Erro ao iniciar servidor:', error);
        process.exit(1);
    }
}

// Tratamento de sinais de sistema
process.on('SIGTERM', () => {
    console.log('SIGTERM recebido. Encerrando servidor...');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT recebido. Encerrando servidor...');
    process.exit(0);
});

// Iniciar aplicação
if (require.main === module) {
    startServer();
}

module.exports = app;

/* 
EXEMPLO DE USO:

1. Instalar dependências:
   npm install express cors pg bcrypt jsonwebtoken

2. Configurar variáveis de ambiente (.env):
   DB_USER=postgres
   DB_HOST=localhost
   DB_NAME=pli_db
   DB_PASSWORD=sua_senha
   DB_PORT=5432
   JWT_SECRET=sua-chave-super-secreta
   PORT=3000
   NODE_ENV=development

3. Executar:
   node examples/express-integration.js

4. Testar:
   - Acesse http://localhost:3000/login
   - Faça login com admin/admin123
   - Acesse http://localhost:3000/dashboard
   - Teste as APIs protegidas

ESTRUTURA DE PASTAS RECOMENDADA:

minha-app/
├── node_modules/
├── public/
│   ├── css/
│   ├── js/
│   └── images/
├── pli-login-system/
│   ├── pli-login-system.js
│   ├── index.html
│   ├── dashboard.html
│   └── backend/
├── .env
├── package.json
└── server.js (este arquivo)

*/
