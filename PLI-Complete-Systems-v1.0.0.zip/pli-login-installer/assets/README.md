# PLI Login System - Sistema Universal de Autenticação

Um sistema completo de login e autenticação para aplicações web, com controle de sessões, proteção de páginas e integração com banco de dados PostgreSQL.

## 🚀 Características

- **Autenticação JWT**: Sistema seguro de tokens
- **Controle de Sessões**: Gerenciamento inteligente de sessões ativas
- **Proteção de Páginas**: Middleware automático para páginas restritas
- **Integração com Banco**: Conecta com base de dados PLI existente
- **Interface Responsiva**: Design moderno com Bootstrap 5
- **Instalação Universal**: Funciona em qualquer aplicação web
- **Logs de Auditoria**: Registro completo de tentativas de login
- **Multi-tenant**: Suporte a diferentes tipos de usuário

## 👥 Tipos de Usuário Suportados

O sistema PLI Login suporta **5 tipos diferentes de usuário** com níveis hierárquicos de permissão:

| Tipo | Descrição | Nível de Acesso | Permissões |
|------|-----------|-----------------|------------|
| **ADMIN** | Administrador | 10 | Acesso total ao sistema, gerenciamento de usuários, configurações |
| **GESTOR** | Gestor/Gerente | 7-9 | Gestão de equipes, relatórios avançados, configurações limitadas |
| **ANALISTA** | Analista | 4-6 | Análise de dados, relatórios, operações especializadas |
| **OPERADOR** | Operador | 2-3 | Operações do dia-a-dia, cadastros, consultas básicas |
| **VISUALIZADOR** | Visualizador | 1 | Apenas visualização, sem permissões de alteração |

### Controle de Acesso Hierárquico

```javascript
// Exemplos de uso dos middlewares por tipo
app.use('/admin/*', middleware.requireAdmin());           // Apenas ADMIN
app.use('/gestao/*', middleware.requireManager());        // ADMIN + GESTOR  
app.use('/analise/*', middleware.requireAnalyst());       // ADMIN + GESTOR + ANALISTA
app.use('/operacoes/*', middleware.requireOperator());    // ADMIN + GESTOR + ANALISTA + OPERADOR
app.use('/visualizar/*', middleware.requireAnyUser());    // Todos os tipos
```

## 📦 Conteúdo do Pacote

```
pli-login-system-package/
├── pli-login-system.js          # Instalador principal
├── index.html                   # Página de login
├── dashboard.html              # Exemplo de página protegida
├── backend/
│   ├── authController.js       # Controlador de autenticação
│   ├── authMiddleware.js       # Middleware de verificação
│   └── authRoutes.js           # Rotas da API
├── database/
│   └── setup.sql               # Script de configuração do banco
├── docs/
│   ├── API.md                  # Documentação da API
│   ├── INTEGRATION.md          # Guia de integração
│   └── TROUBLESHOOTING.md      # Resolução de problemas
└── examples/
    ├── express-integration.js   # Exemplo com Express
    ├── protected-page.html     # Exemplo de página protegida
    └── custom-styles.css       # Estilos personalizáveis
```

## 🛠️ Instalação Rápida

### 1. Frontend (Instalação Automática)

```html
<!DOCTYPE html>
<html>
<head>
    <title>Minha Aplicação</title>
</head>
<body>
    <!-- Seu conteúdo aqui -->
    
    <!-- PLI Login System -->
    <script src="path/to/pli-login-system.js"></script>
    <script>
        // Instalação automática
        const pliLogin = new PLILoginInstaller();
        pliLogin.install({
            baseUrl: 'https://sua-api.com',
            redirectUrl: '/dashboard.html',
            autoProtect: true
        });
    </script>
</body>
</html>
```

### 2. Backend (Express.js)

```javascript
const express = require('express');
const { setupAuthRoutes } = require('./backend/authRoutes');

const app = express();

// Configuração do banco de dados
const dbConfig = {
    user: 'postgres',
    host: 'localhost',
    database: 'pli_db',
    password: 'sua_senha',
    port: 5432,
};

// Middleware básico
app.use(express.json());
app.use(express.static('public'));

// Configurar rotas de autenticação
setupAuthRoutes(app, dbConfig);

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});
```

### 3. Banco de Dados

Execute o script SQL para configurar as tabelas:

```bash
psql -d pli_db -f database/setup.sql
```

## 🔧 Configuração

### Frontend

```javascript
const config = {
    // URL base da API
    baseUrl: 'https://api.exemplo.com',
    
    // Página para redirecionamento após login
    redirectUrl: '/dashboard.html',
    
    // Proteção automática de páginas
    autoProtect: true,
    
    // Páginas públicas (não protegidas)
    publicPages: ['/login.html', '/sobre.html'],
    
    // Configuração visual
    theme: {
        primaryColor: '#007bff',
        logoUrl: '/assets/logo.png',
        companyName: 'Minha Empresa'
    },
    
    // Configuração de sessão
    session: {
        autoRenew: true,
        renewInterval: 300000, // 5 minutos
        warningTime: 120000,   // 2 minutos
        maxInactivity: 1800000 // 30 minutos
    }
};

const pliLogin = new PLILoginInstaller();
pliLogin.install(config);
```

### Backend

```javascript
// Configuração avançada do middleware
const middleware = new PLIAuthMiddleware(dbConfig);

// Proteção básica
app.use('/admin/*', middleware.verifyAuth());

// Proteção por tipo de usuário
app.use('/gestao/*', 
    middleware.verifyAuth(), 
    middleware.requireManager()
);

// Proteção por nível de acesso
app.use('/config/*', 
    middleware.verifyAuth(), 
    middleware.requireAccessLevel(5)
);

// Apenas administradores
app.use('/admin/users', 
    middleware.verifyAuth(), 
    middleware.requireAdmin()
);
```

## 🔐 Proteção de Páginas

### Automática

```javascript
// Ativar proteção automática
const pliAuth = new PLIAuth({
    baseUrl: 'https://api.exemplo.com',
    autoProtect: true,
    publicPages: ['/login.html', '/public.html']
});
```

### Manual

```javascript
// Em páginas específicas
const pageGuard = new PLIPageGuard();
pageGuard.protect({
    requiredUserType: 'ADMIN',
    requiredAccessLevel: 3,
    onUnauthorized: () => {
        window.location.href = '/login.html';
    }
});
```

### Via HTML Data Attributes

```html
<div id="admin-content" data-pli-protect="ADMIN">
    Conteúdo apenas para administradores
</div>

<div id="manager-content" data-pli-protect="GESTOR,ADMIN">
    Conteúdo para gestores e admins
</div>

<div id="level-content" data-pli-min-level="5">
    Conteúdo para nível 5 ou superior
</div>
```

## 📱 Interface de Login

### Personalização

```css
/* Personalizar cores */
:root {
    --pli-primary-color: #your-color;
    --pli-secondary-color: #your-secondary;
    --pli-background: #your-background;
}

/* Personalizar logo */
.pli-login-logo {
    background-image: url('/seu-logo.png');
}

/* Personalizar formulário */
.pli-login-form {
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
```

### Validação Customizada

```javascript
// Adicionar validações personalizadas
pliAuth.addValidator('username', (value) => {
    if (value.length < 3) {
        return 'Username deve ter pelo menos 3 caracteres';
    }
    if (!/^[a-zA-Z0-9_]+$/.test(value)) {
        return 'Username pode conter apenas letras, números e underscore';
    }
    return null; // Válido
});

pliAuth.addValidator('password', (value) => {
    if (value.length < 6) {
        return 'Senha deve ter pelo menos 6 caracteres';
    }
    return null;
});
```

## 🔌 API Endpoints

### Autenticação

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/auth/login` | Realizar login |
| POST | `/api/auth/logout` | Realizar logout |
| POST | `/api/auth/verify` | Verificar token |
| POST | `/api/auth/renew` | Renovar sessão |

### Perfil do Usuário

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/auth/profile` | Obter perfil |
| GET | `/api/auth/sessions` | Listar sessões |
| DELETE | `/api/auth/sessions/:id` | Encerrar sessão |

### Administração

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/auth/admin/users` | Listar usuários |
| POST | `/api/auth/admin/users/:id/toggle` | Ativar/Desativar |

### Exemplo de Uso da API

```javascript
// Login
const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        username: 'usuario',
        password: 'senha',
        userType: 'ADMIN'
    })
});

const data = await response.json();

if (data.sucesso) {
    localStorage.setItem('pli_token', data.token);
    window.location.href = '/dashboard.html';
}
```

## 📊 Monitoramento de Sessões

### Dashboard de Sessões

```javascript
// Obter sessões ativas
pliAuth.getSessions().then(sessions => {
    console.log('Sessões ativas:', sessions);
});

// Monitorar status da sessão
pliAuth.onSessionUpdate((status) => {
    if (status === 'expired') {
        alert('Sua sessão expirou');
        window.location.href = '/login.html';
    }
});

// Renovação automática
pliAuth.enableAutoRenew({
    interval: 300000, // 5 minutos
    warningTime: 120000 // Avisar 2 minutos antes
});
```

### Eventos de Sessão

```javascript
// Escutar eventos
pliAuth.on('login', (user) => {
    console.log('Usuário logado:', user);
});

pliAuth.on('logout', () => {
    console.log('Usuário deslogado');
});

pliAuth.on('sessionWarning', (timeLeft) => {
    console.log('Sessão expira em:', timeLeft);
});

pliAuth.on('sessionExpired', () => {
    alert('Sessão expirada');
    window.location.href = '/login.html';
});
```

## 🛡️ Segurança

### Tokens JWT

- Expiração automática
- Renovação segura
- Invalidação no logout
- Hash do token no banco

### Proteção contra Ataques

- Rate limiting (configure no seu proxy)
- Validação de entrada
- Sanitização de dados
- Logs de auditoria

### Configuração de Segurança

```javascript
// Configurações de segurança recomendadas
const securityConfig = {
    session: {
        maxDuration: 8 * 60 * 60 * 1000, // 8 horas
        inactivityTimeout: 30 * 60 * 1000, // 30 minutos
        maxRenewals: 5,
        enforceUniqueSession: false
    },
    password: {
        minLength: 8,
        requireSpecialChars: true,
        requireNumbers: true,
        requireUppercase: true
    },
    security: {
        maxLoginAttempts: 5,
        lockoutDuration: 15 * 60 * 1000, // 15 minutos
        logAllAttempts: true
    }
};
```

## 🔍 Logs e Auditoria

### Visualizar Logs

```sql
-- Últimas tentativas de login
SELECT * FROM usuarios.log_sistema 
WHERE operacao IN ('LOGIN_SUCESSO', 'LOGIN_FALHA')
ORDER BY data_operacao DESC 
LIMIT 50;

-- Sessões ativas por usuário
SELECT 
    us.username,
    COUNT(*) as sessoes_ativas
FROM usuarios.sessao_controle sc
JOIN usuarios.usuario_sistema us ON sc.usuario_id = us.id
WHERE sc.status_sessao = 'ATIVA'
GROUP BY us.username;
```

### Dashboard de Monitoramento

```javascript
// Criar dashboard simples
pliAuth.createMonitoringDashboard('#monitoring-container', {
    refreshInterval: 30000,
    showCharts: true,
    showLogs: true,
    maxLogEntries: 100
});
```

## 🚨 Resolução de Problemas

### Problemas Comuns

1. **Token inválido/expirado**
   - Verificar configuração do JWT_SECRET
   - Verificar sincronização de horário entre servidor e cliente

2. **Sessão não reconhecida**
   - Verificar conexão com banco de dados
   - Verificar se as tabelas foram criadas corretamente

3. **Redirecionamento não funciona**
   - Verificar configuração de redirectUrl
   - Verificar permissões de acesso às páginas

### Debug Mode

```javascript
// Ativar modo debug
const pliAuth = new PLIAuth({
    baseUrl: 'https://api.exemplo.com',
    debug: true, // Ativa logs detalhados
    debugLevel: 'verbose' // 'basic', 'detailed', 'verbose'
});
```

### Logs Detalhados

```javascript
// Ativar logs no console
localStorage.setItem('pli_debug', 'true');

// Ou configurar programaticamente
pliAuth.setDebugMode(true);
```

## 📞 Suporte

Para suporte e dúvidas:

1. Verifique a documentação completa em `/docs/`
2. Consulte os exemplos em `/examples/`
3. Verifique os logs do sistema
4. Entre em contato com a equipe de desenvolvimento

## 📄 Licença

Sistema desenvolvido para uso interno da PLI. Todos os direitos reservados.

---

**PLI Login System v1.0.0** - Sistema Universal de Autenticação
