-- PLI Login System - Database Setup
-- Script para configuração das tabelas necessárias para o sistema de login

-- Criar schema usuarios se não existir
CREATE SCHEMA IF NOT EXISTS usuarios;

-- Extensão para UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela pessoa_fisica (se não existir)
CREATE TABLE IF NOT EXISTS usuarios.pessoa_fisica (
    id SERIAL PRIMARY KEY,
    nome_completo VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE,
    email VARCHAR(255),
    telefone VARCHAR(20),
    data_nascimento DATE,
    endereco TEXT,
    data_criacao TIMESTAMP DEFAULT NOW(),
    data_alteracao TIMESTAMP DEFAULT NOW(),
    data_exclusao TIMESTAMP NULL
);

-- Tabela usuario_sistema (se não existir)
CREATE TABLE IF NOT EXISTS usuarios.usuario_sistema (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    salt VARCHAR(100) NOT NULL,
    tipo_usuario VARCHAR(20) DEFAULT 'ADMIN' CHECK (tipo_usuario IN ('ADMIN', 'GESTOR', 'ANALISTA', 'OPERADOR', 'VISUALIZADOR')),
    nivel_acesso INTEGER DEFAULT 1 CHECK (nivel_acesso BETWEEN 1 AND 10),
    ativo BOOLEAN DEFAULT true,
    primeiro_login BOOLEAN DEFAULT true,
    ultimo_login TIMESTAMP NULL,
    tentativas_login INTEGER DEFAULT 0,
    bloqueado_ate TIMESTAMP NULL,
    pessoa_fisica_id INTEGER REFERENCES usuarios.pessoa_fisica(id),
    data_criacao TIMESTAMP DEFAULT NOW(),
    data_alteracao TIMESTAMP DEFAULT NOW(),
    data_exclusao TIMESTAMP NULL,
    criado_por INTEGER REFERENCES usuarios.usuario_sistema(id),
    alterado_por INTEGER REFERENCES usuarios.usuario_sistema(id)
);

-- Tabela sessao_controle (atualizada com melhorias)
CREATE TABLE IF NOT EXISTS usuarios.sessao_controle (
    id SERIAL PRIMARY KEY,
    session_id UUID DEFAULT uuid_generate_v4() UNIQUE NOT NULL,
    usuario_id INTEGER NOT NULL REFERENCES usuarios.usuario_sistema(id),
    token_hash VARCHAR(255) NOT NULL,
    status_sessao VARCHAR(20) DEFAULT 'ATIVA' CHECK (status_sessao IN ('ATIVA', 'EXPIRADA', 'ENCERRADA', 'INVALIDA')),
    data_login TIMESTAMP DEFAULT NOW(),
    data_expiracao TIMESTAMP NOT NULL,
    data_logout TIMESTAMP NULL,
    ultimo_acesso TIMESTAMP DEFAULT NOW(),
    endereco_ip INET,
    user_agent TEXT,
    origem VARCHAR(255),
    motivo_logout VARCHAR(50),
    renovacoes INTEGER DEFAULT 0,
    max_renovacoes INTEGER DEFAULT 5,
    dados_extras JSONB
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_usuario_sistema_username ON usuarios.usuario_sistema(username);
CREATE INDEX IF NOT EXISTS idx_usuario_sistema_email ON usuarios.usuario_sistema(email);
CREATE INDEX IF NOT EXISTS idx_usuario_sistema_ativo ON usuarios.usuario_sistema(ativo);
CREATE INDEX IF NOT EXISTS idx_usuario_sistema_tipo ON usuarios.usuario_sistema(tipo_usuario);

CREATE INDEX IF NOT EXISTS idx_sessao_controle_usuario_id ON usuarios.sessao_controle(usuario_id);
CREATE INDEX IF NOT EXISTS idx_sessao_controle_token_hash ON usuarios.sessao_controle(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessao_controle_status ON usuarios.sessao_controle(status_sessao);
CREATE INDEX IF NOT EXISTS idx_sessao_controle_expiracao ON usuarios.sessao_controle(data_expiracao);
CREATE INDEX IF NOT EXISTS idx_sessao_controle_session_id ON usuarios.sessao_controle(session_id);

-- Função para limpeza automática de sessões expiradas
CREATE OR REPLACE FUNCTION usuarios.limpar_sessoes_expiradas()
RETURNS INTEGER AS $$
DECLARE
    sessoes_removidas INTEGER;
BEGIN
    -- Marcar sessões expiradas
    UPDATE usuarios.sessao_controle 
    SET status_sessao = 'EXPIRADA',
        data_logout = NOW(),
        motivo_logout = 'EXPIRADA_AUTOMATICAMENTE'
    WHERE status_sessao = 'ATIVA' 
    AND data_expiracao < NOW();
    
    GET DIAGNOSTICS sessoes_removidas = ROW_COUNT;
    
    -- Log da limpeza
    INSERT INTO usuarios.log_sistema (operacao, descricao, quantidade)
    VALUES ('LIMPEZA_SESSOES', 'Sessões expiradas automaticamente', sessoes_removidas);
    
    RETURN sessoes_removidas;
END;
$$ LANGUAGE plpgsql;

-- Tabela de log do sistema (para auditoria)
CREATE TABLE IF NOT EXISTS usuarios.log_sistema (
    id SERIAL PRIMARY KEY,
    operacao VARCHAR(50) NOT NULL,
    descricao TEXT,
    usuario_id INTEGER REFERENCES usuarios.usuario_sistema(id),
    endereco_ip INET,
    user_agent TEXT,
    dados_extras JSONB,
    quantidade INTEGER,
    data_operacao TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_log_sistema_operacao ON usuarios.log_sistema(operacao);
CREATE INDEX IF NOT EXISTS idx_log_sistema_usuario_id ON usuarios.log_sistema(usuario_id);
CREATE INDEX IF NOT EXISTS idx_log_sistema_data ON usuarios.log_sistema(data_operacao);

-- Função para registrar tentativas de login
CREATE OR REPLACE FUNCTION usuarios.registrar_tentativa_login(
    p_username VARCHAR(100),
    p_sucesso BOOLEAN,
    p_endereco_ip INET,
    p_user_agent TEXT,
    p_motivo VARCHAR(100) DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO usuarios.log_sistema (
        operacao, 
        descricao, 
        usuario_id, 
        endereco_ip, 
        user_agent,
        dados_extras
    )
    SELECT 
        CASE WHEN p_sucesso THEN 'LOGIN_SUCESSO' ELSE 'LOGIN_FALHA' END,
        CASE WHEN p_sucesso THEN 'Login realizado com sucesso' ELSE COALESCE(p_motivo, 'Tentativa de login falhada') END,
        us.id,
        p_endereco_ip,
        p_user_agent,
        jsonb_build_object('username', p_username, 'sucesso', p_sucesso, 'motivo', p_motivo)
    FROM usuarios.usuario_sistema us
    WHERE us.username = p_username AND us.data_exclusao IS NULL;
    
    -- Se o usuário não existir, ainda registra a tentativa
    IF NOT FOUND THEN
        INSERT INTO usuarios.log_sistema (
            operacao, 
            descricao, 
            endereco_ip, 
            user_agent,
            dados_extras
        )
        VALUES (
            'LOGIN_FALHA',
            'Tentativa de login com usuário inexistente',
            p_endereco_ip,
            p_user_agent,
            jsonb_build_object('username', p_username, 'sucesso', false, 'motivo', 'USUARIO_INEXISTENTE')
        );
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Função para atualizar último login
CREATE OR REPLACE FUNCTION usuarios.atualizar_ultimo_login(p_usuario_id INTEGER)
RETURNS VOID AS $$
BEGIN
    UPDATE usuarios.usuario_sistema 
    SET ultimo_login = NOW(),
        tentativas_login = 0,
        primeiro_login = false
    WHERE id = p_usuario_id;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar data_alteracao automaticamente
CREATE OR REPLACE FUNCTION usuarios.atualizar_data_alteracao()
RETURNS TRIGGER AS $$
BEGIN
    NEW.data_alteracao = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger nas tabelas
DROP TRIGGER IF EXISTS trigger_atualizar_data_alteracao_usuario ON usuarios.usuario_sistema;
CREATE TRIGGER trigger_atualizar_data_alteracao_usuario
    BEFORE UPDATE ON usuarios.usuario_sistema
    FOR EACH ROW
    EXECUTE FUNCTION usuarios.atualizar_data_alteracao();

DROP TRIGGER IF EXISTS trigger_atualizar_data_alteracao_pessoa ON usuarios.pessoa_fisica;
CREATE TRIGGER trigger_atualizar_data_alteracao_pessoa
    BEFORE UPDATE ON usuarios.pessoa_fisica
    FOR EACH ROW
    EXECUTE FUNCTION usuarios.atualizar_data_alteracao();

-- Inserir usuário administrador padrão (apenas se não existir)
DO $$
BEGIN
    -- Verificar se já existe um usuário admin
    IF NOT EXISTS (SELECT 1 FROM usuarios.usuario_sistema WHERE username = 'admin' AND data_exclusao IS NULL) THEN
        -- Inserir pessoa física para o admin
        INSERT INTO usuarios.pessoa_fisica (nome_completo, email)
        VALUES ('Administrador do Sistema', 'admin@pli.local');
        
        -- Inserir usuário admin (senha padrão: 'admin123' - DEVE SER ALTERADA)
        INSERT INTO usuarios.usuario_sistema (
            username, 
            email, 
            password_hash, 
            salt, 
            tipo_usuario,
            nivel_acesso,
            pessoa_fisica_id
        )
        VALUES (
            'admin',
            'admin@pli.local',
            '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeD4mYJOyZHKQ9aHW', -- hash de 'admin123'
            'default_salt_change_this',
            'ADMIN',
            10,
            (SELECT id FROM usuarios.pessoa_fisica WHERE email = 'admin@pli.local')
        );
        
        RAISE NOTICE 'Usuário administrador padrão criado: admin/admin123 (ALTERE A SENHA!)';
    END IF;
END $$;

-- Criar job para limpeza automática (executar diariamente)
-- Este comando pode variar dependendo da versão do PostgreSQL e extensões instaladas
-- Descomente se tiver pg_cron instalado:
-- SELECT cron.schedule('limpeza-sessoes-pli', '0 2 * * *', 'SELECT usuarios.limpar_sessoes_expiradas();');

-- Comentários finais
COMMENT ON SCHEMA usuarios IS 'Schema para gerenciamento de usuários e sessões do sistema PLI';
COMMENT ON TABLE usuarios.usuario_sistema IS 'Tabela principal de usuários do sistema';
COMMENT ON TABLE usuarios.sessao_controle IS 'Controle de sessões ativas e históricas';
COMMENT ON TABLE usuarios.log_sistema IS 'Log de auditoria do sistema de autenticação';

-- Verificação final
SELECT 
    'PLI Login System - Database Setup Completed' as status,
    (SELECT COUNT(*) FROM usuarios.usuario_sistema WHERE data_exclusao IS NULL) as usuarios_total,
    (SELECT COUNT(*) FROM usuarios.sessao_controle WHERE status_sessao = 'ATIVA') as sessoes_ativas;
