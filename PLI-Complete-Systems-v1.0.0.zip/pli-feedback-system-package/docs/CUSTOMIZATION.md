# PLI Feedback System - Guia de Personalização

## 🎨 Personalizando o Sistema de Feedback

Este guia mostra como personalizar completamente o PLI Feedback System para se adequar ao design da sua aplicação.

## 🔧 Configuração Inicial

### Instalação com Configurações Personalizadas

```javascript
const installer = new PLIFeedbackInstaller();
installer.install({
    // Configurações básicas
    autoInstall: true,
    includePLIColors: false,  // Desabilitar cores PLI
    debug: true,
    
    // Cores personalizadas
    customColors: {
        primary: '#2563eb',      // Azul personalizado
        success: '#10b981',      // Verde personalizado
        error: '#ef4444',        // Vermelho personalizado
        warning: '#f59e0b',      // Amarelo personalizado
        info: '#06b6d4',         // Azul claro personalizado
        confirmation: '#64748b'   // Cinza personalizado
    }
});
```

## 🎯 Personalização de Cores

### 1. Cores por Categoria

```javascript
// Definir paleta de cores completa
const customColors = {
    // Cores principais
    primary: '#1e40af',
    secondary: '#64748b',
    
    // Cores de feedback
    success: '#059669',
    error: '#dc2626',
    warning: '#d97706',
    info: '#0284c7',
    confirmation: '#475569',
    
    // Cores adicionais
    light: '#f8fafc',
    dark: '#0f172a',
    muted: '#64748b'
};

const installer = new PLIFeedbackInstaller();
installer.install({ customColors });
```

### 2. Aplicação de Cores via CSS

Após a instalação, você pode sobrescrever estilos específicos:

```css
/* Personalizar cores dos ícones */
.feedback-icon.success { color: #10b981 !important; }
.feedback-icon.error { color: #ef4444 !important; }
.feedback-icon.warning { color: #f59e0b !important; }
.feedback-icon.info { color: #06b6d4 !important; }

/* Personalizar cores dos botões */
.btn-primary { background-color: #2563eb !important; }
.btn-success { background-color: #10b981 !important; }
.btn-danger { background-color: #ef4444 !important; }

/* Personalizar cores dos steps de progress */
.progress-step.completed { 
    background: rgba(16, 185, 129, 0.1) !important; 
    border-left-color: #10b981 !important; 
}

.progress-step.processing { 
    background: rgba(245, 158, 11, 0.1) !important; 
    border-left-color: #f59e0b !important; 
}

.progress-step.error { 
    background: rgba(239, 68, 68, 0.1) !important; 
    border-left-color: #ef4444 !important; 
}
```

## 🎨 Personalização de Estilos

### 1. Modal Personalizado

```css
/* Customizar modal principal */
#pli-feedback-modal .modal-content {
    border-radius: 20px !important;
    border: none !important;
    box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25) !important;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    color: white !important;
}

/* Ícones com efeito glow */
.feedback-icon {
    text-shadow: 0 0 20px currentColor !important;
    filter: drop-shadow(0 0 10px currentColor) !important;
}

/* Botões com estilo glassmorphism */
#pli-feedback-modal .btn {
    background: rgba(255, 255, 255, 0.1) !important;
    border: 1px solid rgba(255, 255, 255, 0.2) !important;
    backdrop-filter: blur(10px) !important;
    color: white !important;
    transition: all 0.3s ease !important;
}

#pli-feedback-modal .btn:hover {
    background: rgba(255, 255, 255, 0.2) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2) !important;
}
```

### 2. Progress Overlay Personalizado

```css
/* Overlay com efeito blur */
.progress-overlay {
    backdrop-filter: blur(8px) !important;
    background: rgba(15, 23, 42, 0.7) !important;
}

/* Container com estilo moderno */
.progress-content {
    background: linear-gradient(135deg, #1e293b 0%, #334155 100%) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: white !important;
}

/* Header com gradiente */
.progress-header {
    background: linear-gradient(90deg, #3b82f6, #8b5cf6) !important;
    border-radius: 12px 12px 0 0 !important;
    margin: -2rem -2rem 2rem -2rem !important;
    padding: 2rem !important;
    border-bottom: none !important;
}

/* Steps com tema escuro */
.progress-step {
    background: rgba(51, 65, 85, 0.5) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: #e2e8f0 !important;
}

.progress-step.completed {
    background: rgba(34, 197, 94, 0.2) !important;
    border-color: #22c55e !important;
}

.progress-step.processing {
    background: rgba(251, 191, 36, 0.2) !important;
    border-color: #fbbf24 !important;
}

.progress-step.error {
    background: rgba(239, 68, 68, 0.2) !important;
    border-color: #ef4444 !important;
}
```

## 🌟 Temas Pré-definidos

### 1. Tema Dark Mode

```css
/* Aplicar após instalação */
.dark-theme {
    /* Modal dark */
    --modal-bg: #1e293b;
    --modal-color: #e2e8f0;
    --modal-border: #334155;
    
    /* Progress dark */
    --progress-bg: #0f172a;
    --progress-content-bg: #1e293b;
    --progress-step-bg: #334155;
    --progress-text: #e2e8f0;
}

#pli-feedback-modal.dark-theme .modal-content {
    background-color: var(--modal-bg) !important;
    color: var(--modal-color) !important;
    border: 1px solid var(--modal-border) !important;
}

.progress-overlay.dark-theme {
    background: rgba(15, 23, 42, 0.9) !important;
}

.progress-content.dark-theme {
    background: var(--progress-content-bg) !important;
    color: var(--progress-text) !important;
    border: 1px solid var(--modal-border) !important;
}
```

**Aplicar tema:**
```javascript
// Adicionar classe ao modal
document.getElementById('pli-feedback-modal').classList.add('dark-theme');

// Adicionar classe ao progress (quando ativo)
document.querySelector('.progress-overlay')?.classList.add('dark-theme');
document.querySelector('.progress-content')?.classList.add('dark-theme');
```

### 2. Tema Material Design

```css
.material-theme {
    /* Elevação e sombras */
    --elevation-1: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    --elevation-2: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
    --elevation-3: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
    
    /* Cores Material */
    --mat-primary: #2196f3;
    --mat-accent: #ff4081;
    --mat-warn: #f44336;
    --mat-success: #4caf50;
}

#pli-feedback-modal.material-theme .modal-content {
    border-radius: 4px !important;
    box-shadow: var(--elevation-3) !important;
    border: none !important;
}

#pli-feedback-modal.material-theme .btn {
    border-radius: 4px !important;
    text-transform: uppercase !important;
    font-weight: 500 !important;
    letter-spacing: 0.5px !important;
    box-shadow: var(--elevation-1) !important;
}

.progress-content.material-theme {
    border-radius: 4px !important;
    box-shadow: var(--elevation-3) !important;
}

.progress-step.material-theme {
    border-radius: 4px !important;
    box-shadow: var(--elevation-1) !important;
    transition: box-shadow 0.3s ease !important;
}

.progress-step.material-theme:hover {
    box-shadow: var(--elevation-2) !important;
}
```

### 3. Tema Minimalista

```css
.minimal-theme {
    /* Cores suaves */
    --min-gray-50: #f9fafb;
    --min-gray-100: #f3f4f6;
    --min-gray-500: #6b7280;
    --min-gray-900: #111827;
}

#pli-feedback-modal.minimal-theme .modal-content {
    border-radius: 8px !important;
    border: 1px solid var(--min-gray-100) !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
    background: white !important;
}

#pli-feedback-modal.minimal-theme .feedback-icon {
    font-size: 2.5rem !important;
    margin-bottom: 1rem !important;
}

#pli-feedback-modal.minimal-theme h4 {
    font-weight: 600 !important;
    font-size: 1.25rem !important;
    color: var(--min-gray-900) !important;
}

#pli-feedback-modal.minimal-theme p {
    color: var(--min-gray-500) !important;
    font-size: 0.95rem !important;
}

#pli-feedback-modal.minimal-theme .btn {
    border-radius: 6px !important;
    font-weight: 500 !important;
    padding: 0.5rem 1.5rem !important;
    border: 1px solid transparent !important;
}

.progress-content.minimal-theme {
    border-radius: 8px !important;
    background: white !important;
    border: 1px solid var(--min-gray-100) !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
}

.progress-step.minimal-theme {
    border-radius: 6px !important;
    border: 1px solid var(--min-gray-100) !important;
    background: var(--min-gray-50) !important;
}
```

## 🚀 Personalização Avançada

### 1. Animações Customizadas

```css
/* Animação de entrada do modal */
@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-50px) scale(0.9);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

#pli-feedback-modal.show .modal-content {
    animation: modalSlideIn 0.3s ease-out;
}

/* Animação de pulse para processing */
@keyframes customPulse {
    0%, 100% { 
        transform: scale(1); 
        box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
    }
    50% { 
        transform: scale(1.05); 
        box-shadow: 0 0 0 10px rgba(59, 130, 246, 0);
    }
}

.progress-step.processing {
    animation: customPulse 2s infinite;
}

/* Animação de sucesso */
@keyframes successBounce {
    0%, 20%, 53%, 80%, 100% {
        transform: translate3d(0,0,0);
    }
    40%, 43% {
        transform: translate3d(0, -10px, 0);
    }
    70% {
        transform: translate3d(0, -5px, 0);
    }
    90% {
        transform: translate3d(0, -2px, 0);
    }
}

.progress-step.completed .step-icon {
    animation: successBounce 1s ease;
}
```

### 2. Ícones Personalizados

```javascript
// Função para personalizar ícones
function customizeIcons() {
    const iconConfig = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-triangle',
        warning: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle',
        confirmation: 'fas fa-question-circle',
        processing: 'fas fa-cog fa-spin',
        completed: 'fas fa-check',
        pending: 'far fa-circle'
    };
    
    // Aplicar via CSS
    Object.keys(iconConfig).forEach(type => {
        const style = document.createElement('style');
        style.textContent = `
            .feedback-icon.${type} i:before,
            .step-icon.${type} i:before {
                content: "${iconConfig[type].split(' ').pop()}";
            }
        `;
        document.head.appendChild(style);
    });
}

// Aplicar após instalação
customizeIcons();
```

### 3. Sons de Feedback

```javascript
// Adicionar sons aos feedbacks
class AudioFeedback {
    constructor() {
        this.sounds = {
            success: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj...'), // Som de sucesso
            error: new Audio('data:audio/wav;base64,UklGRvQDAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YdADAAC4uLi4uLi4uLi4uLi4uLi4uLi4uLi4...'), // Som de erro
            warning: new Audio('data:audio/wav;base64,UklGRkADAABXQVZFZm10IBAAAAABAAEAgLsAAIC7AAABAAgAZGF0YRwDAACJiYmJiYmJiYmJiYmJiYmJiYmJiYmJ...') // Som de aviso
        };
    }
    
    play(type) {
        if (this.sounds[type]) {
            this.sounds[type].currentTime = 0;
            this.sounds[type].play().catch(() => {
                // Ignorar erros de autoplay
            });
        }
    }
}

// Integrar com sistema existente
const audioFeedback = new AudioFeedback();

// Sobrescrever métodos para incluir som
const originalSuccess = PLIFeedback.success;
PLIFeedback.success = function(...args) {
    audioFeedback.play('success');
    return originalSuccess.apply(this, args);
};

const originalError = PLIFeedback.error;
PLIFeedback.error = function(...args) {
    audioFeedback.play('error');
    return originalError.apply(this, args);
};

const originalWarning = PLIFeedback.warning;
PLIFeedback.warning = function(...args) {
    audioFeedback.play('warning');
    return originalWarning.apply(this, args);
};
```

## 📱 Responsividade Personalizada

### 1. Breakpoints Customizados

```css
/* Mobile First - Customizar para sua aplicação */
@media (max-width: 480px) {
    #pli-feedback-modal .modal-dialog {
        margin: 0.5rem;
        max-width: calc(100% - 1rem);
    }
    
    .feedback-icon {
        font-size: 3rem !important;
    }
    
    #pli-feedback-modal h4 {
        font-size: 1.1rem !important;
    }
    
    .progress-content {
        width: 95%;
        padding: 1rem;
        margin: 0.5rem;
    }
    
    .progress-step {
        padding: 0.75rem;
        margin: 1rem 0;
    }
}

@media (min-width: 481px) and (max-width: 768px) {
    #pli-feedback-modal .modal-dialog {
        max-width: 90%;
    }
    
    .progress-content {
        width: 85%;
        max-width: 500px;
    }
}

@media (min-width: 769px) {
    #pli-feedback-modal .modal-dialog {
        max-width: 600px;
    }
    
    .progress-content {
        max-width: 550px;
    }
}
```

### 2. Orientação Personalizada

```css
/* Landscape em dispositivos móveis */
@media (max-height: 500px) and (orientation: landscape) {
    #pli-feedback-modal .modal-dialog {
        margin-top: 1rem;
        margin-bottom: 1rem;
    }
    
    .feedback-icon {
        font-size: 2.5rem !important;
        margin-bottom: 0.5rem !important;
    }
    
    .progress-content {
        max-height: 90vh;
        overflow-y: auto;
    }
    
    .progress-step {
        margin: 0.75rem 0;
        padding: 0.75rem;
    }
}
```

## 🔧 Configuração por Projeto

### 1. Arquivo de Configuração

```javascript
// config/feedback-theme.js
const FeedbackTheme = {
    // Cores do projeto
    colors: {
        primary: '#1e40af',
        success: '#059669',
        error: '#dc2626',
        warning: '#d97706',
        info: '#0284c7',
        confirmation: '#475569'
    },
    
    // Estilos
    styles: {
        modalRadius: '12px',
        progressRadius: '16px',
        iconSize: '4rem',
        animationDuration: '0.3s'
    },
    
    // Configurações
    settings: {
        enableSounds: true,
        enableAnimations: true,
        theme: 'default', // 'default', 'dark', 'material', 'minimal'
        responsiveBreakpoints: {
            mobile: '480px',
            tablet: '768px',
            desktop: '1024px'
        }
    }
};

// Aplicar configuração
function applyFeedbackTheme(theme) {
    // Instalar com cores personalizadas
    const installer = new PLIFeedbackInstaller();
    installer.install({
        customColors: theme.colors,
        includePLIColors: false,
        debug: false
    });
    
    // Aplicar estilos personalizados
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
        #pli-feedback-modal .modal-content {
            border-radius: ${theme.styles.modalRadius} !important;
        }
        
        .progress-content {
            border-radius: ${theme.styles.progressRadius} !important;
        }
        
        .feedback-icon {
            font-size: ${theme.styles.iconSize} !important;
        }
        
        .modal-content, .progress-content {
            transition: all ${theme.styles.animationDuration} ease !important;
        }
    `;
    document.head.appendChild(styleSheet);
    
    // Aplicar tema específico
    if (theme.settings.theme !== 'default') {
        document.body.classList.add(`${theme.settings.theme}-theme`);
    }
}

// Usar configuração
applyFeedbackTheme(FeedbackTheme);
```

### 2. Integração com CSS Variables

```css
/* Definir variables CSS para fácil customização */
:root {
    /* Cores */
    --pli-feedback-primary: #1e40af;
    --pli-feedback-success: #059669;
    --pli-feedback-error: #dc2626;
    --pli-feedback-warning: #d97706;
    --pli-feedback-info: #0284c7;
    --pli-feedback-confirmation: #475569;
    
    /* Tamanhos */
    --pli-feedback-modal-radius: 12px;
    --pli-feedback-progress-radius: 16px;
    --pli-feedback-icon-size: 4rem;
    --pli-feedback-step-padding: 1rem;
    
    /* Animações */
    --pli-feedback-transition: 0.3s ease;
    --pli-feedback-animation-duration: 1.5s;
    
    /* Sombras */
    --pli-feedback-shadow-light: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    --pli-feedback-shadow-medium: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    --pli-feedback-shadow-heavy: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
}

/* Aplicar variables */
.feedback-icon.success { color: var(--pli-feedback-success) !important; }
.feedback-icon.error { color: var(--pli-feedback-error) !important; }
.feedback-icon.warning { color: var(--pli-feedback-warning) !important; }
.feedback-icon.info { color: var(--pli-feedback-info) !important; }

#pli-feedback-modal .modal-content {
    border-radius: var(--pli-feedback-modal-radius) !important;
    box-shadow: var(--pli-feedback-shadow-medium) !important;
    transition: var(--pli-feedback-transition) !important;
}

.progress-content {
    border-radius: var(--pli-feedback-progress-radius) !important;
    box-shadow: var(--pli-feedback-shadow-heavy) !important;
}

.progress-step {
    padding: var(--pli-feedback-step-padding) !important;
    transition: var(--pli-feedback-transition) !important;
}

.feedback-icon {
    font-size: var(--pli-feedback-icon-size) !important;
}

.progress-step.processing {
    animation-duration: var(--pli-feedback-animation-duration) !important;
}
```

### 3. Mudança Dinâmica de Tema

```javascript
// Função para alternar temas
function switchFeedbackTheme(themeName) {
    // Remover tema atual
    document.body.classList.remove('dark-theme', 'material-theme', 'minimal-theme');
    
    // Aplicar novo tema
    if (themeName !== 'default') {
        document.body.classList.add(`${themeName}-theme`);
    }
    
    // Salvar preferência
    localStorage.setItem('pli-feedback-theme', themeName);
    
    // Notificar mudança
    showInfo("Tema Alterado", `Tema ${themeName} aplicado com sucesso!`);
}

// Carregar tema salvo
function loadSavedTheme() {
    const savedTheme = localStorage.getItem('pli-feedback-theme') || 'default';
    switchFeedbackTheme(savedTheme);
}

// Aplicar ao carregar página
document.addEventListener('DOMContentLoaded', loadSavedTheme);
```

Este guia cobre todas as principais formas de personalizar o PLI Feedback System. Use essas técnicas para adaptar o sistema ao design único da sua aplicação.
