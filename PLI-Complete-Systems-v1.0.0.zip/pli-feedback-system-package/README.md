# 🚀 PLI Feedback System - Pacote Universal

Sistema completo de feedback e notificações para aplicações web, pronto para instalação em qualquer projeto.

## 📦 O que está incluído

```
pli-feedback-system-package/
├── 📄 pli-feedback-system.js      # Instalador universal (principal)
├── 📚 docs/                       # Documentação completa
│   ├── API.md                     # Referência da API
│   ├── CUSTOMIZATION.md           # Guia de personalização
│   └── TROUBLESHOOTING.md         # Solução de problemas
├── 🎯 examples/                   # Exemplos práticos
│   ├── basic-usage.html           # Uso básico e interativo
│   ├── advanced-progress.html     # Progress feedback avançado
│   ├── custom-styling.html        # Personalização de estilos
│   └── integration-examples.html  # Integração em sistemas
└── 📖 README.md                   # Este arquivo
```

## ⚡ Instalação Ultra-Rápida

### 1. Instalação Automática (Recomendado)

Simplesmente inclua o script no seu HTML:
```html
<!DOCTYPE html>
<html>
<head>
    <title>Meu Sistema</title>
    <!-- PLI Feedback System - Instalação Automática -->
    <script src="pli-feedback-system.js"></script>
</head>
<body>
    <!-- Seu conteúdo aqui -->
    
    <script>
        // Já pode usar o sistema imediatamente!
        showSuccess("Sistema Carregado", "PLI Feedback System ativo!");
    </script>
</body>
</html>
```

### 2. Verificação da Instalação

```javascript
// Verificar se o sistema foi instalado corretamente
if (typeof PLIFeedback !== 'undefined') {
    console.log('✅ PLI Feedback System carregado com sucesso!');
    console.log('📋 Versão:', PLIFeedback.version);
    console.log('🎯 Funções disponíveis:', Object.keys(window).filter(k => k.startsWith('show')));
} else {
    console.error('❌ Erro na instalação do PLI Feedback System');
}
```

## 🎯 Uso Básico

### Notificações Modais

```javascript
// Notificações básicas
showSuccess("Sucesso!", "Operação realizada com êxito!");
showError("Erro!", "Algo deu errado.");
showWarning("Atenção!", "Verifique as informações.");
showInfo("Informação", "Dados atualizados.");

// Com callback
showConfirm("Confirmar", "Deseja continuar?", 
    function() { console.log("Confirmado!"); },
    function() { console.log("Cancelado!"); }
);
```

### Feedback de Progresso

```javascript
// Definir etapas do processo
const steps = [
    { title: "Validando dados", description: "Verificando informações..." },
    { title: "Salvando", description: "Persistindo no banco..." },
    { title: "Enviando email", description: "Notificando usuário..." },
    { title: "Finalizando", description: "Concluindo operação..." }
];

// Iniciar processo
PLIProgress.start(steps, "Processando Formulário", "Aguarde...");
PLIProgress.begin();

// Avançar etapas (com sucesso)
setTimeout(() => PLIProgress.nextStep(), 2000);
setTimeout(() => PLIProgress.nextStep(), 4000);
setTimeout(() => PLIProgress.nextStep(), 6000);
setTimeout(() => PLIProgress.nextStep(), 8000);

// Ou reportar erro em alguma etapa
// PLIProgress.nextStep(false, "Erro na validação dos dados");
```

## 🔧 Integração em Projetos Existentes

### Formulários
```javascript
function handleSubmit(event) {
    event.preventDefault();
    
    // Iniciar feedback de progresso
    startFormProcess(); // Função helper incluída
    
    // Sua lógica de processamento aqui
    processForm()
        .then(() => {
            PLIProgress.nextStep(); // Etapa concluída
            return saveData();
        })
        .then(() => {
            PLIProgress.nextStep(); // Dados salvos
            showSuccess("Formulário Enviado", "Dados salvos com sucesso!");
        })
        .catch(error => {
            PLIProgress.nextStep(false, error.message);
        });
}
```

### APIs e Requisições
```javascript
async function callAPI(endpoint, data) {
    try {
        startApiProcess(); // Função helper incluída
        
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        PLIProgress.nextStep(); // Requisição enviada
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const result = await response.json();
        PLIProgress.nextStep(); // Resposta recebida
        
        showSuccess("API Success", "Dados processados!");
        return result;
        
    } catch (error) {
        PLIProgress.nextStep(false, `Erro: ${error.message}`);
        throw error;
    }
}
```

## 🎨 Personalização

O sistema é totalmente personalizável via CSS:

```css
/* Personalizar cores do tema */
:root {
    --pli-primary: #your-color;
    --pli-success: #your-success-color;
    --pli-error: #your-error-color;
    --pli-warning: #your-warning-color;
}

/* Personalizar modais */
.pli-modal {
    /* Seus estilos aqui */
}

/* Personalizar progress feedback */
.pli-progress {
    /* Seus estilos aqui */
}
```

## 📚 Documentação Completa

- **[API.md](docs/API.md)** - Referência completa da API com todos os métodos
- **[CUSTOMIZATION.md](docs/CUSTOMIZATION.md)** - Guia de personalização e temas
- **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** - Solução de problemas comuns

## 🎯 Exemplos Práticos

Explore os exemplos incluídos no pacote:

1. **[basic-usage.html](examples/basic-usage.html)** - Demonstração interativa de todas as funcionalidades
2. **[advanced-progress.html](examples/advanced-progress.html)** - Progress feedback avançado com métricas
3. **[custom-styling.html](examples/custom-styling.html)** - Interface para personalização de temas
4. **[integration-examples.html](examples/integration-examples.html)** - Integração em sistemas reais

## ✨ Características

### 🔄 Instalação Automática
- **Zero configuração**: Funciona imediatamente após incluir o script
- **Auto-dependências**: Carrega Bootstrap 5.1.3 e FontAwesome 6.0.0 automaticamente
- **Verificação inteligente**: Detecta se dependências já estão carregadas

### 📱 Interface Responsiva
- **Bootstrap 5**: Interface moderna e responsiva
- **FontAwesome 6**: Ícones profissionais
- **Mobile-first**: Otimizado para dispositivos móveis

### 🎯 Dual-System
- **Modal Feedbacks**: Notificações rápidas (sucesso, erro, aviso, info, confirmação)
- **Progress Feedback**: Feedback detalhado para processos longos

### 🎨 Altamente Personalizável
- **CSS customizável**: Temas e cores totalmente ajustáveis
- **Múltiplos layouts**: Diferentes estilos para diferentes necessidades
- **Flexível**: Adapta-se ao design da sua aplicação

## 🛠️ Compatibilidade

### Navegadores Suportados
- ✅ Chrome 60+
- ✅ Firefox 55+
- ✅ Safari 12+
- ✅ Edge 79+
- ✅ Opera 47+

### Frameworks Compatíveis
- ✅ Vanilla JavaScript
- ✅ jQuery
- ✅ React (via refs)
- ✅ Vue.js
- ✅ Angular
- ✅ Qualquer framework que permita HTML/JS

### Dependências
- **Bootstrap 5.1.3** (carregado automaticamente via CDN)
- **FontAwesome 6.0.0** (carregado automaticamente via CDN)
- **Navegador moderno com suporte a ES6**

## 🚀 Performance

- **Tamanho mínimo**: ~15KB minificado
- **Carregamento assíncrono**: Não bloqueia o carregamento da página
- **CDN otimizado**: Dependências carregadas de CDNs rápidos
- **Cache-friendly**: Recursos são cacheados pelo navegador

## 🔧 Configurações Avançadas

### Desabilitar Carregamento Automático
```javascript
// Desabilitar carregamento automático do Bootstrap
window.PLI_SKIP_BOOTSTRAP = true;

// Desabilitar carregamento automático do FontAwesome
window.PLI_SKIP_FONTAWESOME = true;

// Incluir o script após definir as variáveis
```

### Configuração Manual
```javascript
// Instalar manualmente (se necessário)
const installer = new PLIFeedbackInstaller();
installer.install().then(() => {
    console.log('Sistema instalado manualmente!');
});
```

## 🐛 Solução de Problemas

### Problema: "PLIFeedback is not defined"
**Solução**: Aguarde o carregamento completo do script ou use:
```javascript
window.addEventListener('load', function() {
    // Seu código aqui
    showSuccess("Carregado!", "Sistema pronto para uso!");
});
```

### Problema: Estilos não aplicados
**Solução**: Verifique se o Bootstrap foi carregado:
```javascript
if (typeof bootstrap !== 'undefined') {
    console.log('Bootstrap carregado com sucesso!');
} else {
    console.error('Bootstrap não foi carregado');
}
```

### Mais soluções
Consulte [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) para problemas específicos.

## 📄 Licença

Este sistema foi extraído e adaptado do projeto PLI Cadastros e está disponível para uso em qualquer projeto.

## 🤝 Contribuições

Para melhorias ou sugestões, consulte a documentação ou implemente suas personalizações usando as opções de customização disponíveis.

## 📞 Suporte

Para dúvidas sobre implementação, consulte:
1. [Documentação da API](docs/API.md)
2. [Exemplos práticos](examples/)
3. [Guia de solução de problemas](docs/TROUBLESHOOTING.md)

---

## 🎉 Quick Start - 30 segundos!

1. **Baixe** o arquivo `pli-feedback-system.js`
2. **Inclua** no seu HTML: `<script src="pli-feedback-system.js"></script>`
3. **Use**: `showSuccess("Funcionou!", "Sistema instalado com sucesso!");`

**É isso!** Seu sistema de feedback está pronto para uso. 🚀

---

*PLI Feedback System - Transformando feedback de usuário em experiências excepcionais* ✨
        showSuccess("Sistema Carregado", "PLI Feedback System ativo!");
    </script>
</body>
</html>
```

### Opção 2: Instalação Manual
```javascript
// Criar e instalar manualmente
const installer = new PLIFeedbackInstaller();
installer.install({
    debug: true,
    includePLIColors: true,
    customColors: {
        primary: '#your-color',
        success: '#your-success-color'
    }
});
```

## 📋 Recursos Inclusos

### ✅ Modal Feedbacks
- **Success**: Operações bem-sucedidas
- **Error**: Tratamento de erros
- **Warning**: Avisos importantes
- **Info**: Informações gerais
- **Confirmation**: Diálogos de confirmação

### ⏳ Progress Feedback
- Feedback visual para processos em etapas
- Animações suaves
- Estados customizáveis (pendente, processando, concluído, erro)
- Templates pré-definidos para login e cadastro

### 🎨 Estilização
- Design moderno e responsivo
- Cores padronizadas PLI
- Suporte a cores customizadas
- Animações suaves
- Ícones FontAwesome integrados

### 🔧 Dependências Automáticas
- **Bootstrap 5.1.3**: Framework CSS
- **FontAwesome 6.0.0**: Ícones
- Carregamento automático via CDN
- Verificação de dependências

## 📚 Exemplos de Uso

### Modal Feedbacks Básicos
```javascript
// Sucesso
showSuccess("Dados Salvos", "Informações salvas com sucesso!");

// Erro
showError("Falha na Conexão", "Não foi possível conectar ao servidor.");

// Aviso
showWarning("Atenção", "Verifique os dados antes de continuar.");

// Informação
showInfo("Nova Versão", "Sistema atualizado para v2.0.0");
```

### Confirmações com Ações
```javascript
showConfirm(
    "Confirmar Exclusão",
    "Tem certeza que deseja excluir este item?",
    function() {
        // Usuário confirmou
        console.log("Item excluído");
        showSuccess("Excluído", "Item removido com sucesso!");
    },
    function() {
        // Usuário cancelou
        console.log("Operação cancelada");
    }
);
```

### Progress Feedback - Login Pré-definido
```javascript
// Iniciar processo de login
startLoginProcess();

// Simular etapas
setTimeout(() => PLIProgress.nextStep(), 1000);  // Validando credenciais
setTimeout(() => PLIProgress.nextStep(), 2000);  // Carregando permissões
setTimeout(() => PLIProgress.nextStep(), 3000);  // Preparando dashboard
setTimeout(() => PLIProgress.nextStep(), 4000);  // Finalizando login
```

### Progress Feedback Customizado
```javascript
// Definir etapas personalizadas
const steps = [
    { title: "Processando arquivo", description: "Analisando dados enviados..." },
    { title: "Validando informações", description: "Verificando integridade dos dados..." },
    { title: "Salvando no banco", description: "Persistindo informações..." },
    { title: "Finalizando", description: "Concluindo operação..." }
];

// Iniciar processo
PLIProgress.start(steps, "Importação de Dados", "Processando arquivo enviado");
PLIProgress.begin();

// Avançar etapas
setTimeout(() => PLIProgress.nextStep(), 2000);
setTimeout(() => PLIProgress.nextStep(), 4000);
setTimeout(() => PLIProgress.nextStep(), 6000);
setTimeout(() => PLIProgress.nextStep(), 8000);
```

### Tratamento de Erros no Progress
```javascript
PLIProgress.start(steps, "Processando Dados");
PLIProgress.begin();

// Etapa com sucesso
setTimeout(() => PLIProgress.nextStep(true), 2000);

// Etapa com erro
setTimeout(() => {
    PLIProgress.nextStep(false, "Erro: Conexão perdida com o servidor");
}, 4000);
```

## ⚙️ Configuração Avançada

### Personalização de Cores
```javascript
const installer = new PLIFeedbackInstaller();
installer.install({
    customColors: {
        primary: '#1a365d',      // Cor primária
        success: '#2d7d32',      // Verde sucesso
        error: '#c62828',        // Vermelho erro
        warning: '#f57c00',      // Laranja aviso
        info: '#1976d2',         // Azul informação
        confirmation: '#455a64'  // Cinza confirmação
    },
    includePLIColors: false,     // Desabilitar cores PLI
    debug: true                  // Ativar logs debug
});
```

### Verificação de Instalação
```javascript
// Verificar se sistema está ativo
if (window.PLIFeedback) {
    console.log("✅ PLI Feedback System ativo");
    
    // Testar funcionalidades
    showInfo("Sistema Ativo", "Todas as funcionalidades disponíveis!");
} else {
    console.log("❌ Sistema não instalado");
}
```

## 🌐 Métodos Disponíveis

### Modal Feedbacks
| Método | Descrição | Parâmetros |
|--------|-----------|------------|
| `showSuccess(title, message, options)` | Modal de sucesso | título, mensagem, opções |
| `showError(title, message, options)` | Modal de erro | título, mensagem, opções |
| `showWarning(title, message, options)` | Modal de aviso | título, mensagem, opções |
| `showInfo(title, message, options)` | Modal informativo | título, mensagem, opções |
| `showConfirm(title, message, onConfirm, onCancel)` | Modal de confirmação | título, mensagem, callbacks |
| `showToast(message, type)` | Compatibilidade com toast | mensagem, tipo |

### Progress Feedback
| Método | Descrição | Parâmetros |
|--------|-----------|------------|
| `PLIProgress.start(steps, title, subtitle)` | Iniciar processo | etapas, título, subtítulo |
| `PLIProgress.begin()` | Começar primeira etapa | - |
| `PLIProgress.nextStep(success, errorMsg)` | Avançar etapa | sucesso, mensagem erro |
| `PLIProgress.reset()` | Resetar processo | - |
| `PLIProgress.hideOverlay()` | Fechar overlay | - |

### Processos Pré-definidos
| Método | Descrição |
|--------|-----------|
| `startLoginProcess()` | Processo padrão de login |
| `startCadastroProcess()` | Processo padrão de cadastro |

## 🔧 Estrutura de Arquivos

```
pli-feedback-system-package/
├── pli-feedback-system.js          # Instalador principal
├── README.md                       # Este arquivo
├── docs/
│   ├── API.md                     # Documentação completa da API
│   ├── CUSTOMIZATION.md           # Guia de personalização
│   └── TROUBLESHOOTING.md         # Resolução de problemas
└── examples/
    ├── basic-usage.html           # Exemplo básico
    ├── advanced-progress.html     # Progress avançado
    ├── custom-styling.html        # Personalização
    └── integration-examples.html  # Exemplos de integração
```

## 📱 Compatibilidade

- ✅ **Navegadores**: Chrome, Firefox, Safari, Edge (versões modernas)
- ✅ **Frameworks**: Vanilla JS, jQuery, React, Vue, Angular
- ✅ **Bootstrap**: Compatível com Bootstrap 5+
- ✅ **Responsivo**: Funciona em desktop e mobile

## 🆘 Resolução de Problemas

### Sistema não carrega
1. Verificar se arquivo está sendo carregado corretamente
2. Verificar console do navegador para erros
3. Testar com `window.PLIFeedbackInstaller`

### Estilos não aplicados
1. Verificar se Bootstrap está carregando
2. Verificar conflitos CSS
3. Verificar se FontAwesome está disponível

### Debug Mode
```javascript
const installer = new PLIFeedbackInstaller();
installer.install({ debug: true }); // Ativa logs detalhados
```

## 📄 Licença

MIT License - Use livremente em seus projetos.

## 👥 Suporte

Para dúvidas ou problemas:
1. Verificar exemplos na pasta `examples/`
2. Consultar documentação em `docs/`
3. Ativar modo debug para diagnóstico

---

**PLI Feedback System v1.0.0** - Sistema profissional de feedback para aplicações web.
