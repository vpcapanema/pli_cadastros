# PLI Feedback System - Resolução de Problemas

## 🔧 Diagnóstico e Soluções

Este guia ajuda a identificar e resolver os problemas mais comuns do PLI Feedback System.

## 🚨 Problemas de Instalação

### ❌ Sistema não carrega

**Sintomas:**
- Nenhuma função do feedback funciona
- `window.PLIFeedback` é undefined
- Console mostra erros de script

**Diagnóstico:**
```javascript
// Verificar se o arquivo foi carregado
console.log('Instalador disponível:', typeof PLIFeedbackInstaller !== 'undefined');
console.log('Sistema instalado:', typeof PLIFeedback !== 'undefined');
console.log('Progress disponível:', typeof PLIProgress !== 'undefined');
```

**Soluções:**

1. **Verificar caminho do arquivo:**
```html
<!-- Verificar se o caminho está correto -->
<script src="./pli-feedback-system.js"></script>
<!-- ou -->
<script src="/js/pli-feedback-system.js"></script>
```

2. **Verificar erros no console:**
```javascript
// Ativar debug para ver detalhes
const installer = new PLIFeedbackInstaller();
installer.install({ debug: true });
```

3. **Instalação manual:**
```javascript
// Se auto-instalação falhar, instalar manualmente
document.addEventListener('DOMContentLoaded', function() {
    if (typeof PLIFeedbackInstaller !== 'undefined') {
        const installer = new PLIFeedbackInstaller();
        installer.install({ debug: true });
    } else {
        console.error('PLIFeedbackInstaller não encontrado');
    }
});
```

### ❌ Dependências não carregam

**Sintomas:**
- Bootstrap não funciona
- Ícones não aparecem
- Estilos não aplicados

**Diagnóstico:**
```javascript
// Verificar dependências
console.log('Bootstrap disponível:', typeof bootstrap !== 'undefined');
console.log('Bootstrap CSS:', !!document.getElementById('pli-bootstrap-css'));
console.log('FontAwesome CSS:', !!document.getElementById('pli-fontawesome-css'));
```

**Soluções:**

1. **Aguardar carregamento:**
```javascript
// Aguardar dependências carregarem
setTimeout(() => {
    if (typeof bootstrap === 'undefined') {
        console.warn('Bootstrap ainda não carregou, tentando novamente...');
        // Recarregar ou usar fallback
    }
}, 2000);
```

2. **CDN alternativo:**
```javascript
// Modificar URLs de CDN se necessário
const installer = new PLIFeedbackInstaller();
installer.dependencies = {
    bootstrap: {
        css: 'https://unpkg.com/bootstrap@5.1.3/dist/css/bootstrap.min.css',
        js: 'https://unpkg.com/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'
    },
    fontawesome: {
        css: 'https://use.fontawesome.com/releases/v6.0.0/css/all.css'
    }
};
installer.install();
```

3. **Verificar bloqueadores:**
```javascript
// Verificar se há bloqueadores de conteúdo
if (!document.getElementById('pli-bootstrap-css')) {
    console.warn('CSS do Bootstrap pode estar sendo bloqueado');
    // Implementar fallback local
}
```

## 🎯 Problemas de Modal

### ❌ Modal não abre

**Sintomas:**
- `showSuccess()`, `showError()` não fazem nada
- Modal não aparece na tela
- Nenhum erro no console

**Diagnóstico:**
```javascript
// Verificar estrutura do modal
console.log('Modal existe:', !!document.getElementById('pli-feedback-modal'));
console.log('Bootstrap Modal:', typeof bootstrap !== 'undefined' && typeof bootstrap.Modal !== 'undefined');

// Testar manualmente
try {
    showSuccess("Teste", "Testando modal");
} catch (error) {
    console.error('Erro ao abrir modal:', error);
}
```

**Soluções:**

1. **Recriar estrutura do modal:**
```javascript
// Remover e recriar modal
const existingModal = document.getElementById('pli-feedback-modal');
if (existingModal) {
    existingModal.remove();
}

// Recriar
PLIFeedback.createModalStructure();
```

2. **Usar Bootstrap diretamente:**
```javascript
// Testar Bootstrap diretamente
const modal = new bootstrap.Modal(document.getElementById('pli-feedback-modal'));
modal.show();
```

3. **Verificar z-index:**
```css
/* Ajustar z-index se modal ficar atrás de outros elementos */
#pli-feedback-modal {
    z-index: 9999 !important;
}
```

### ❌ Modal abre mas não fecha

**Sintomas:**
- Modal abre normalmente
- Botões não fecham o modal
- Background não fecha modal

**Soluções:**

1. **Verificar atributos dos botões:**
```javascript
// Verificar se botões têm data-bs-dismiss
const buttons = document.querySelectorAll('#pli-feedback-modal .btn');
buttons.forEach(btn => {
    if (!btn.hasAttribute('data-bs-dismiss')) {
        btn.setAttribute('data-bs-dismiss', 'modal');
    }
});
```

2. **Fechar programaticamente:**
```javascript
// Função para fechar modal manualmente
function closeModal() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('pli-feedback-modal'));
    if (modal) {
        modal.hide();
    }
}
```

## ⏳ Problemas de Progress

### ❌ Progress overlay não aparece

**Sintomas:**
- `PLIProgress.start()` não mostra overlay
- Tela fica normal sem indicação de progresso

**Diagnóstico:**
```javascript
// Verificar overlay
console.log('Progress overlay:', document.getElementById('pli-progress-overlay'));
console.log('Progress instance:', PLIProgress);

// Testar
PLIProgress.start([{title: "Teste", description: "Testando..."}], "Teste", "Teste");
PLIProgress.begin();
```

**Soluções:**

1. **Verificar z-index:**
```css
.progress-overlay {
    z-index: 10000 !important;
    position: fixed !important;
}
```

2. **Verificar estilos:**
```javascript
// Verificar se estilos foram aplicados
const styles = document.getElementById('pli-feedback-styles');
console.log('Estilos PLI carregados:', !!styles);
```

3. **Recriar overlay:**
```javascript
// Remover overlay existente e recriar
if (PLIProgress.overlay) {
    PLIProgress.overlay.remove();
    PLIProgress.overlay = null;
}

// Reiniciar progresso
PLIProgress.start(steps, title, subtitle);
```

### ❌ Steps não avançam

**Sintomas:**
- `PLIProgress.nextStep()` não funciona
- Steps ficam no estado pending

**Soluções:**

1. **Verificar índice atual:**
```javascript
// Debug do progresso
console.log('Step atual:', PLIProgress.currentStepIndex);
console.log('Total steps:', PLIProgress.currentSteps.length);
console.log('Steps:', PLIProgress.currentSteps);
```

2. **Reset e restart:**
```javascript
// Resetar progresso
PLIProgress.reset();
PLIProgress.currentStepIndex = 0;
PLIProgress.begin();
```

3. **Avançar manualmente:**
```javascript
// Avançar step por step manualmente
function debugNextStep() {
    console.log('Avançando step:', PLIProgress.currentStepIndex);
    PLIProgress.nextStep();
    console.log('Novo step:', PLIProgress.currentStepIndex);
}
```

## 🎨 Problemas de Estilização

### ❌ Estilos não aplicados

**Sintomas:**
- Modal e progress aparecem sem estilo
- Cores padrão do browser
- Layout quebrado

**Diagnóstico:**
```javascript
// Verificar estilos
const pliStyles = document.getElementById('pli-feedback-styles');
const bootstrapStyles = document.getElementById('pli-bootstrap-css');
const fontawesomeStyles = document.getElementById('pli-fontawesome-css');

console.log('PLI Styles:', !!pliStyles);
console.log('Bootstrap Styles:', !!bootstrapStyles);
console.log('FontAwesome Styles:', !!fontawesomeStyles);
```

**Soluções:**

1. **Recriar estilos:**
```javascript
// Remover e recriar estilos
const existingStyles = document.getElementById('pli-feedback-styles');
if (existingStyles) {
    existingStyles.remove();
}

// Reinstalar sistema
const installer = new PLIFeedbackInstaller();
installer.installStyles();
```

2. **Verificar conflitos CSS:**
```css
/* Usar !important para sobrescrever conflitos */
#pli-feedback-modal .modal-content {
    border-radius: 12px !important;
    border: none !important;
}

.progress-overlay {
    background: rgba(0, 0, 0, 0.5) !important;
    position: fixed !important;
}
```

3. **Aplicar estilos inline:**
```javascript
// Aplicar estilos críticos via JavaScript
function applyEmergencyStyles() {
    const modal = document.getElementById('pli-feedback-modal');
    if (modal) {
        modal.style.zIndex = '9999';
        const content = modal.querySelector('.modal-content');
        if (content) {
            content.style.borderRadius = '12px';
            content.style.border = 'none';
        }
    }
}
```

### ❌ Ícones não aparecem

**Sintomas:**
- Quadrados ou símbolos estranhos no lugar dos ícones
- Ícones FontAwesome não carregam

**Soluções:**

1. **Verificar FontAwesome:**
```javascript
// Verificar se FontAwesome carregou
const faTest = document.createElement('i');
faTest.className = 'fas fa-check';
document.body.appendChild(faTest);
const computedStyle = window.getComputedStyle(faTest, ':before');
console.log('FontAwesome funcionando:', computedStyle.content !== 'none');
document.body.removeChild(faTest);
```

2. **CDN alternativo:**
```javascript
// Usar CDN alternativo
const faLink = document.createElement('link');
faLink.rel = 'stylesheet';
faLink.href = 'https://use.fontawesome.com/releases/v6.0.0/css/all.css';
document.head.appendChild(faLink);
```

3. **Fallback sem ícones:**
```css
/* Fallback para quando ícones não carregam */
.feedback-icon::before {
    content: "●";
    font-size: 4rem;
    display: block;
}

.step-icon::before {
    content: "○";
    font-size: 1.5rem;
    display: block;
}
```

## 📱 Problemas de Responsividade

### ❌ Modal muito grande em mobile

**Sintomas:**
- Modal corta na tela em dispositivos móveis
- Texto muito pequeno ou muito grande

**Soluções:**

1. **CSS responsivo:**
```css
@media (max-width: 480px) {
    #pli-feedback-modal .modal-dialog {
        margin: 1rem !important;
        max-width: calc(100% - 2rem) !important;
    }
    
    .feedback-icon {
        font-size: 3rem !important;
    }
    
    #pli-feedback-modal h4 {
        font-size: 1.2rem !important;
    }
}
```

2. **Viewport meta tag:**
```html
<!-- Verificar se existe -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

### ❌ Progress overlay não cobre tela toda

**Soluções:**

```css
.progress-overlay {
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    z-index: 10000 !important;
}
```

## 🌐 Problemas de Compatibilidade

### ❌ Conflito com outros frameworks

**Sintomas:**
- Outros modais param de funcionar
- Estilos sobrescritos
- JavaScript conflitos

**Soluções:**

1. **Namespace específico:**
```css
/* Usar seletores mais específicos */
#pli-feedback-modal.pli-namespace .modal-content {
    /* estilos específicos */
}
```

2. **Isolar Bootstrap:**
```javascript
// Salvar referência do Bootstrap original
const originalBootstrap = window.bootstrap;

// Usar namespace para PLI
window.pliBootstrap = window.bootstrap;
```

3. **Carregar sem conflitos:**
```javascript
// Instalar sem incluir PLI colors
const installer = new PLIFeedbackInstaller();
installer.install({
    includePLIColors: false,
    customColors: null
});
```

### ❌ Problemas com jQuery

**Sintomas:**
- Conflitos entre jQuery e Bootstrap
- $ não definido

**Soluções:**

```javascript
// Verificar jQuery
if (typeof $ === 'undefined' && typeof jQuery !== 'undefined') {
    window.$ = jQuery;
}

// Usar versão standalone do Bootstrap
// (Bootstrap 5 não requer jQuery)
```

## 🔍 Ferramentas de Debug

### Debug Completo

```javascript
function debugPLISystem() {
    console.group('PLI Feedback System Debug');
    
    // Verificar instalação
    console.log('✓ Verificando instalação...');
    console.log('Instalador:', typeof PLIFeedbackInstaller !== 'undefined');
    console.log('Sistema:', typeof PLIFeedback !== 'undefined');
    console.log('Progress:', typeof PLIProgress !== 'undefined');
    console.log('Bootstrap:', typeof bootstrap !== 'undefined');
    
    // Verificar elementos DOM
    console.log('\n✓ Verificando DOM...');
    console.log('Modal estrutura:', !!document.getElementById('pli-feedback-modal'));
    console.log('Progress overlay:', !!document.getElementById('pli-progress-overlay'));
    
    // Verificar estilos
    console.log('\n✓ Verificando estilos...');
    console.log('PLI Styles:', !!document.getElementById('pli-feedback-styles'));
    console.log('Bootstrap CSS:', !!document.getElementById('pli-bootstrap-css'));
    console.log('FontAwesome CSS:', !!document.getElementById('pli-fontawesome-css'));
    
    // Verificar funções globais
    console.log('\n✓ Verificando funções globais...');
    console.log('showSuccess:', typeof showSuccess !== 'undefined');
    console.log('showError:', typeof showError !== 'undefined');
    console.log('showWarning:', typeof showWarning !== 'undefined');
    console.log('showInfo:', typeof showInfo !== 'undefined');
    console.log('showConfirm:', typeof showConfirm !== 'undefined');
    
    // Teste funcional
    console.log('\n✓ Teste funcional...');
    try {
        showInfo("Debug", "Sistema funcionando corretamente!");
        console.log('Teste modal: ✅ OK');
    } catch (error) {
        console.log('Teste modal: ❌ ERRO -', error.message);
    }
    
    console.groupEnd();
}

// Executar debug
debugPLISystem();
```

### Monitor de Performance

```javascript
function monitorPLIPerformance() {
    const observer = new PerformanceObserver((list) => {
        list.getEntries().forEach((entry) => {
            if (entry.name.includes('pli-feedback')) {
                console.log(`PLI Resource: ${entry.name} - ${entry.duration}ms`);
            }
        });
    });
    
    observer.observe({entryTypes: ['resource', 'navigation']});
}

// Ativar monitoramento
monitorPLIPerformance();
```

### Reset Completo

```javascript
function resetPLISystem() {
    console.log('🔄 Resetando PLI Feedback System...');
    
    // Remover elementos DOM
    const elementsToRemove = [
        '#pli-feedback-modal',
        '#pli-progress-overlay', 
        '#pli-feedback-styles',
        '#pli-bootstrap-css',
        '#pli-fontawesome-css',
        '#pli-bootstrap-js'
    ];
    
    elementsToRemove.forEach(selector => {
        const element = document.querySelector(selector);
        if (element) {
            element.remove();
            console.log('Removido:', selector);
        }
    });
    
    // Limpar variáveis globais
    delete window.PLIFeedback;
    delete window.PLIProgress;
    delete window.showSuccess;
    delete window.showError;
    delete window.showWarning;
    delete window.showInfo;
    delete window.showConfirm;
    delete window.showToast;
    
    console.log('✅ Sistema resetado. Reinstale com:');
    console.log('const installer = new PLIFeedbackInstaller();');
    console.log('installer.install({ debug: true });');
}
```

## 📞 Suporte Adicional

### Informações para Suporte

Ao reportar problemas, inclua:

1. **Versão do sistema:** `console.log(new PLIFeedbackInstaller().version)`
2. **Navegador e versão:** `navigator.userAgent`
3. **Dependências carregadas:** Resultado do `debugPLISystem()`
4. **Console errors:** Screenshots ou texto dos erros
5. **Código que falha:** Exemplo mínimo que reproduz o problema

### Testes Mínimos

```html
<!DOCTYPE html>
<html>
<head>
    <title>PLI Feedback Test</title>
    <script src="pli-feedback-system.js"></script>
</head>
<body>
    <h1>Teste PLI Feedback</h1>
    <button onclick="showSuccess('Teste', 'Funcionando!')">Testar</button>
    
    <script>
        // Debug automático após carregar
        setTimeout(() => {
            debugPLISystem();
        }, 2000);
    </script>
</body>
</html>
```

Use este guia para diagnosticar e resolver a maioria dos problemas do PLI Feedback System.
