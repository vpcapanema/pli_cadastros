# PLI Feedback System - Documentação da API

## 📖 Referência Completa da API

### 🚀 Instalador Principal

#### `PLIFeedbackInstaller`

##### Constructor
```javascript
const installer = new PLIFeedbackInstaller();
```

##### Métodos

###### `install(options)`
Instala o sistema completo de feedback.

**Parâmetros:**
```javascript
{
    autoInstall: true,           // Auto-instalação (padrão: true)
    includePLIColors: true,      // Incluir cores PLI (padrão: true)
    customColors: null,          // Cores customizadas (opcional)
    language: 'pt-br',          // Idioma (padrão: pt-br)
    debug: false                 // Modo debug (padrão: false)
}
```

**Exemplo:**
```javascript
const installer = new PLIFeedbackInstaller();
await installer.install({
    debug: true,
    customColors: {
        primary: '#1a365d',
        success: '#2d7d32',
        error: '#c62828'
    }
});
```

---

### 🎯 Modal Feedbacks

#### `PLIFeedback` (Instância Global)

##### Métodos Principais

###### `success(title, message, options)`
Exibe modal de sucesso.

**Parâmetros:**
- `title` (string): Título do modal
- `message` (string): Mensagem do modal
- `options` (object, opcional): Configurações adicionais

**Exemplo:**
```javascript
PLIFeedback.success("Dados Salvos", "Informações salvas com sucesso!");

// Com opções customizadas
PLIFeedback.success("Operação Concluída", "Processo finalizado.", {
    buttons: [
        { text: "Continuar", icon: "fas fa-arrow-right", onclick: "nextStep()" },
        { text: "Fechar", icon: "fas fa-times" }
    ]
});
```

###### `error(title, message, options)`
Exibe modal de erro.

**Exemplo:**
```javascript
PLIFeedback.error("Erro na Conexão", "Não foi possível conectar ao servidor.");
```

###### `warning(title, message, options)`
Exibe modal de aviso.

**Exemplo:**
```javascript
PLIFeedback.warning("Atenção", "Dados podem ser perdidos se continuar.");
```

###### `info(title, message, options)`
Exibe modal informativo.

**Exemplo:**
```javascript
PLIFeedback.info("Nova Versão", "Sistema atualizado para v2.0.0");
```

###### `confirm(title, message, onConfirm, onCancel)`
Exibe modal de confirmação.

**Parâmetros:**
- `title` (string): Título do modal
- `message` (string): Mensagem do modal
- `onConfirm` (function): Callback para confirmação
- `onCancel` (function, opcional): Callback para cancelamento

**Exemplo:**
```javascript
PLIFeedback.confirm(
    "Confirmar Exclusão",
    "Tem certeza que deseja excluir este item?",
    function() {
        console.log("Usuário confirmou");
        deleteItem();
    },
    function() {
        console.log("Usuário cancelou");
    }
);
```

##### Opções Avançadas do Modal

**Estrutura do objeto `options`:**
```javascript
{
    buttons: [
        {
            text: "Texto do Botão",      // Texto exibido
            icon: "fas fa-check",        // Classe do ícone (opcional)
            onclick: "function()",       // Função a executar (opcional)
            dismiss: true                // Fechar modal ao clicar (padrão: true)
        }
    ]
}
```

**Exemplo completo:**
```javascript
PLIFeedback.success("Upload Concluído", "Arquivo enviado com sucesso!", {
    buttons: [
        { 
            text: "Ver Arquivo", 
            icon: "fas fa-eye", 
            onclick: "viewFile()", 
            dismiss: true 
        },
        { 
            text: "Enviar Outro", 
            icon: "fas fa-upload", 
            onclick: "uploadAnother()", 
            dismiss: true 
        },
        { 
            text: "Fechar", 
            icon: "fas fa-times" 
        }
    ]
});
```

---

### ⏳ Progress Feedback

#### `PLIProgress` (Instância Global)

##### Métodos Principais

###### `start(steps, title, subtitle)`
Inicia um processo de feedback de progresso.

**Parâmetros:**
- `steps` (array): Array de objetos com as etapas
- `title` (string): Título do processo
- `subtitle` (string): Subtítulo/descrição

**Estrutura de uma etapa:**
```javascript
{
    title: "Nome da Etapa",           // Título da etapa
    description: "Descrição detalhada" // Descrição do que está acontecendo
}
```

**Exemplo:**
```javascript
const steps = [
    { title: "Validando dados", description: "Verificando informações fornecidas..." },
    { title: "Processando arquivo", description: "Analisando conteúdo do arquivo..." },
    { title: "Salvando informações", description: "Persistindo dados no banco..." },
    { title: "Finalizando", description: "Concluindo operação..." }
];

PLIProgress.start(steps, "Processamento de Dados", "Aguarde enquanto processamos suas informações");
```

###### `begin()`
Inicia a primeira etapa do processo.

**Exemplo:**
```javascript
PLIProgress.start(steps, "Título", "Subtítulo");
PLIProgress.begin(); // Inicia primeira etapa
```

###### `nextStep(success, errorMessage)`
Avança para a próxima etapa.

**Parâmetros:**
- `success` (boolean, padrão: true): Se a etapa foi bem-sucedida
- `errorMessage` (string, opcional): Mensagem de erro caso `success` seja false

**Exemplos:**
```javascript
// Etapa bem-sucedida
PLIProgress.nextStep();
// ou
PLIProgress.nextStep(true);

// Etapa com erro
PLIProgress.nextStep(false, "Erro: Falha na conexão com o banco de dados");
```

###### `reset()`
Reinicia o processo, voltando todas as etapas ao estado inicial.

**Exemplo:**
```javascript
PLIProgress.reset();
PLIProgress.begin(); // Reiniciar processo
```

###### `hideOverlay()`
Fecha o overlay de progresso manualmente.

**Exemplo:**
```javascript
PLIProgress.hideOverlay();
```

##### Estados das Etapas

| Estado | Classe CSS | Ícone | Descrição |
|--------|------------|-------|-----------|
| `pending` | `.pending` | `fa-circle` | Etapa aguardando |
| `processing` | `.processing` | `fa-spinner fa-spin` | Etapa em andamento |
| `completed` | `.completed` | `fa-check-circle` | Etapa concluída |
| `error` | `.error` | `fa-times-circle` | Etapa com erro |

---

### 🌐 Funções Globais de Conveniência

#### Modal Feedbacks Globais

```javascript
// Funções diretas (sem instância)
showSuccess(title, message, options)
showError(title, message, options)  
showWarning(title, message, options)
showInfo(title, message, options)
showConfirm(title, message, onConfirm, onCancel)
```

#### Compatibilidade Toast

```javascript
showToast(message, type)
```

**Parâmetros:**
- `message` (string): Mensagem a exibir
- `type` (string): Tipo do toast ('success', 'error', 'warning', 'info')

**Exemplo:**
```javascript
showToast("Operação realizada com sucesso!", "success");
showToast("Erro na operação", "error");
```

---

### 🎨 Processos Pré-definidos

#### `startLoginProcess()`
Inicia processo padrão de login com 4 etapas.

**Etapas incluídas:**
1. Validando credenciais
2. Carregando permissões
3. Preparando dashboard
4. Finalizando login

**Exemplo de uso completo:**
```javascript
// Iniciar processo
startLoginProcess();

// Simular etapas
setTimeout(() => PLIProgress.nextStep(), 1000);   // Credenciais OK
setTimeout(() => PLIProgress.nextStep(), 2500);   // Permissões carregadas
setTimeout(() => PLIProgress.nextStep(), 4000);   // Dashboard pronto
setTimeout(() => PLIProgress.nextStep(), 5500);   // Login finalizado
```

#### `startCadastroProcess()`
Inicia processo padrão de cadastro com 4 etapas.

**Etapas incluídas:**
1. Validando dados
2. Salvando no banco
3. Enviando notificações
4. Finalizando cadastro

**Exemplo de uso completo:**
```javascript
// Iniciar processo
startCadastroProcess();

// Simular progresso
setTimeout(() => PLIProgress.nextStep(), 1500);   // Dados validados
setTimeout(() => PLIProgress.nextStep(), 3000);   // Salvos no banco
setTimeout(() => PLIProgress.nextStep(), 4500);   // Notificações enviadas
setTimeout(() => PLIProgress.nextStep(), 6000);   // Cadastro finalizado
```

---

### 🔧 Configuração e Personalização

#### Cores Customizadas

**Cores suportadas:**
```javascript
const customColors = {
    primary: '#0f203e',      // Cor primária (títulos, bordas)
    success: '#28a745',      // Verde (sucesso)
    error: '#dc3545',        // Vermelho (erro)
    warning: '#ffc107',      // Amarelo (aviso)
    info: '#17a2b8',         // Azul (informação)
    confirmation: '#6c757d'  // Cinza (confirmação)
};
```

#### Aplicação de Cores

```javascript
const installer = new PLIFeedbackInstaller();
installer.install({
    customColors: customColors,
    includePLIColors: false  // Desabilita cores PLI padrão
});
```

#### Variáveis CSS PLI (quando includePLIColors: true)

```css
:root {
    --pli-azul-escuro: #0f203e;
    --pli-azul-medio: #1e3a8a;
    --pli-azul-claro: #3b82f6;
    --pli-cinza-escuro: #374151;
    --pli-cinza-medio: #6b7280;
    --pli-cinza-claro: #d1d5db;
}

/* Classes utilitárias */
.text-pli-dark { color: var(--pli-azul-escuro) !important; }
.bg-pli-dark { background-color: var(--pli-azul-escuro) !important; }
.pli-card { /* Estilo de card PLI */ }
```

---

### 🔍 Verificação e Debug

#### Verificação de Instalação

```javascript
// Verificar se sistema está ativo
if (window.PLIFeedback && window.PLIProgress) {
    console.log("✅ Sistema PLI ativo");
} else {
    console.log("❌ Sistema não instalado");
}

// Verificar componentes específicos
const checks = {
    installer: !!window.PLIFeedbackInstaller,
    feedback: !!window.PLIFeedback,
    progress: !!window.PLIProgress,
    bootstrap: !!window.bootstrap,
    modal: !!document.getElementById('pli-feedback-modal')
};

console.table(checks);
```

#### Modo Debug

**Ativar debug:**
```javascript
const installer = new PLIFeedbackInstaller();
installer.install({ debug: true });
```

**Logs de debug incluem:**
- Status de carregamento de dependências
- Criação de elementos DOM
- Verificação de instalação
- Erros de execução

---

### ⚠️ Tratamento de Erros

#### Erros Comuns e Soluções

1. **Sistema não carrega**
```javascript
// Verificar se arquivo foi carregado
if (typeof PLIFeedbackInstaller === 'undefined') {
    console.error('Arquivo pli-feedback-system.js não carregado');
}
```

2. **Bootstrap não encontrado**
```javascript
// O sistema carrega automaticamente, mas você pode verificar
if (!window.bootstrap) {
    console.warn('Bootstrap não disponível - aguarde carregamento');
}
```

3. **Conflitos CSS**
```javascript
// Desabilitar cores PLI se necessário
installer.install({ includePLIColors: false });
```

---

### 📋 Eventos e Callbacks

#### Eventos de Modal

```javascript
// Modal foi mostrado
document.getElementById('pli-feedback-modal').addEventListener('shown.bs.modal', function() {
    console.log('Modal exibido');
});

// Modal foi fechado
document.getElementById('pli-feedback-modal').addEventListener('hidden.bs.modal', function() {
    console.log('Modal fechado');
});
```

#### Callbacks de Progress

```javascript
// Processo customizado com callbacks
const steps = [
    { title: "Etapa 1", description: "Descrição..." },
    { title: "Etapa 2", description: "Descrição..." }
];

PLIProgress.start(steps, "Processo", "Aguarde...");
PLIProgress.begin();

// Primeira etapa
setTimeout(() => {
    PLIProgress.nextStep();
    console.log("Etapa 1 concluída");
}, 2000);

// Segunda etapa
setTimeout(() => {
    PLIProgress.nextStep();
    console.log("Processo finalizado");
    
    // Executar ação após conclusão
    showSuccess("Concluído", "Processo finalizado com sucesso!");
}, 4000);
```

---

### 📱 Responsividade

O sistema é totalmente responsivo e se adapta automaticamente a diferentes tamanhos de tela:

- **Desktop**: Modais centralizados, overlay completo
- **Tablet**: Ajuste automático de tamanhos
- **Mobile**: Modais adaptados para telas pequenas

**Classes CSS responsivas incluídas:**
```css
@media (max-width: 768px) {
    .progress-content {
        width: 95%;
        padding: 1.5rem;
    }
    
    .modal-dialog {
        margin: 1rem;
    }
}
```

---

### 🧪 Exemplos Avançados

#### Processo com Validação Condicional

```javascript
const steps = [
    { title: "Validando dados", description: "Verificando informações..." },
    { title: "Processando", description: "Aplicando regras de negócio..." },
    { title: "Finalizando", description: "Concluindo operação..." }
];

PLIProgress.start(steps, "Validação Complexa", "Processando dados");
PLIProgress.begin();

// Simular validação que pode falhar
setTimeout(() => {
    const isValid = Math.random() > 0.3; // 70% chance de sucesso
    
    if (isValid) {
        PLIProgress.nextStep(true);
        setTimeout(() => PLIProgress.nextStep(), 2000);
        setTimeout(() => PLIProgress.nextStep(), 4000);
    } else {
        PLIProgress.nextStep(false, "Dados inválidos - verifique os campos obrigatórios");
    }
}, 2000);
```

#### Modal com Múltiplas Ações

```javascript
PLIFeedback.info("Arquivo Processado", "O arquivo foi processado com sucesso. O que deseja fazer agora?", {
    buttons: [
        { 
            text: "Baixar Relatório", 
            icon: "fas fa-download", 
            onclick: "downloadReport()", 
            dismiss: true 
        },
        { 
            text: "Enviar por Email", 
            icon: "fas fa-envelope", 
            onclick: "sendEmail()", 
            dismiss: true 
        },
        { 
            text: "Visualizar", 
            icon: "fas fa-eye", 
            onclick: "viewReport()", 
            dismiss: true 
        },
        { 
            text: "Fechar", 
            icon: "fas fa-times" 
        }
    ]
});
```

---

Esta documentação cobre todos os aspectos da API do PLI Feedback System. Para exemplos práticos, consulte os arquivos na pasta `examples/`.
