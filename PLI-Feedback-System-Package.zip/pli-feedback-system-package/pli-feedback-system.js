/**
 * PLI Feedback System - Universal Installer
 * Sistema de feedback padronizado para aplicações web
 * @version 1.0.0
 * @author PLI Team
 * @license MIT
 */

(function(window, document) {
    'use strict';

    /**
     * Instalador principal do sistema PLI Feedback
     */
    class PLIFeedbackInstaller {
        constructor() {
            this.version = '1.0.0';
            this.dependencies = {
                bootstrap: {
                    css: 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css',
                    js: 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'
                },
                fontawesome: {
                    css: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'
                }
            };
            
            this.config = {
                autoInstall: true,
                includePLIColors: true,
                customColors: null,
                language: 'pt-br',
                debug: false
            };

            this.isInstalled = false;
        }

        /**
         * Instala o sistema de feedback completo
         * @param {Object} options - Opções de instalação
         */
        async install(options = {}) {
            this.config = { ...this.config, ...options };
            
            this.log('🚀 Iniciando instalação do PLI Feedback System v' + this.version);
            
            try {
                // 1. Verificar se já está instalado
                if (this.isInstalled || window.PLIFeedback) {
                    this.log('ℹ️ Sistema já instalado');
                    return true;
                }

                // 2. Instalar dependências
                await this.installDependencies();
                
                // 3. Instalar estilos
                this.installStyles();
                
                // 4. Instalar sistema JavaScript
                this.installFeedbackSystem();
                
                // 5. Criar instâncias globais
                this.createGlobalInstances();
                
                // 6. Verificar instalação
                this.verifyInstallation();
                
                this.isInstalled = true;
                this.log('✅ PLI Feedback System instalado com sucesso!');
                return true;
                
            } catch (error) {
                this.log('❌ Erro na instalação: ' + error.message, true);
                return false;
            }
        }

        /**
         * Carrega dependências externas
         */
        async installDependencies() {
            this.log('📦 Instalando dependências...');
            
            // Bootstrap CSS
            await this.loadCSS(this.dependencies.bootstrap.css, 'pli-bootstrap-css');
            
            // FontAwesome CSS
            await this.loadCSS(this.dependencies.fontawesome.css, 'pli-fontawesome-css');
            
            // Bootstrap JS
            await this.loadScript(this.dependencies.bootstrap.js, 'pli-bootstrap-js');
            
            this.log('✅ Dependências instaladas');
        }

        /**
         * Carrega um arquivo CSS
         */
        loadCSS(href, id) {
            return new Promise((resolve, reject) => {
                if (document.getElementById(id)) {
                    resolve();
                    return;
                }
                
                const link = document.createElement('link');
                link.id = id;
                link.rel = 'stylesheet';
                link.href = href;
                link.onload = resolve;
                link.onerror = () => reject(new Error('Erro ao carregar CSS: ' + href));
                document.head.appendChild(link);
            });
        }

        /**
         * Carrega um arquivo JavaScript
         */
        loadScript(src, id) {
            return new Promise((resolve, reject) => {
                if (document.getElementById(id)) {
                    resolve();
                    return;
                }
                
                const script = document.createElement('script');
                script.id = id;
                script.src = src;
                script.onload = resolve;
                script.onerror = () => reject(new Error('Erro ao carregar JS: ' + src));
                document.head.appendChild(script);
            });
        }

        /**
         * Instala os estilos CSS do sistema
         */
        installStyles() {
            this.log('🎨 Instalando estilos...');
            
            if (document.getElementById('pli-feedback-styles')) {
                this.log('ℹ️ Estilos já instalados');
                return;
            }

            const colors = this.config.customColors || this.getDefaultColors();
            
            const cssRules = [
                '/* PLI Feedback System Styles */',
                '',
                '/* Modal Feedback Styles */',
                '.feedback-icon { font-size: 4rem; margin-bottom: 1rem; }',
                '.feedback-icon.success { color: ' + colors.success + '; }',
                '.feedback-icon.error { color: ' + colors.error + '; }',
                '.feedback-icon.warning { color: ' + colors.warning + '; }',
                '.feedback-icon.info { color: ' + colors.info + '; }',
                '.feedback-icon.confirmation { color: ' + colors.confirmation + '; }',
                '',
                '/* Progress Feedback Styles */',
                '.progress-step {',
                '    display: flex; align-items: center; margin: 1.5rem 0;',
                '    padding: 1rem; border-radius: 12px; transition: all 0.3s ease;',
                '    border-left: 4px solid transparent;',
                '}',
                '.progress-step.pending { background: #f8f9fa; border-left-color: #dee2e6; }',
                '.progress-step.processing {',
                '    background: rgba(255, 193, 7, 0.1); border-left-color: ' + colors.warning + ';',
                '    animation: pulse 1.5s infinite;',
                '}',
                '.progress-step.completed {',
                '    background: rgba(40, 167, 69, 0.1); border-left-color: ' + colors.success + ';',
                '}',
                '.progress-step.error {',
                '    background: rgba(220, 53, 69, 0.1); border-left-color: ' + colors.error + ';',
                '}',
                '.step-icon {',
                '    font-size: 1.5rem; margin-right: 1rem; width: 40px;',
                '    text-align: center; transition: all 0.3s ease;',
                '}',
                '.step-content { flex-grow: 1; }',
                '.step-title {',
                '    font-weight: 600; margin-bottom: 0.25rem; color: ' + colors.primary + ';',
                '}',
                '.step-description { color: #6c757d; font-size: 0.9rem; margin: 0; }',
                '',
                '@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }',
                '',
                '/* Progress Overlay */',
                '.progress-overlay {',
                '    position: fixed; top: 0; left: 0; width: 100%; height: 100%;',
                '    background: rgba(0, 0, 0, 0.5); display: flex;',
                '    justify-content: center; align-items: center; z-index: 9999;',
                '    opacity: 0; visibility: hidden; transition: all 0.3s ease;',
                '}',
                '.progress-overlay.show { opacity: 1; visibility: visible; }',
                '.progress-content {',
                '    background: white; border-radius: 16px; padding: 2rem;',
                '    max-width: 500px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);',
                '}',
                '.progress-header {',
                '    text-align: center; margin-bottom: 2rem; padding-bottom: 1rem;',
                '    border-bottom: 2px solid #e9ecef;',
                '}',
                '.progress-header h4 { color: ' + colors.primary + '; margin-bottom: 0.5rem; }',
                '.progress-header p { color: #6c757d; margin: 0; }',
                '',
                this.config.includePLIColors ? this.getPLIColorStyles() : ''
            ];

            const styleElement = document.createElement('style');
            styleElement.id = 'pli-feedback-styles';
            styleElement.textContent = cssRules.join('\n');
            document.head.appendChild(styleElement);
            
            this.log('✅ Estilos instalados');
        }

        /**
         * Retorna as cores padrão do sistema
         */
        getDefaultColors() {
            return {
                primary: '#0f203e',
                success: '#28a745',
                error: '#dc3545',
                warning: '#ffc107',
                info: '#17a2b8',
                confirmation: '#6c757d'
            };
        }

        /**
         * Retorna estilos das cores PLI
         */
        getPLIColorStyles() {
            return [
                ':root {',
                '    --pli-azul-escuro: #0f203e; --pli-azul-medio: #1e3a8a;',
                '    --pli-azul-claro: #3b82f6; --pli-cinza-escuro: #374151;',
                '    --pli-cinza-medio: #6b7280; --pli-cinza-claro: #d1d5db;',
                '}',
                '.text-pli-dark { color: var(--pli-azul-escuro) !important; }',
                '.bg-pli-dark { background-color: var(--pli-azul-escuro) !important; }',
                '.pli-card {',
                '    border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);',
                '    border: 1px solid #e5e7eb;',
                '}'
            ].join('\n');
        }

        /**
         * Instala o sistema JavaScript
         */
        installFeedbackSystem() {
            this.log('⚙️ Instalando sistema de feedback...');
            
            if (window.PLIFeedbackSystemClass) {
                this.log('ℹ️ Sistema já instalado');
                return;
            }

            // Definir classe de Modal Feedback
            window.PLIFeedbackSystemClass = class {
                constructor() {
                    this.init();
                }

                init() {
                    this.createModalStructure();
                }

                createModalStructure() {
                    if (document.getElementById('pli-feedback-modal')) return;
                    
                    const modalHTML = [
                        '<div class="modal fade" id="pli-feedback-modal" tabindex="-1" aria-hidden="true">',
                        '  <div class="modal-dialog modal-dialog-centered">',
                        '    <div class="modal-content border-0" style="border-radius: 12px;">',
                        '      <div class="modal-body text-center p-4">',
                        '        <div class="feedback-icon mb-3" id="pli-feedback-icon"></div>',
                        '        <h4 class="mb-3" id="pli-feedback-title" style="color: #0f203e;">Título</h4>',
                        '        <p class="text-muted mb-4" id="pli-feedback-message">Mensagem</p>',
                        '        <div id="pli-feedback-buttons">',
                        '          <button type="button" class="btn btn-primary btn-lg px-4" data-bs-dismiss="modal">',
                        '            <i class="fas fa-check me-2"></i>OK',
                        '          </button>',
                        '        </div>',
                        '      </div>',
                        '    </div>',
                        '  </div>',
                        '</div>'
                    ].join('');
                    
                    document.body.insertAdjacentHTML('beforeend', modalHTML);
                }

                showModal(type, title, message, options = {}) {
                    const modal = document.getElementById('pli-feedback-modal');
                    const icon = document.getElementById('pli-feedback-icon');
                    const titleElement = document.getElementById('pli-feedback-title');
                    const messageElement = document.getElementById('pli-feedback-message');
                    const buttonsContainer = document.getElementById('pli-feedback-buttons');

                    const configs = {
                        success: { icon: '<i class="fas fa-check-circle feedback-icon success"></i>', buttonClass: 'btn-success' },
                        error: { icon: '<i class="fas fa-times-circle feedback-icon error"></i>', buttonClass: 'btn-danger' },
                        warning: { icon: '<i class="fas fa-exclamation-triangle feedback-icon warning"></i>', buttonClass: 'btn-warning' },
                        info: { icon: '<i class="fas fa-info-circle feedback-icon info"></i>', buttonClass: 'btn-info' },
                        confirmation: { icon: '<i class="fas fa-question-circle feedback-icon confirmation"></i>', buttonClass: 'btn-primary' }
                    };

                    const config = configs[type] || configs.info;
                    icon.innerHTML = config.icon;
                    titleElement.textContent = title;
                    messageElement.textContent = message;

                    if (options.buttons && options.buttons.length) {
                        buttonsContainer.innerHTML = '';
                        options.buttons.forEach((button, index) => {
                            const btnClass = index === 0 ? config.buttonClass : 'btn-secondary';
                            const btnHTML = [
                                '<button type="button" class="btn ' + btnClass + ' btn-lg px-4 me-2"',
                                button.onclick ? ' onclick="' + button.onclick + '"' : '',
                                button.dismiss !== false ? ' data-bs-dismiss="modal"' : '',
                                '>',
                                button.icon ? '<i class="' + button.icon + ' me-2"></i>' : '',
                                button.text,
                                '</button>'
                            ].join('');
                            buttonsContainer.insertAdjacentHTML('beforeend', btnHTML);
                        });
                    } else {
                        buttonsContainer.innerHTML = [
                            '<button type="button" class="btn ' + config.buttonClass + ' btn-lg px-4" data-bs-dismiss="modal">',
                            '  <i class="fas fa-check me-2"></i>OK',
                            '</button>'
                        ].join('');
                    }

                    const bootstrapModal = new bootstrap.Modal(modal);
                    bootstrapModal.show();
                    return bootstrapModal;
                }

                success(title, message, options = {}) { return this.showModal('success', title, message, options); }
                error(title, message, options = {}) { return this.showModal('error', title, message, options); }
                warning(title, message, options = {}) { return this.showModal('warning', title, message, options); }
                info(title, message, options = {}) { return this.showModal('info', title, message, options); }

                confirm(title, message, onConfirm, onCancel = null) {
                    const confirmId = 'pli_confirm_' + Date.now();
                    const cancelId = 'pli_cancel_' + Date.now();
                    
                    window[confirmId] = function() {
                        onConfirm();
                        const modal = bootstrap.Modal.getInstance(document.getElementById('pli-feedback-modal'));
                        if (modal) modal.hide();
                        delete window[confirmId];
                        delete window[cancelId];
                    };
                    
                    if (onCancel) {
                        window[cancelId] = function() {
                            onCancel();
                            delete window[confirmId];
                            delete window[cancelId];
                        };
                    }
                    
                    const options = {
                        buttons: [
                            { text: 'Confirmar', icon: 'fas fa-check', onclick: confirmId + '()', dismiss: false },
                            { text: 'Cancelar', icon: 'fas fa-times', onclick: onCancel ? cancelId + '()' : '' }
                        ]
                    };
                    
                    return this.showModal('confirmation', title, message, options);
                }
            };

            // Definir classe de Progress Feedback
            window.PLIProgressFeedbackClass = class {
                constructor() {
                    this.overlay = null;
                    this.currentSteps = [];
                    this.currentStepIndex = 0;
                }

                start(steps, title = 'Processando...', subtitle = 'Aguarde enquanto processamos sua solicitação') {
                    this.currentSteps = steps;
                    this.currentStepIndex = 0;
                    this.createOverlay(title, subtitle);
                    this.showOverlay();
                }

                createOverlay(title, subtitle) {
                    if (this.overlay) this.overlay.remove();

                    let stepsHTML = '';
                    this.currentSteps.forEach((step, index) => {
                        stepsHTML += [
                            '<div class="progress-step pending" id="progress-step-' + index + '">',
                            '  <div class="step-icon"><i class="fas fa-circle"></i></div>',
                            '  <div class="step-content">',
                            '    <div class="step-title">' + step.title + '</div>',
                            '    <p class="step-description">' + step.description + '</p>',
                            '  </div>',
                            '</div>'
                        ].join('');
                    });

                    const overlayHTML = [
                        '<div class="progress-overlay" id="pli-progress-overlay">',
                        '  <div class="progress-content">',
                        '    <div class="progress-header">',
                        '      <h4><i class="fas fa-cog me-2"></i>' + title + '</h4>',
                        '      <p>' + subtitle + '</p>',
                        '    </div>',
                        '    <div class="progress-steps">' + stepsHTML + '</div>',
                        '  </div>',
                        '</div>'
                    ].join('');

                    document.body.insertAdjacentHTML('beforeend', overlayHTML);
                    this.overlay = document.getElementById('pli-progress-overlay');
                }

                showOverlay() {
                    if (this.overlay) {
                        setTimeout(() => this.overlay.classList.add('show'), 100);
                    }
                }

                hideOverlay() {
                    if (this.overlay) {
                        this.overlay.classList.remove('show');
                        const self = this;
                        setTimeout(() => {
                            if (self.overlay) {
                                self.overlay.remove();
                                self.overlay = null;
                            }
                        }, 300);
                    }
                }

                nextStep(success = true, errorMessage = null) {
                    const stepElement = document.getElementById('progress-step-' + this.currentStepIndex);
                    
                    if (stepElement) {
                        stepElement.classList.remove('pending', 'processing');
                        
                        if (success) {
                            stepElement.classList.add('completed');
                            stepElement.querySelector('.step-icon i').className = 'fas fa-check-circle text-success';
                        } else {
                            stepElement.classList.add('error');
                            stepElement.querySelector('.step-icon i').className = 'fas fa-times-circle text-danger';
                            if (errorMessage) {
                                stepElement.querySelector('.step-description').textContent = errorMessage;
                            }
                            return;
                        }
                    }

                    this.currentStepIndex++;
                    
                    if (this.currentStepIndex < this.currentSteps.length) {
                        this.processStep(this.currentStepIndex);
                    } else {
                        const self = this;
                        setTimeout(() => self.hideOverlay(), 1500);
                    }
                }

                processStep(stepIndex) {
                    const stepElement = document.getElementById('progress-step-' + stepIndex);
                    if (stepElement) {
                        stepElement.classList.remove('pending');
                        stepElement.classList.add('processing');
                        stepElement.querySelector('.step-icon i').className = 'fas fa-spinner fa-spin text-warning';
                    }
                }

                begin() {
                    if (this.currentSteps.length > 0) {
                        this.processStep(0);
                    }
                }

                reset() {
                    this.currentStepIndex = 0;
                    const self = this;
                    this.currentSteps.forEach((_, index) => {
                        const stepElement = document.getElementById('progress-step-' + index);
                        if (stepElement) {
                            stepElement.className = 'progress-step pending';
                            stepElement.querySelector('.step-icon i').className = 'fas fa-circle';
                            stepElement.querySelector('.step-description').textContent = self.currentSteps[index].description;
                        }
                    });
                }
            };

            this.log('✅ Classes JavaScript instaladas');
        }

        /**
         * Cria instâncias globais e métodos de conveniência
         */
        createGlobalInstances() {
            this.log('🌐 Criando instâncias globais...');
            
            // Instâncias principais
            window.PLIFeedback = new window.PLIFeedbackSystemClass();
            window.PLIProgress = new window.PLIProgressFeedbackClass();

            // Métodos de conveniência globais
            window.showSuccess = (title, message, options) => window.PLIFeedback.success(title, message, options);
            window.showError = (title, message, options) => window.PLIFeedback.error(title, message, options);
            window.showWarning = (title, message, options) => window.PLIFeedback.warning(title, message, options);
            window.showInfo = (title, message, options) => window.PLIFeedback.info(title, message, options);
            window.showConfirm = (title, message, onConfirm, onCancel) => window.PLIFeedback.confirm(title, message, onConfirm, onCancel);

            // Compatibilidade com showToast
            window.showToast = (message, type = 'info') => {
                const title = { success: 'Sucesso', error: 'Erro', warning: 'Aviso', info: 'Informação' }[type] || 'Informação';
                window.PLIFeedback[type === 'success' ? 'success' : type === 'error' ? 'error' : type === 'warning' ? 'warning' : 'info'](title, message);
            };

            // Funções pré-definidas para processos comuns
            window.startLoginProcess = () => {
                const steps = [
                    { title: 'Validando credenciais', description: 'Verificando usuário e senha...' },
                    { title: 'Carregando permissões', description: 'Buscando dados do usuário...' },
                    { title: 'Preparando dashboard', description: 'Configurando interface...' },
                    { title: 'Finalizando login', description: 'Redirecionando...' }
                ];
                window.PLIProgress.start(steps, 'Realizando Login', 'Aguarde enquanto validamos suas credenciais');
                window.PLIProgress.begin();
            };

            window.startCadastroProcess = () => {
                const steps = [
                    { title: 'Validando dados', description: 'Verificando informações fornecidas...' },
                    { title: 'Salvando no banco', description: 'Persistindo dados no sistema...' },
                    { title: 'Enviando notificações', description: 'Notificando usuários relevantes...' },
                    { title: 'Finalizando cadastro', description: 'Concluindo operação...' }
                ];
                window.PLIProgress.start(steps, 'Processando Cadastro', 'Aguarde enquanto criamos sua conta');
                window.PLIProgress.begin();
            };

            this.log('✅ Instâncias globais criadas');
        }

        /**
         * Verifica se a instalação foi bem-sucedida
         */
        verifyInstallation() {
            this.log('🔍 Verificando instalação...');
            
            const checks = [
                { name: 'Bootstrap CSS', check: () => document.getElementById('pli-bootstrap-css') },
                { name: 'FontAwesome CSS', check: () => document.getElementById('pli-fontawesome-css') },
                { name: 'Bootstrap JS', check: () => window.bootstrap },
                { name: 'PLI Styles', check: () => document.getElementById('pli-feedback-styles') },
                { name: 'PLI Feedback', check: () => window.PLIFeedback },
                { name: 'PLI Progress', check: () => window.PLIProgress },
                { name: 'Global Functions', check: () => window.showSuccess && window.showError },
                { name: 'Modal Structure', check: () => document.getElementById('pli-feedback-modal') }
            ];

            const results = checks.map(check => ({ name: check.name, passed: check.check() }));
            const passed = results.filter(r => r.passed).length;
            const total = results.length;

            this.log('📊 Verificação: ' + passed + '/' + total + ' checks passaram');
            
            results.forEach(result => {
                this.log((result.passed ? '✅' : '❌') + ' ' + result.name);
            });

            if (passed === total) {
                this.log('🎉 Instalação verificada com sucesso!');
            } else {
                this.log('⚠️ Alguns componentes podem não estar funcionando corretamente', true);
            }
        }

        /**
         * Log personalizado
         */
        log(message, isError = false) {
            if (this.config.debug || isError) {
                console[isError ? 'error' : 'log']('[PLI Feedback System] ' + message);
            }
        }

        /**
         * Gera exemplo de uso
         */
        generateUsageExample() {
            return [
                '// ===== EXEMPLOS DE USO DO PLI FEEDBACK SYSTEM =====',
                '',
                '// 1. MODAL FEEDBACKS (uso básico)',
                'showSuccess("Operação Concluída", "Dados salvos com sucesso!");',
                'showError("Erro na Operação", "Não foi possível conectar ao servidor.");',
                'showWarning("Atenção", "Verifique os dados antes de continuar.");',
                'showInfo("Informação", "Sistema atualizado para nova versão.");',
                '',
                '// 2. CONFIRMAÇÃO COM AÇÕES',
                'showConfirm(',
                '    "Confirmar Exclusão",',
                '    "Tem certeza que deseja excluir este item?",',
                '    function() {',
                '        console.log("Usuário confirmou");',
                '        showSuccess("Excluído", "Item removido com sucesso!");',
                '    },',
                '    function() {',
                '        console.log("Usuário cancelou");',
                '    }',
                ');',
                '',
                '// 3. PROGRESS FEEDBACK PARA LOGIN',
                'startLoginProcess();',
                'setTimeout(() => PLIProgress.nextStep(), 1000);',
                'setTimeout(() => PLIProgress.nextStep(), 2000);',
                'setTimeout(() => PLIProgress.nextStep(), 3000);',
                'setTimeout(() => PLIProgress.nextStep(), 4000);',
                '',
                '// 4. PROGRESS FEEDBACK CUSTOMIZADO',
                'const steps = [',
                '    { title: "Processando arquivo", description: "Analisando dados..." },',
                '    { title: "Validando informações", description: "Verificando integridade..." },',
                '    { title: "Salvando dados", description: "Persistindo no banco..." }',
                '];',
                '',
                'PLIProgress.start(steps, "Importação de Dados", "Processando arquivo enviado");',
                'PLIProgress.begin();',
                '',
                '// Simular progresso',
                'setTimeout(() => PLIProgress.nextStep(), 2000);',
                'setTimeout(() => PLIProgress.nextStep(), 4000);',
                'setTimeout(() => PLIProgress.nextStep(), 6000);'
            ].join('\n');
        }
    }

    // Expor o instalador globalmente
    window.PLIFeedbackInstaller = PLIFeedbackInstaller;

    // Auto-instalação se configurado
    function autoInstall() {
        if (window.PLIFeedbackInstaller && !window.PLIFeedback) {
            const installer = new PLIFeedbackInstaller();
            installer.install({
                autoInstall: true,
                includePLIColors: true,
                debug: false
            });
        }
    }

    // Aguardar DOM carregar para auto-instalação
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', autoInstall);
    } else {
        autoInstall();
    }

})(window, document);
