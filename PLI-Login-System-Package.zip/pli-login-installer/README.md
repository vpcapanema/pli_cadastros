# PLI Login System - Instalador Universal

Um instalador completo e autocontido para o Sistema Universal de Login PLI.

## 🚀 Instalação Rápida

### Windows
```bash
# 1. Execute o instalador
INSTALAR.bat

# 2. Configure suas credenciais no arquivo .env
# 3. Execute os atalhos criados:
"Configurar Banco.bat"    # Configura o banco de dados
"Iniciar PLI Login.bat"   # Inicia o servidor
```

### Linux/Mac
```bash
# 1. Torne o script executável
chmod +x instalar.sh

# 2. Execute o instalador
./instalar.sh

# 3. Configure suas credenciais no arquivo .env
# 4. Execute os scripts criados:
./configurar-banco.sh     # Configura o banco de dados
./iniciar-pli-login.sh    # Inicia o servidor
```

## 📦 O que o instalador faz

### ✅ **Verificações Automáticas:**
- Verifica se Node.js está instalado
- Verifica se npm está disponível
- Valida dependências do sistema

### 🗂️ **Estrutura Criada:**
```
pli-login-system/
├── server.js                 # Servidor principal Express
├── package.json             # Dependências e scripts
├── .env.example             # Configurações de exemplo
├── assets/                  # Arquivos do sistema PLI
│   ├── pli-login-system.js  # Sistema universal
│   ├── index.html           # Página de login
│   └── dashboard.html       # Dashboard exemplo
├── backend/                 # Backend completo
│   ├── authController.js    # Controlador de auth
│   ├── authMiddleware.js    # Middleware de proteção
│   └── authRoutes.js        # Rotas da API
├── database/               # Scripts de banco
│   └── setup.sql           # Configuração das tabelas
├── docs/                   # Documentação completa
├── examples/               # Exemplos de integração
├── scripts/                # Scripts utilitários
│   ├── initial-setup.js    # Configuração inicial
│   ├── setup-database.js   # Configuração do banco
│   └── test-system.js      # Testes do sistema
├── logs/                   # Diretório de logs
└── public/                 # Arquivos estáticos
```

### 🔧 **Configuração Automática:**
- Instala todas as dependências npm
- Gera chave JWT segura automaticamente
- Cria arquivo .env com configurações padrão
- Configura sistema de logs
- Cria servidor Express completo
- Gera scripts utilitários

### 🎯 **Atalhos Criados:**
- **INSTALAR.bat** / **instalar.sh** - Instalador principal
- **Iniciar PLI Login.bat** / **iniciar-pli-login.sh** - Inicia servidor
- **Configurar Banco.bat** / **configurar-banco.sh** - Configura banco

## ⚙️ Configuração

### 1. **Configurar Banco de Dados**

Edite o arquivo `.env` criado:
```env
# Banco de Dados
DB_HOST=localhost
DB_PORT=5432  
DB_NAME=pli_db
DB_USER=postgres
DB_PASSWORD=sua_senha_real_aqui

# JWT (já gerado automaticamente)
JWT_SECRET=chave_gerada_automaticamente

# Servidor
PORT=3000
NODE_ENV=development
```

### 2. **Configurar Banco PostgreSQL**

Execute o script de configuração:
```bash
# Windows
"Configurar Banco.bat"

# Linux/Mac  
./configurar-banco.sh

# Ou manualmente
npm run setup-db
```

### 3. **Iniciar Sistema**

```bash
# Windows
"Iniciar PLI Login.bat"

# Linux/Mac
./iniciar-pli-login.sh

# Ou manualmente
npm start
```

## 🌐 URLs do Sistema

Após a instalação, o sistema estará disponível em:

- **Página de Login:** http://localhost:3000/login
- **Dashboard:** http://localhost:3000/dashboard
- **Status da API:** http://localhost:3000/api/status
- **Documentação:** Pasta `docs/`

## 🔐 Login Padrão

```
Usuário: admin
Senha: admin123
Tipo: ADMIN
```

**⚠️ IMPORTANTE:** Altere a senha padrão imediatamente em produção!

## 📋 Scripts Disponíveis

```json
{
  "start": "node server.js",           // Inicia o servidor
  "dev": "node server.js",            // Modo desenvolvimento  
  "setup-db": "node scripts/setup-database.js",  // Configura banco
  "test": "node scripts/test-system.js"          // Testa sistema
}
```

## 🛠️ Arquivos Principais

### **server.js** - Servidor Principal
- Express.js configurado
- Middleware de autenticação
- Rotas protegidas
- Tratamento de erros
- Sistema de logs

### **scripts/initial-setup.js** - Configuração Inicial
- Cria estrutura de diretórios
- Gera chave JWT segura
- Configura variáveis de ambiente
- Prepara sistema de logs

### **scripts/setup-database.js** - Configuração do Banco
- Conecta no PostgreSQL
- Executa script SQL
- Cria tabelas necessárias
- Insere usuário padrão

### **scripts/test-system.js** - Testes
- Testa conectividade
- Valida APIs
- Verifica autenticação

## 🔒 Segurança

### **Chave JWT Automática**
O instalador gera automaticamente uma chave JWT de 512 bits segura:
```javascript
const jwtSecret = crypto.randomBytes(64).toString('hex');
```

### **Configurações de Segurança**
```env
BCRYPT_ROUNDS=12                 # Rounds do bcrypt
SESSION_MAX_AGE=28800000        # 8 horas de sessão
MAX_LOGIN_ATTEMPTS=5            # Máx tentativas de login
RATE_LIMIT_WINDOW=900000        # Janela rate limiting
RATE_LIMIT_MAX=100              # Máx requests por janela
```

## 🐛 Resolução de Problemas

### **Erro: Node.js não encontrado**
```bash
# Instale Node.js
https://nodejs.org
```

### **Erro: Conexão com banco**
```bash
# Verifique configurações no .env
# Verifique se PostgreSQL está rodando
# Teste conexão manual
```

### **Erro: Porta em uso**
```bash
# Altere a porta no .env
PORT=3001
```

### **Logs do Sistema**
```bash
# Verifique logs em:
tail -f logs/pli-login.log
```

## 📊 Monitoramento

### **Status da API**
```bash
GET http://localhost:3000/api/status
```

Resposta:
```json
{
  "sistema": "PLI Login System",
  "versao": "1.0.0", 
  "status": "ativo",
  "timestamp": "2025-01-31T...",
  "uptime": 3600
}
```

### **Teste Automático**
```bash
npm test
# ou
node scripts/test-system.js
```

## 🚀 Integração

### **Frontend Simples**
```html
<script src="/assets/pli-login-system.js"></script>
<script>
const pli = new PLILoginInstaller();
pli.install({
    baseUrl: 'http://localhost:3000',
    autoProtect: true
});
</script>
```

### **Backend Express**
```javascript
const { setupAuthRoutes } = require('./backend/authRoutes');
setupAuthRoutes(app, dbConfig);
```

## 📞 Suporte

1. **Documentação:** Pasta `docs/`
2. **Exemplos:** Pasta `examples/`
3. **Logs:** Pasta `logs/`
4. **API Reference:** `docs/API.md`

---

**PLI Login System v1.0.0** - Instalador Universal Completo

✅ **Sistema totalmente autocontido e pronto para produção!**
