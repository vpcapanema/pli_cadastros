#!/usr/bin/env python3
"""
PLI Login System - Instalador Universal Python
Instalador multiplataforma que funciona em Windows, Linux e Mac
"""

import os
import sys
import shutil
import subprocess
import json
import secrets
from pathlib import Path

class PLILoginInstaller:
    def __init__(self):
        self.version = "1.0.0"
        self.name = "PLI Login System"
        self.current_dir = Path(__file__).parent.absolute()
        
    def print_banner(self):
        print("=" * 50)
        print(f"   {self.name.upper()} - INSTALADOR UNIVERSAL")
        print(f"   Versão {self.version}")
        print("=" * 50)
        print()
        
    def check_requirements(self):
        """Verifica se Node.js e npm estão instalados"""
        print("🔍 Verificando requisitos...")
        
        # Verificar Node.js
        try:
            result = subprocess.run(['node', '--version'], 
                                  capture_output=True, text=True, check=True)
            node_version = result.stdout.strip()
            print(f"   ✅ Node.js detectado: {node_version}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("   ❌ Node.js não encontrado!")
            print("   💡 Por favor, instale Node.js: https://nodejs.org")
            return False
            
        # Verificar npm
        try:
            result = subprocess.run(['npm', '--version'], 
                                  capture_output=True, text=True, check=True)
            npm_version = result.stdout.strip()
            print(f"   ✅ npm detectado: {npm_version}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("   ❌ npm não encontrado!")
            print("   💡 Por favor, reinstale Node.js com npm incluído")
            return False
            
        return True
        
    def get_destination_dir(self):
        """Pergunta o diretório de destino"""
        print()
        dest = input("📁 Digite o diretório de destino (Enter para usar o atual): ").strip()
        
        if not dest:
            dest = os.getcwd()
            
        dest_path = Path(dest).absolute()
        print(f"   📂 Diretório de destino: {dest_path}")
        
        return dest_path
        
    def create_directory_structure(self, dest_dir):
        """Cria a estrutura de diretórios"""
        print("\n📁 Criando estrutura de diretórios...")
        
        base_dir = dest_dir / "pli-login-system"
        
        directories = [
            base_dir,
            base_dir / "backend",
            base_dir / "database", 
            base_dir / "docs",
            base_dir / "examples",
            base_dir / "scripts",
            base_dir / "public",
            base_dir / "logs",
            base_dir / "temp"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            print(f"   ✅ {directory.relative_to(dest_dir)}")
            
        return base_dir
        
    def copy_files(self, dest_dir):
        """Copia todos os arquivos do sistema"""
        print("\n📋 Copiando arquivos do sistema...")
        
        source_dirs = ['assets', 'backend', 'database', 'docs', 'examples', 'scripts']
        
        for source_dir in source_dirs:
            source_path = self.current_dir / source_dir
            dest_path = dest_dir / source_dir
            
            if source_path.exists():
                if dest_path.exists():
                    shutil.rmtree(dest_path)
                shutil.copytree(source_path, dest_path)
                print(f"   ✅ {source_dir}/")
            else:
                print(f"   ⚠️  {source_dir}/ não encontrado")
                
    def create_package_json(self, dest_dir):
        """Cria o package.json"""
        print("\n📦 Criando package.json...")
        
        package_data = {
            "name": "pli-login-system",
            "version": "1.0.0",
            "description": "Sistema Universal de Login PLI",
            "main": "server.js",
            "scripts": {
                "start": "node server.js",
                "dev": "node server.js",
                "setup-db": "node scripts/setup-database.js",
                "test": "node scripts/test-system.js"
            },
            "dependencies": {
                "express": "^4.18.2",
                "cors": "^2.8.5", 
                "pg": "^8.11.0",
                "bcrypt": "^5.1.0",
                "jsonwebtoken": "^9.0.0",
                "dotenv": "^16.0.3"
            },
            "keywords": ["login", "authentication", "pli", "jwt", "session"],
            "author": "PLI System",
            "license": "MIT"
        }
        
        package_file = dest_dir / "package.json"
        with open(package_file, 'w', encoding='utf-8') as f:
            json.dump(package_data, f, indent=2, ensure_ascii=False)
            
        print("   ✅ package.json criado")
        
    def create_env_file(self, dest_dir):
        """Cria arquivo .env com chave JWT segura"""
        print("\n⚙️  Criando arquivo de configuração...")
        
        # Gerar chave JWT segura
        jwt_secret = secrets.token_hex(64)
        
        env_content = f"""# PLI Login System - Configuração
# Configure estas variáveis antes de executar

# Banco de Dados
DB_HOST=localhost
DB_PORT=5432
DB_NAME=pli_db
DB_USER=postgres
DB_PASSWORD=sua_senha_aqui

# JWT
JWT_SECRET={jwt_secret}
JWT_EXPIRES_IN=8h

# Servidor
PORT=3000
NODE_ENV=development

# Segurança
BCRYPT_ROUNDS=12
SESSION_MAX_AGE=28800000
MAX_LOGIN_ATTEMPTS=5

# Logs
LOG_LEVEL=info
LOG_FILE=logs/pli-login.log

# Recursos
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
"""
        
        env_file = dest_dir / ".env.example"
        with open(env_file, 'w', encoding='utf-8') as f:
            f.write(env_content)
            
        print("   ✅ .env.example criado com chave JWT segura")
        
    def install_dependencies(self, dest_dir):
        """Instala dependências npm"""
        print("\n📦 Instalando dependências npm...")
        print("   ⏳ Isso pode levar alguns minutos...")
        
        try:
            os.chdir(dest_dir)
            result = subprocess.run(['npm', 'install'], 
                                  capture_output=True, text=True, check=True)
            print("   ✅ Dependências instaladas com sucesso")
            return True
        except subprocess.CalledProcessError as e:
            print(f"   ❌ Erro na instalação: {e}")
            print("   💡 Tente executar 'npm install' manualmente")
            return False
            
    def run_initial_setup(self, dest_dir):
        """Executa configuração inicial"""
        print("\n🔧 Executando configuração inicial...")
        
        try:
            os.chdir(dest_dir)
            subprocess.run(['node', 'scripts/initial-setup.js'], check=True)
            print("   ✅ Configuração inicial concluída")
            return True
        except subprocess.CalledProcessError as e:
            print(f"   ❌ Erro na configuração: {e}")
            return False
            
    def create_shortcuts(self, dest_dir):
        """Cria atalhos para execução"""
        print("\n🔗 Criando atalhos...")
        
        if os.name == 'nt':  # Windows
            # Atalho para iniciar servidor
            start_script = dest_dir.parent / "Iniciar PLI Login.bat"
            with open(start_script, 'w') as f:
                f.write(f"""@echo off
cd /d "{dest_dir}"
npm start
pause
""")
            
            # Atalho para configurar banco
            db_script = dest_dir.parent / "Configurar Banco.bat"
            with open(db_script, 'w') as f:
                f.write(f"""@echo off
cd /d "{dest_dir}"
node scripts\\setup-database.js
pause
""")
            
            print("   ✅ Atalhos .bat criados")
            
        else:  # Linux/Mac
            # Script para iniciar servidor
            start_script = dest_dir.parent / "iniciar-pli-login.sh"
            with open(start_script, 'w') as f:
                f.write(f"""#!/bin/bash
cd "{dest_dir}"
npm start
""")
            start_script.chmod(0o755)
            
            # Script para configurar banco
            db_script = dest_dir.parent / "configurar-banco.sh"
            with open(db_script, 'w') as f:
                f.write(f"""#!/bin/bash
cd "{dest_dir}"
node scripts/setup-database.js
""")
            db_script.chmod(0o755)
            
            print("   ✅ Scripts .sh criados")
            
    def print_success_message(self, dest_dir):
        """Exibe mensagem de sucesso"""
        print("\n" + "=" * 50)
        print("🎉 INSTALAÇÃO CONCLUÍDA COM SUCESSO!")
        print("=" * 50)
        print()
        print(f"📁 Arquivos instalados em: {dest_dir}")
        print()
        print("📋 PRÓXIMOS PASSOS:")
        print()
        print("1. Configure o arquivo .env com suas credenciais do banco")
        print("2. Execute o script de configuração do banco de dados")
        print("3. Inicie o servidor PLI Login System")
        print()
        
        if os.name == 'nt':  # Windows
            print("🪟 ATALHOS WINDOWS:")
            print('   • Execute "Configurar Banco.bat"')
            print('   • Execute "Iniciar PLI Login.bat"')
        else:  # Linux/Mac
            print("🐧 SCRIPTS LINUX/MAC:")
            print("   • Execute ./configurar-banco.sh")
            print("   • Execute ./iniciar-pli-login.sh")
            
        print()
        print("📚 DOCUMENTAÇÃO:")
        print("   • README.md: Guia completo de uso")
        print("   • docs/API.md: Documentação da API")
        print("   • examples/: Exemplos de integração")
        print()
        print("🔐 LOGIN PADRÃO:")
        print("   • Usuário: admin")
        print("   • Senha: admin123")
        print("   • URL: http://localhost:3000")
        print()
        print("⚠️  IMPORTANTE: Altere a senha padrão em produção!")
        print()
        
    def install(self):
        """Executa instalação completa"""
        self.print_banner()
        
        # 1. Verificar requisitos
        if not self.check_requirements():
            sys.exit(1)
            
        # 2. Obter diretório de destino
        dest_dir = self.get_destination_dir()
        
        # 3. Criar estrutura de diretórios
        install_dir = self.create_directory_structure(dest_dir)
        
        # 4. Copiar arquivos
        self.copy_files(install_dir)
        
        # 5. Criar package.json
        self.create_package_json(install_dir)
        
        # 6. Criar arquivo .env
        self.create_env_file(install_dir)
        
        # 7. Instalar dependências
        if not self.install_dependencies(install_dir):
            print("\n⚠️  Instalação das dependências falhou, mas você pode tentar manualmente")
            
        # 8. Configuração inicial
        if not self.run_initial_setup(install_dir):
            print("\n⚠️  Configuração inicial falhou, mas o sistema pode funcionar")
            
        # 9. Criar atalhos
        self.create_shortcuts(install_dir)
        
        # 10. Mensagem de sucesso
        self.print_success_message(install_dir)

def main():
    installer = PLILoginInstaller()
    
    try:
        installer.install()
    except KeyboardInterrupt:
        print("\n\n❌ Instalação cancelada pelo usuário")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Erro durante a instalação: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
