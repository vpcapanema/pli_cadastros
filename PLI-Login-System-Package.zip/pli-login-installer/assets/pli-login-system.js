/**
 * PLI Login System - Instalador Universal
 * Sistema completo de autenticação e controle de sessão
 * 
 * Características:
 * - Instalação automática de dependências
 * - Sistema de login responsivo
 * - Controle de sessão inteligente  
 * - Proteção de páginas restritas
 * - Integração com banco pli_db
 * - Suporte a múltiplos tipos de usuário
 * 
 * @version 1.0.0
 * @author PLI System
 */

(function() {
    'use strict';

    /**
     * Classe principal do instalador do sistema de login
     */
    class PLILoginInstaller {
        constructor() {
            this.version = '1.0.0';
            this.dependencies = {
                bootstrap: 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css',
                bootstrapJS: 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js',
                fontawesome: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',
                jquery: 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'
            };
            this.isInstalled = false;
        }

        /**
         * Instala o sistema completo
         */
        async install() {
            console.log('🚀 Iniciando instalação do PLI Login System...');
            
            try {
                // Verificar se já está instalado
                if (this.isInstalled) {
                    console.log('✅ PLI Login System já está instalado');
                    return true;
                }

                // 1. Instalar dependências
                await this.installDependencies();
                
                // 2. Instalar estilos CSS
                this.installStyles();
                
                // 3. Instalar sistema de autenticação
                this.installAuthSystem();
                
                // 4. Instalar guard de páginas
                this.installPageGuard();
                
                // 5. Instalar utilitários
                this.installUtilities();
                
                // 6. Verificar instalação
                const verified = this.verifyInstallation();
                
                if (verified) {
                    this.isInstalled = true;
                    console.log('✅ PLI Login System instalado com sucesso!');
                    
                    // Disparar evento de sistema pronto
                    window.dispatchEvent(new CustomEvent('pli-login-ready', {
                        detail: { version: this.version }
                    }));
                    
                    return true;
                } else {
                    throw new Error('Falha na verificação da instalação');
                }
                
            } catch (error) {
                console.error('❌ Erro na instalação do PLI Login System:', error);
                return false;
            }
        }

        /**
         * Instala dependências externas
         */
        async installDependencies() {
            const promises = [];

            // Bootstrap CSS
            if (!this.isDependencyLoaded('bootstrap', 'css')) {
                promises.push(this.loadCSS(this.dependencies.bootstrap, 'bootstrap-css'));
            }

            // FontAwesome
            if (!this.isDependencyLoaded('fontawesome', 'css')) {
                promises.push(this.loadCSS(this.dependencies.fontawesome, 'fontawesome-css'));
            }

            // jQuery
            if (!window.jQuery) {
                promises.push(this.loadJS(this.dependencies.jquery, 'jquery-js'));
            }

            // Bootstrap JS
            if (!this.isDependencyLoaded('bootstrap', 'js')) {
                promises.push(this.loadJS(this.dependencies.bootstrapJS, 'bootstrap-js'));
            }

            if (promises.length > 0) {
                console.log('📦 Carregando dependências...');
                await Promise.all(promises);
                console.log('✅ Dependências carregadas');
            }
        }

        /**
         * Verifica se uma dependência já está carregada
         */
        isDependencyLoaded(name, type) {
            if (name === 'bootstrap' && type === 'css') {
                return document.querySelector('link[href*="bootstrap"]') !== null;
            }
            if (name === 'fontawesome' && type === 'css') {
                return document.querySelector('link[href*="font-awesome"]') !== null;
            }
            if (name === 'bootstrap' && type === 'js') {
                return typeof bootstrap !== 'undefined';
            }
            return false;
        }

        /**
         * Carrega arquivo CSS
         */
        loadCSS(url, id) {
            return new Promise((resolve, reject) => {
                if (document.getElementById(id)) {
                    resolve();
                    return;
                }

                const link = document.createElement('link');
                link.id = id;
                link.rel = 'stylesheet';
                link.href = url;
                link.onload = resolve;
                link.onerror = reject;
                document.head.appendChild(link);
            });
        }

        /**
         * Carrega arquivo JavaScript
         */
        loadJS(url, id) {
            return new Promise((resolve, reject) => {
                if (document.getElementById(id)) {
                    resolve();
                    return;
                }

                const script = document.createElement('script');
                script.id = id;
                script.src = url;
                script.onload = resolve;
                script.onerror = reject;
                document.head.appendChild(script);
            });
        }

        /**
         * Instala estilos CSS customizados
         */
        installStyles() {
            if (document.getElementById('pli-login-styles')) return;

            const css = `
            <style id="pli-login-styles">
                /* PLI Login System Styles */
                :root {
                    --pli-primary: #0f203e;
                    --pli-secondary: #1e40af;
                    --pli-success: #10b981;
                    --pli-danger: #ef4444;
                    --pli-warning: #f59e0b;
                    --pli-info: #3b82f6;
                    --pli-light: #f8fafc;
                    --pli-dark: #1e293b;
                }

                /* Login Container */
                .pli-login-container {
                    min-height: 100vh;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }

                .pli-login-card {
                    background: white;
                    border-radius: 16px;
                    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
                    overflow: hidden;
                    width: 100%;
                    max-width: 450px;
                }

                .pli-login-header {
                    background: var(--pli-primary);
                    color: white;
                    padding: 2rem;
                    text-align: center;
                }

                .pli-login-header h1 {
                    margin: 0;
                    font-size: 1.8rem;
                    font-weight: 600;
                }

                .pli-login-header p {
                    margin: 0.5rem 0 0 0;
                    opacity: 0.9;
                }

                .pli-login-body {
                    padding: 2rem;
                }

                .pli-form-group {
                    margin-bottom: 1.5rem;
                }

                .pli-form-label {
                    display: block;
                    margin-bottom: 0.5rem;
                    font-weight: 500;
                    color: #374151;
                }

                .pli-form-control {
                    width: 100%;
                    padding: 12px 16px;
                    border: 2px solid #e5e7eb;
                    border-radius: 8px;
                    font-size: 16px;
                    transition: all 0.3s ease;
                    box-sizing: border-box;
                }

                .pli-form-control:focus {
                    outline: none;
                    border-color: var(--pli-primary);
                    box-shadow: 0 0 0 3px rgba(15, 32, 62, 0.1);
                }

                .pli-btn {
                    width: 100%;
                    padding: 12px;
                    border: none;
                    border-radius: 8px;
                    font-size: 16px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 8px;
                }

                .pli-btn-primary {
                    background: var(--pli-primary);
                    color: white;
                }

                .pli-btn-primary:hover {
                    background: #0a1929;
                    transform: translateY(-1px);
                    box-shadow: 0 4px 12px rgba(15, 32, 62, 0.3);
                }

                .pli-btn:disabled {
                    opacity: 0.6;
                    cursor: not-allowed;
                    transform: none;
                }

                /* Alert Styles */
                .pli-alert {
                    padding: 12px 16px;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    border-left: 4px solid;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }

                .pli-alert-success {
                    background: #d1fae5;
                    border-color: var(--pli-success);
                    color: #065f46;
                }

                .pli-alert-danger {
                    background: #fee2e2;
                    border-color: var(--pli-danger);
                    color: #991b1b;
                }

                .pli-alert-warning {
                    background: #fef3c7;
                    border-color: var(--pli-warning);
                    color: #92400e;
                }

                .pli-alert-info {
                    background: #dbeafe;
                    border-color: var(--pli-info);
                    color: #1e40af;
                }

                /* Session Indicator */
                .pli-session-indicator {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: rgba(255, 255, 255, 0.95);
                    padding: 8px 12px;
                    border-radius: 20px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                    font-size: 12px;
                    z-index: 1050;
                    display: flex;
                    align-items: center;
                    gap: 6px;
                }

                .pli-session-status {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: var(--pli-success);
                }

                .pli-session-status.inactive {
                    background: var(--pli-warning);
                }

                .pli-session-status.expired {
                    background: var(--pli-danger);
                }

                /* Loading Spinner */
                .pli-spinner {
                    width: 20px;
                    height: 20px;
                    border: 2px solid #f3f3f3;
                    border-top: 2px solid var(--pli-primary);
                    border-radius: 50%;
                    animation: pli-spin 1s linear infinite;
                }

                @keyframes pli-spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                /* Protected Page Styles */
                .pli-protected-content {
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }

                .pli-protected-content.authorized {
                    opacity: 1;
                }

                .pli-loading-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(255, 255, 255, 0.9);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 9999;
                }

                /* Responsive */
                @media (max-width: 768px) {
                    .pli-login-container {
                        padding: 10px;
                    }
                    
                    .pli-login-header {
                        padding: 1.5rem;
                    }
                    
                    .pli-login-body {
                        padding: 1.5rem;
                    }
                }
            </style>
            `;

            document.head.insertAdjacentHTML('beforeend', css);
        }

        /**
         * Instala sistema de autenticação
         */
        installAuthSystem() {
            // Classe de autenticação
            window.PLIAuth = class PLIAuth {
                constructor() {
                    this.apiBaseUrl = '/api';
                    this.tokenKey = 'pli_token';
                    this.userKey = 'pli_user';
                    this.sessionKey = 'pli_session';
                    this.renewalThreshold = 5 * 60 * 1000; // 5 minutos
                    this.checkInterval = 60 * 1000; // 1 minuto
                    this.renewalTimer = null;
                    
                    // Inicializar sistema
                    this.init();
                }

                init() {
                    // Verificar sessão existente
                    if (this.isAuthenticated()) {
                        this.startSessionMonitoring();
                    }

                    // Event listeners
                    window.addEventListener('beforeunload', () => this.handlePageUnload());
                    window.addEventListener('pli-login-success', (e) => this.handleLoginSuccess(e.detail));
                    window.addEventListener('pli-logout', () => this.handleLogout());
                }

                /**
                 * Realiza login
                 */
                async login(credentials) {
                    try {
                        const response = await this.apiCall('/auth/login', {
                            method: 'POST',
                            body: JSON.stringify(credentials)
                        });

                        if (response.sucesso) {
                            this.setSession(response.token, response.user);
                            this.startSessionMonitoring();
                            
                            window.dispatchEvent(new CustomEvent('pli-login-success', {
                                detail: { user: response.user, token: response.token }
                            }));

                            return { success: true, user: response.user, redirect: response.redirect };
                        } else {
                            return { success: false, message: response.mensagem, logs: response.logs };
                        }
                    } catch (error) {
                        console.error('Erro no login:', error);
                        return { success: false, message: 'Erro de conexão' };
                    }
                }

                /**
                 * Realiza logout
                 */
                async logout() {
                    try {
                        await this.apiCall('/auth/logout', { method: 'POST' });
                    } catch (error) {
                        console.error('Erro no logout:', error);
                    } finally {
                        this.clearSession();
                        window.dispatchEvent(new CustomEvent('pli-logout'));
                        window.location.href = '/login.html';
                    }
                }

                /**
                 * Verifica se está autenticado
                 */
                isAuthenticated() {
                    const token = this.getToken();
                    const user = this.getUser();
                    
                    if (!token || !user) return false;
                    
                    // Verificar expiração
                    const session = this.getSession();
                    if (session && session.expiresAt) {
                        return new Date().getTime() < session.expiresAt;
                    }
                    
                    return true;
                }

                /**
                 * Obtém token
                 */
                getToken() {
                    return localStorage.getItem(this.tokenKey);
                }

                /**
                 * Obtém dados do usuário
                 */
                getUser() {
                    const userData = localStorage.getItem(this.userKey);
                    return userData ? JSON.parse(userData) : null;
                }

                /**
                 * Obtém dados da sessão
                 */
                getSession() {
                    const sessionData = localStorage.getItem(this.sessionKey);
                    return sessionData ? JSON.parse(sessionData) : null;
                }

                /**
                 * Define sessão
                 */
                setSession(token, user) {
                    const expiresAt = new Date().getTime() + (24 * 60 * 60 * 1000); // 24 horas
                    
                    localStorage.setItem(this.tokenKey, token);
                    localStorage.setItem(this.userKey, JSON.stringify(user));
                    localStorage.setItem(this.sessionKey, JSON.stringify({
                        loginTime: new Date().getTime(),
                        expiresAt,
                        lastActivity: new Date().getTime()
                    }));
                }

                /**
                 * Limpa sessão
                 */
                clearSession() {
                    localStorage.removeItem(this.tokenKey);
                    localStorage.removeItem(this.userKey);
                    localStorage.removeItem(this.sessionKey);
                    
                    if (this.renewalTimer) {
                        clearInterval(this.renewalTimer);
                        this.renewalTimer = null;
                    }
                }

                /**
                 * Atualiza atividade da sessão
                 */
                updateActivity() {
                    const session = this.getSession();
                    if (session) {
                        session.lastActivity = new Date().getTime();
                        localStorage.setItem(this.sessionKey, JSON.stringify(session));
                    }
                }

                /**
                 * Inicia monitoramento de sessão
                 */
                startSessionMonitoring() {
                    if (this.renewalTimer) return;

                    this.renewalTimer = setInterval(() => {
                        if (!this.isAuthenticated()) {
                            this.logout();
                            return;
                        }

                        const session = this.getSession();
                        if (session) {
                            const timeToExpiry = session.expiresAt - new Date().getTime();
                            const timeSinceActivity = new Date().getTime() - session.lastActivity;

                            // Renovar se próximo do vencimento e usuário ativo
                            if (timeToExpiry < this.renewalThreshold && timeSinceActivity < 2 * 60 * 1000) {
                                this.renewSession();
                            }
                        }
                    }, this.checkInterval);
                }

                /**
                 * Renova sessão
                 */
                async renewSession() {
                    try {
                        const response = await this.apiCall('/auth/renew', { method: 'POST' });
                        if (response.sucesso) {
                            const user = this.getUser();
                            this.setSession(response.token, user);
                            
                            window.dispatchEvent(new CustomEvent('pli-session-renewed', {
                                detail: { token: response.token }
                            }));
                        }
                    } catch (error) {
                        console.error('Erro ao renovar sessão:', error);
                    }
                }

                /**
                 * Chamada para API
                 */
                async apiCall(endpoint, options = {}) {
                    const url = this.apiBaseUrl + endpoint;
                    const token = this.getToken();

                    const config = {
                        headers: {
                            'Content-Type': 'application/json',
                            ...(token && { 'Authorization': `Bearer ${token}` })
                        },
                        ...options
                    };

                    const response = await fetch(url, config);
                    return await response.json();
                }

                /**
                 * Manipuladores de eventos
                 */
                handleLoginSuccess(detail) {
                    this.startSessionMonitoring();
                }

                handleLogout() {
                    this.clearSession();
                }

                handlePageUnload() {
                    // Registrar fechamento da página se necessário
                }
            };

            // Criar instância global
            window.pliAuth = new window.PLIAuth();
        }

        /**
         * Instala guard de proteção de páginas
         */
        installPageGuard() {
            window.PLIPageGuard = class PLIPageGuard {
                constructor() {
                    this.protectedPages = [
                        'dashboard.html',
                        'admin.html',
                        'profile.html',
                        'settings.html'
                    ];
                    this.publicPages = [
                        'login.html',
                        'index.html',
                        'about.html'
                    ];
                }

                /**
                 * Protege a página atual
                 */
                protect(options = {}) {
                    const currentPage = this.getCurrentPage();
                    
                    // Verificar se é página protegida
                    if (this.isProtectedPage(currentPage)) {
                        if (!window.pliAuth.isAuthenticated()) {
                            this.redirectToLogin();
                            return false;
                        }

                        // Verificar nível de acesso se especificado
                        if (options.requiredLevel) {
                            const user = window.pliAuth.getUser();
                            if (!user || user.nivel_acesso < options.requiredLevel) {
                                this.showAccessDenied();
                                return false;
                            }
                        }

                        // Verificar tipo de usuário se especificado
                        if (options.requiredTypes) {
                            const user = window.pliAuth.getUser();
                            if (!user || !options.requiredTypes.includes(user.tipo_usuario)) {
                                this.showAccessDenied();
                                return false;
                            }
                        }
                    }

                    // Mostrar conteúdo protegido
                    this.showProtectedContent();
                    return true;
                }

                /**
                 * Obtém página atual
                 */
                getCurrentPage() {
                    return window.location.pathname.split('/').pop() || 'index.html';
                }

                /**
                 * Verifica se é página protegida
                 */
                isProtectedPage(page) {
                    return this.protectedPages.some(protectedPage => 
                        page.includes(protectedPage)
                    );
                }

                /**
                 * Redireciona para login
                 */
                redirectToLogin() {
                    const currentUrl = encodeURIComponent(window.location.pathname + window.location.search);
                    window.location.href = `/login.html?next=${currentUrl}`;
                }

                /**
                 * Mostra acesso negado
                 */
                showAccessDenied() {
                    document.body.innerHTML = `
                        <div class="pli-login-container">
                            <div class="pli-login-card">
                                <div class="pli-login-header">
                                    <h1><i class="fas fa-ban"></i> Acesso Negado</h1>
                                    <p>Você não tem permissão para acessar esta página</p>
                                </div>
                                <div class="pli-login-body">
                                    <button class="pli-btn pli-btn-primary" onclick="history.back()">
                                        <i class="fas fa-arrow-left"></i> Voltar
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }

                /**
                 * Mostra conteúdo protegido
                 */
                showProtectedContent() {
                    const protectedElements = document.querySelectorAll('.pli-protected-content');
                    protectedElements.forEach(element => {
                        element.classList.add('authorized');
                    });

                    // Remover overlay de loading se existir
                    const overlay = document.querySelector('.pli-loading-overlay');
                    if (overlay) {
                        overlay.remove();
                    }
                }
            };

            // Criar instância global
            window.pliPageGuard = new window.PLIPageGuard();
        }

        /**
         * Instala utilitários
         */
        installUtilities() {
            // Funções globais de utilidade
            window.pliUtils = {
                /**
                 * Mostra indicador de sessão
                 */
                showSessionIndicator() {
                    if (document.getElementById('pli-session-indicator')) return;

                    const indicator = document.createElement('div');
                    indicator.id = 'pli-session-indicator';
                    indicator.className = 'pli-session-indicator';
                    
                    const updateIndicator = () => {
                        if (window.pliAuth.isAuthenticated()) {
                            const user = window.pliAuth.getUser();
                            indicator.innerHTML = `
                                <span class="pli-session-status"></span>
                                <span>${user ? user.nome : 'Usuário'}</span>
                            `;
                        } else {
                            indicator.innerHTML = `
                                <span class="pli-session-status expired"></span>
                                <span>Desconectado</span>
                            `;
                        }
                    };

                    updateIndicator();
                    document.body.appendChild(indicator);

                    // Atualizar a cada minuto
                    setInterval(updateIndicator, 60000);
                },

                /**
                 * Mostra loading overlay
                 */
                showLoading(message = 'Carregando...') {
                    const overlay = document.createElement('div');
                    overlay.className = 'pli-loading-overlay';
                    overlay.innerHTML = `
                        <div style="text-align: center;">
                            <div class="pli-spinner"></div>
                            <p style="margin-top: 16px;">${message}</p>
                        </div>
                    `;
                    document.body.appendChild(overlay);
                },

                /**
                 * Esconde loading overlay
                 */
                hideLoading() {
                    const overlay = document.querySelector('.pli-loading-overlay');
                    if (overlay) {
                        overlay.remove();
                    }
                },

                /**
                 * Mostra alerta
                 */
                showAlert(type, message, container = null) {
                    const alert = document.createElement('div');
                    alert.className = `pli-alert pli-alert-${type}`;
                    
                    const icons = {
                        success: 'fas fa-check-circle',
                        danger: 'fas fa-exclamation-circle',
                        warning: 'fas fa-exclamation-triangle',
                        info: 'fas fa-info-circle'
                    };

                    alert.innerHTML = `
                        <i class="${icons[type] || icons.info}"></i>
                        <span>${message}</span>
                    `;

                    const target = container || document.querySelector('.pli-login-body') || document.body;
                    target.insertBefore(alert, target.firstChild);

                    // Auto remover após 5 segundos
                    setTimeout(() => {
                        if (alert.parentNode) {
                            alert.remove();
                        }
                    }, 5000);
                },

                /**
                 * Formata data
                 */
                formatDate(date, format = 'dd/mm/yyyy hh:mm') {
                    const d = new Date(date);
                    const day = String(d.getDate()).padStart(2, '0');
                    const month = String(d.getMonth() + 1).padStart(2, '0');
                    const year = d.getFullYear();
                    const hours = String(d.getHours()).padStart(2, '0');
                    const minutes = String(d.getMinutes()).padStart(2, '0');

                    return format
                        .replace('dd', day)
                        .replace('mm', month)
                        .replace('yyyy', year)
                        .replace('hh', hours)
                        .replace('mm', minutes);
                },

                /**
                 * Valida campos obrigatórios
                 */
                validateRequired(formSelector) {
                    const form = document.querySelector(formSelector);
                    if (!form) return false;

                    const requiredFields = form.querySelectorAll('[required]');
                    let isValid = true;

                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            field.style.borderColor = 'var(--pli-danger)';
                            isValid = false;
                        } else {
                            field.style.borderColor = '';
                        }
                    });

                    return isValid;
                }
            };

            // Funções globais para compatibilidade
            window.showLoginAlert = window.pliUtils.showAlert;
            window.showLoading = window.pliUtils.showLoading;
            window.hideLoading = window.pliUtils.hideLoading;
        }

        /**
         * Verifica se a instalação foi bem-sucedida
         */
        verifyInstallation() {
            try {
                // Verificar se as classes principais foram criadas
                const hasAuth = typeof window.PLIAuth === 'function';
                const hasPageGuard = typeof window.PLIPageGuard === 'function';
                const hasUtils = typeof window.pliUtils === 'object';
                
                // Verificar se as instâncias globais existem
                const hasAuthInstance = window.pliAuth instanceof window.PLIAuth;
                const hasPageGuardInstance = window.pliPageGuard instanceof window.PLIPageGuard;
                
                // Verificar se os estilos foram aplicados
                const hasStyles = document.getElementById('pli-login-styles') !== null;
                
                console.log('🔍 Verificação da instalação:', {
                    hasAuth,
                    hasPageGuard,
                    hasUtils,
                    hasAuthInstance,
                    hasPageGuardInstance,
                    hasStyles
                });
                
                return hasAuth && hasPageGuard && hasUtils && hasAuthInstance && hasPageGuardInstance && hasStyles;
                
            } catch (error) {
                console.error('Erro na verificação:', error);
                return false;
            }
        }
    }

    // Auto-instalação quando o script é carregado
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', async () => {
            const installer = new PLILoginInstaller();
            await installer.install();
        });
    } else {
        // DOM já carregado
        setTimeout(async () => {
            const installer = new PLILoginInstaller();
            await installer.install();
        }, 100);
    }

    // Exportar para acesso global
    window.PLILoginInstaller = PLILoginInstaller;

})();
