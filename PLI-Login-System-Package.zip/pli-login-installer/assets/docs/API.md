# API Reference - PLI Login System

Documentação completa da API de autenticação do sistema PLI.

## 🔗 Base URL

```
https://sua-api.com/api/auth
```

## 🔐 Autenticação

A API utiliza tokens JWT (JSON Web Token) para autenticação. Após o login bem-sucedido, inclua o token no header `Authorization`:

```
Authorization: Bearer {seu-token-jwt}
```

## 📝 Endpoints

### Autenticação Básica

#### POST /login

Realiza login no sistema.

**Parâmetros:**
```json
{
    "username": "string (obrigatório)",
    "password": "string (obrigatório)", 
    "userType": "string (opcional)" // ADMIN, GESTOR, ANALISTA, OPERADOR, VISUALIZADOR
}
```

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "mensagem": "Login realizado com sucesso",
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "usuario": {
        "id": 123,
        "username": "usuario",
        "email": "usuario@exemplo.com",
        "nome": "Nome do Usuário",
        "tipo_usuario": "ADMIN",
        "nivel_acesso": 5
    },
    "sessao": {
        "id": "uuid",
        "data_expiracao": "2024-01-01T12:00:00Z",
        "endereco_ip": "192.168.1.1"
    }
}
```

**Resposta de Erro (401):**
```json
{
    "sucesso": false,
    "mensagem": "Credenciais inválidas",
    "codigo": "CREDENCIAIS_INVALIDAS"
}
```

#### POST /logout

Realiza logout e invalida o token atual.

**Headers:**
```
Authorization: Bearer {token}
```

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "mensagem": "Logout realizado com sucesso"
}
```

#### POST /verify

Verifica se um token é válido.

**Parâmetros:**
```json
{
    "token": "string (obrigatório)"
}
```

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "valido": true,
    "usuario": {
        "id": 123,
        "username": "usuario",
        "email": "usuario@exemplo.com",
        "tipo_usuario": "ADMIN"
    },
    "sessao": {
        "data_expiracao": "2024-01-01T12:00:00Z",
        "tempo_restante": 3600
    }
}
```

#### POST /renew

Renova uma sessão ativa (requer autenticação).

**Headers:**
```
Authorization: Bearer {token}
```

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "mensagem": "Sessão renovada com sucesso",
    "nova_expiracao": "2024-01-01T12:00:00Z",
    "renovacoes_restantes": 3
}
```

### Perfil do Usuário

#### GET /profile

Obtém informações do perfil do usuário logado.

**Headers:**
```
Authorization: Bearer {token}
```

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "usuario": {
        "id": 123,
        "username": "usuario",
        "email": "usuario@exemplo.com",
        "nome": "Nome Completo",
        "tipo_usuario": "ADMIN",
        "nivel_acesso": 5,
        "ativo": true,
        "data_criacao": "2024-01-01T00:00:00Z",
        "ultimo_login": "2024-01-01T10:00:00Z"
    },
    "sessao": {
        "id": 456,
        "data_login": "2024-01-01T10:00:00Z",
        "ultimo_acesso": "2024-01-01T11:00:00Z",
        "endereco_ip": "192.168.1.1"
    }
}
```

### Gerenciamento de Sessões

#### GET /sessions

Lista todas as sessões ativas do usuário.

**Headers:**
```
Authorization: Bearer {token}
```

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "sessoes": [
        {
            "id": 456,
            "session_id": "uuid",
            "data_login": "2024-01-01T10:00:00Z",
            "ultimo_acesso": "2024-01-01T11:00:00Z",
            "endereco_ip": "192.168.1.1",
            "user_agent": "Mozilla/5.0...",
            "origem": "https://app.exemplo.com",
            "sessao_atual": true
        }
    ],
    "total": 1
}
```

#### DELETE /sessions/{sessionId}

Encerra uma sessão específica.

**Headers:**
```
Authorization: Bearer {token}
```

**Parâmetros de URL:**
- `sessionId`: ID da sessão a ser encerrada

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "mensagem": "Sessão encerrada com sucesso"
}
```

### Administração (Requer permissão de ADMIN)

#### GET /admin/users

Lista usuários do sistema.

**Headers:**
```
Authorization: Bearer {token}
```

**Query Parameters:**
- `page`: Página (padrão: 1)
- `limit`: Itens por página (padrão: 20)
- `search`: Termo de busca
- `type`: Filtrar por tipo de usuário

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "usuarios": [
        {
            "id": 123,
            "username": "usuario",
            "email": "usuario@exemplo.com",
            "nome_completo": "Nome Completo",
            "tipo_usuario": "ADMIN",
            "nivel_acesso": 5,
            "ativo": true,
            "data_criacao": "2024-01-01T00:00:00Z",
            "ultimo_login": "2024-01-01T10:00:00Z",
            "sessoes_ativas": 2
        }
    ],
    "pagination": {
        "total": 50,
        "page": 1,
        "limit": 20,
        "pages": 3
    }
}
```

#### POST /admin/users/{userId}/toggle

Ativa ou desativa um usuário.

**Headers:**
```
Authorization: Bearer {token}
```

**Parâmetros de URL:**
- `userId`: ID do usuário

**Resposta de Sucesso (200):**
```json
{
    "sucesso": true,
    "mensagem": "Usuário ativado com sucesso",
    "usuario": {
        "id": 123,
        "username": "usuario",
        "ativo": true
    }
}
```

## 🚨 Códigos de Erro

### Códigos de Autenticação

| Código | Mensagem | Descrição |
|--------|----------|-----------|
| `TOKEN_AUSENTE` | Token de acesso não fornecido | Header Authorization não enviado |
| `TOKEN_INVALIDO` | Token inválido | Token malformado ou corrompido |
| `TOKEN_EXPIRADO` | Token expirado | Token válido mas expirado |
| `SESSAO_INVALIDA` | Sessão inválida ou expirada | Sessão não encontrada no banco |
| `CREDENCIAIS_INVALIDAS` | Credenciais inválidas | Username/senha incorretos |
| `USUARIO_INATIVO` | Usuário inativo | Conta desativada |
| `USUARIO_BLOQUEADO` | Usuário temporariamente bloqueado | Muitas tentativas de login |

### Códigos de Autorização

| Código | Mensagem | Descrição |
|--------|----------|-----------|
| `NAO_AUTENTICADO` | Usuário não autenticado | Token não fornecido |
| `TIPO_NAO_AUTORIZADO` | Tipo de usuário não autorizado | Tipo insuficiente para a operação |
| `NIVEL_INSUFICIENTE` | Nível de acesso insuficiente | Nível de acesso baixo |
| `ACESSO_WEB_APENAS` | Acesso permitido apenas via navegador | User-Agent não é de navegador |

### Códigos de Validação

| Código | Mensagem | Descrição |
|--------|----------|-----------|
| `DADOS_OBRIGATORIOS` | Campos obrigatórios não fornecidos | Parâmetros ausentes |
| `FORMATO_INVALIDO` | Formato de dados inválido | Dados mal formatados |
| `SESSAO_NAO_ENCONTRADA` | Sessão não encontrada | ID de sessão inexistente |
| `USUARIO_NAO_ENCONTRADO` | Usuário não encontrado | ID de usuário inexistente |

## 📊 Rate Limiting

Para proteger a API contra abuso, as seguintes limitações são aplicadas:

| Endpoint | Limite | Janela |
|----------|--------|--------|
| `/login` | 5 tentativas | 15 minutos |
| `/verify` | 100 requests | 1 minuto |
| `/renew` | 10 requests | 5 minutos |
| Outros | 60 requests | 1 minuto |

**Resposta quando limite excedido (429):**
```json
{
    "sucesso": false,
    "mensagem": "Muitas tentativas. Tente novamente em alguns minutos.",
    "codigo": "RATE_LIMIT_EXCEDIDO",
    "retry_after": 900
}
```

## 🔒 Configuração de Segurança

### Headers de Segurança

A API retorna os seguintes headers de segurança:

```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
Content-Security-Policy: default-src 'self'
```

### Configuração JWT

```javascript
// Configuração recomendada
const jwtConfig = {
    secret: process.env.JWT_SECRET, // Chave forte e única
    expiresIn: '8h', // Expiração do token
    algorithm: 'HS256',
    issuer: 'pli-login-system',
    audience: 'pli-app'
};
```

## 🔧 Configuração do Cliente

### JavaScript (Frontend)

```javascript
class PLIApiClient {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
        this.token = localStorage.getItem('pli_token');
    }

    async login(username, password, userType = 'ADMIN') {
        const response = await fetch(`${this.baseUrl}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password, userType })
        });

        const data = await response.json();
        
        if (data.sucesso) {
            this.token = data.token;
            localStorage.setItem('pli_token', data.token);
        }
        
        return data;
    }

    async apiCall(endpoint, options = {}) {
        const url = `${this.baseUrl}/auth${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.token}`,
                ...options.headers
            },
            ...options
        };

        const response = await fetch(url, config);
        
        if (response.status === 401) {
            // Token expirado ou inválido
            localStorage.removeItem('pli_token');
            window.location.href = '/login.html';
            return;
        }
        
        return response.json();
    }

    async getProfile() {
        return this.apiCall('/profile');
    }

    async getSessions() {
        return this.apiCall('/sessions');
    }

    async renewSession() {
        return this.apiCall('/renew', { method: 'POST' });
    }

    async logout() {
        const result = await this.apiCall('/logout', { method: 'POST' });
        localStorage.removeItem('pli_token');
        return result;
    }
}

// Uso
const api = new PLIApiClient('https://sua-api.com/api');

// Login
api.login('usuario', 'senha').then(result => {
    if (result.sucesso) {
        console.log('Login realizado:', result.usuario);
    }
});

// Verificar perfil
api.getProfile().then(profile => {
    console.log('Perfil:', profile.usuario);
});
```

### Node.js (Backend)

```javascript
const axios = require('axios');

class PLIApiClient {
    constructor(baseUrl, token = null) {
        this.baseUrl = baseUrl;
        this.token = token;
        this.client = axios.create({
            baseURL: `${baseUrl}/auth`,
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // Interceptor para adicionar token automaticamente
        this.client.interceptors.request.use(config => {
            if (this.token) {
                config.headers.Authorization = `Bearer ${this.token}`;
            }
            return config;
        });

        // Interceptor para tratar erros
        this.client.interceptors.response.use(
            response => response.data,
            error => {
                if (error.response?.status === 401) {
                    this.token = null;
                }
                throw error;
            }
        );
    }

    async login(username, password, userType = 'ADMIN') {
        const response = await this.client.post('/login', {
            username, password, userType
        });
        
        if (response.sucesso) {
            this.token = response.token;
        }
        
        return response;
    }

    async verify(token) {
        return this.client.post('/verify', { token });
    }

    async getUsers(params = {}) {
        return this.client.get('/admin/users', { params });
    }
}

// Uso
const api = new PLIApiClient('https://sua-api.com/api');

// Login e usar API
api.login('admin', 'senha').then(async result => {
    if (result.sucesso) {
        const users = await api.getUsers({ page: 1, limit: 10 });
        console.log('Usuários:', users);
    }
});
```

## 🧪 Testes

### Exemplo de Teste com Jest

```javascript
const request = require('supertest');
const app = require('../app'); // Sua aplicação Express

describe('PLI Auth API', () => {
    let authToken;

    beforeAll(async () => {
        // Fazer login para obter token
        const response = await request(app)
            .post('/api/auth/login')
            .send({
                username: 'admin',
                password: 'admin123'
            });
        
        authToken = response.body.token;
    });

    test('POST /api/auth/login - sucesso', async () => {
        const response = await request(app)
            .post('/api/auth/login')
            .send({
                username: 'admin',
                password: 'admin123'
            });

        expect(response.status).toBe(200);
        expect(response.body.sucesso).toBe(true);
        expect(response.body.token).toBeDefined();
    });

    test('POST /api/auth/login - credenciais inválidas', async () => {
        const response = await request(app)
            .post('/api/auth/login')
            .send({
                username: 'admin',
                password: 'senha_errada'
            });

        expect(response.status).toBe(401);
        expect(response.body.sucesso).toBe(false);
        expect(response.body.codigo).toBe('CREDENCIAIS_INVALIDAS');
    });

    test('GET /api/auth/profile - com token válido', async () => {
        const response = await request(app)
            .get('/api/auth/profile')
            .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.body.sucesso).toBe(true);
        expect(response.body.usuario).toBeDefined();
    });

    test('GET /api/auth/profile - sem token', async () => {
        const response = await request(app)
            .get('/api/auth/profile');

        expect(response.status).toBe(401);
        expect(response.body.codigo).toBe('TOKEN_AUSENTE');
    });
});
```

## 📋 Changelog

### v1.0.0
- Implementação inicial da API
- Sistema de autenticação JWT
- Controle de sessões
- Endpoints administrativos
- Documentação completa

---

Para mais informações, consulte o [README.md](README.md) principal ou entre em contato com a equipe de desenvolvimento.
