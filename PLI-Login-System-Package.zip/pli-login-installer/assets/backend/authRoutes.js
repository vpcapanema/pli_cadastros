/**
 * PLI Login System - Express Routes
 * Rotas para autenticação e gerenciamento de sessões
 */

const express = require('express');
const authController = require('./authController');
const PLIAuthMiddleware = require('./authMiddleware');

/**
 * Configurar rotas de autenticação
 */
function setupAuthRoutes(app, dbConfig) {
    const controller = new authController(dbConfig);
    const middleware = new PLIAuthMiddleware(dbConfig);

    // Rotas públicas (sem autenticação)
    
    /**
     * POST /api/auth/login
     * Realizar login no sistema
     */
    app.post('/api/auth/login', async (req, res) => {
        try {
            const { username, password, userType = 'ADMIN' } = req.body;

            // Validar entrada
            if (!username || !password) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Username e senha são obrigatórios',
                    codigo: 'DADOS_OBRIGATORIOS'
                });
            }

            // Obter informações da requisição
            const requestInfo = {
                endereco_ip: req.ip || req.connection.remoteAddress || 'unknown',
                user_agent: req.headers['user-agent'] || 'unknown',
                origem: req.headers.origin || req.headers.referer || 'direct'
            };

            // Tentar fazer login
            const resultado = await controller.login(username, password, userType, requestInfo);

            res.json(resultado);

        } catch (error) {
            console.error('[AUTH ROUTES] Erro no login:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    /**
     * POST /api/auth/logout
     * Realizar logout do sistema
     */
    app.post('/api/auth/logout', async (req, res) => {
        try {
            const authHeader = req.headers.authorization;
            
            if (!authHeader || !authHeader.startsWith('Bearer ')) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Token não fornecido',
                    codigo: 'TOKEN_AUSENTE'
                });
            }

            const token = authHeader.split(' ')[1];

            // Realizar logout
            const resultado = await controller.logout(token);

            res.json(resultado);

        } catch (error) {
            console.error('[AUTH ROUTES] Erro no logout:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    /**
     * POST /api/auth/verify
     * Verificar validade do token
     */
    app.post('/api/auth/verify', async (req, res) => {
        try {
            const { token } = req.body;

            if (!token) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Token é obrigatório',
                    codigo: 'TOKEN_AUSENTE'
                });
            }

            // Verificar token
            const resultado = await controller.verify(token);

            res.json(resultado);

        } catch (error) {
            console.error('[AUTH ROUTES] Erro na verificação:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    // Rotas protegidas (requerem autenticação)

    /**
     * POST /api/auth/renew
     * Renovar sessão ativa
     */
    app.post('/api/auth/renew', middleware.verifyAuth(), async (req, res) => {
        try {
            const token = req.headers.authorization.split(' ')[1];
            
            // Renovar sessão
            const resultado = await controller.renewSession(token);

            res.json(resultado);

        } catch (error) {
            console.error('[AUTH ROUTES] Erro na renovação:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    /**
     * GET /api/auth/profile
     * Obter perfil do usuário logado
     */
    app.get('/api/auth/profile', middleware.verifyAuth(), async (req, res) => {
        try {
            res.json({
                sucesso: true,
                usuario: req.user,
                sessao: {
                    id: req.session.id,
                    data_login: req.session.data_login,
                    ultimo_acesso: req.session.ultimo_acesso,
                    endereco_ip: req.session.endereco_ip
                }
            });

        } catch (error) {
            console.error('[AUTH ROUTES] Erro no perfil:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    /**
     * GET /api/auth/sessions
     * Listar sessões ativas do usuário
     */
    app.get('/api/auth/sessions', middleware.verifyAuth(), async (req, res) => {
        try {
            const userId = req.user.id;

            const query = `
                SELECT 
                    id,
                    session_id,
                    data_login,
                    ultimo_acesso,
                    endereco_ip,
                    user_agent,
                    origem,
                    CASE 
                        WHEN id = $2 THEN true 
                        ELSE false 
                    END as sessao_atual
                FROM usuarios.sessao_controle
                WHERE usuario_id = $1 
                AND status_sessao = 'ATIVA'
                AND data_expiracao > NOW()
                ORDER BY ultimo_acesso DESC
            `;

            const result = await controller.pool.query(query, [userId, req.session.id]);

            res.json({
                sucesso: true,
                sessoes: result.rows,
                total: result.rows.length
            });

        } catch (error) {
            console.error('[AUTH ROUTES] Erro nas sessões:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    /**
     * DELETE /api/auth/sessions/:sessionId
     * Encerrar sessão específica
     */
    app.delete('/api/auth/sessions/:sessionId', middleware.verifyAuth(), async (req, res) => {
        try {
            const { sessionId } = req.params;
            const userId = req.user.id;

            // Verificar se a sessão pertence ao usuário
            const checkQuery = `
                SELECT id FROM usuarios.sessao_controle
                WHERE id = $1 AND usuario_id = $2 AND status_sessao = 'ATIVA'
            `;

            const checkResult = await controller.pool.query(checkQuery, [sessionId, userId]);

            if (checkResult.rows.length === 0) {
                return res.status(404).json({
                    sucesso: false,
                    mensagem: 'Sessão não encontrada',
                    codigo: 'SESSAO_NAO_ENCONTRADA'
                });
            }

            // Encerrar sessão
            const updateQuery = `
                UPDATE usuarios.sessao_controle 
                SET status_sessao = 'ENCERRADA', 
                    data_logout = NOW(), 
                    motivo_logout = 'ENCERRADA_PELO_USUARIO'
                WHERE id = $1
            `;

            await controller.pool.query(updateQuery, [sessionId]);

            res.json({
                sucesso: true,
                mensagem: 'Sessão encerrada com sucesso'
            });

        } catch (error) {
            console.error('[AUTH ROUTES] Erro ao encerrar sessão:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    // Rotas administrativas (apenas administradores)

    /**
     * GET /api/auth/admin/users
     * Listar usuários do sistema (admin apenas)
     */
    app.get('/api/auth/admin/users', 
        middleware.verifyAuth(), 
        middleware.requireAdmin(), 
        async (req, res) => {
        try {
            const { page = 1, limit = 20, search = '', type = '' } = req.query;
            const offset = (page - 1) * limit;

            let whereClause = 'WHERE us.data_exclusao IS NULL';
            const params = [];

            if (search) {
                whereClause += ' AND (us.username ILIKE $' + (params.length + 1) + ' OR pf.nome_completo ILIKE $' + (params.length + 2) + ')';
                params.push(`%${search}%`, `%${search}%`);
            }

            if (type) {
                whereClause += ' AND us.tipo_usuario = $' + (params.length + 1);
                params.push(type);
            }

            const query = `
                SELECT 
                    us.id,
                    us.username,
                    us.email,
                    us.tipo_usuario,
                    us.nivel_acesso,
                    us.ativo,
                    us.data_criacao,
                    us.ultimo_login,
                    pf.nome_completo,
                    (
                        SELECT COUNT(*) 
                        FROM usuarios.sessao_controle sc 
                        WHERE sc.usuario_id = us.id 
                        AND sc.status_sessao = 'ATIVA'
                        AND sc.data_expiracao > NOW()
                    ) as sessoes_ativas
                FROM usuarios.usuario_sistema us
                LEFT JOIN usuarios.pessoa_fisica pf ON us.pessoa_fisica_id = pf.id
                ${whereClause}
                ORDER BY us.data_criacao DESC
                LIMIT $${params.length + 1} OFFSET $${params.length + 2}
            `;

            params.push(limit, offset);

            const result = await controller.pool.query(query, params);

            // Contar total
            const countQuery = `
                SELECT COUNT(*) as total
                FROM usuarios.usuario_sistema us
                LEFT JOIN usuarios.pessoa_fisica pf ON us.pessoa_fisica_id = pf.id
                ${whereClause}
            `;

            const countResult = await controller.pool.query(countQuery, params.slice(0, -2));

            res.json({
                sucesso: true,
                usuarios: result.rows,
                pagination: {
                    total: parseInt(countResult.rows[0].total),
                    page: parseInt(page),
                    limit: parseInt(limit),
                    pages: Math.ceil(countResult.rows[0].total / limit)
                }
            });

        } catch (error) {
            console.error('[AUTH ROUTES] Erro na listagem de usuários:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    /**
     * POST /api/auth/admin/users/:userId/toggle
     * Ativar/Desativar usuário (admin apenas)
     */
    app.post('/api/auth/admin/users/:userId/toggle', 
        middleware.verifyAuth(), 
        middleware.requireAdmin(), 
        async (req, res) => {
        try {
            const { userId } = req.params;

            // Verificar se usuário existe
            const userQuery = `
                SELECT id, ativo, username 
                FROM usuarios.usuario_sistema 
                WHERE id = $1 AND data_exclusao IS NULL
            `;

            const userResult = await controller.pool.query(userQuery, [userId]);

            if (userResult.rows.length === 0) {
                return res.status(404).json({
                    sucesso: false,
                    mensagem: 'Usuário não encontrado',
                    codigo: 'USUARIO_NAO_ENCONTRADO'
                });
            }

            const user = userResult.rows[0];
            const novoStatus = !user.ativo;

            // Atualizar status
            const updateQuery = `
                UPDATE usuarios.usuario_sistema 
                SET ativo = $1, data_alteracao = NOW()
                WHERE id = $2
            `;

            await controller.pool.query(updateQuery, [novoStatus, userId]);

            // Se desativando, encerrar todas as sessões
            if (!novoStatus) {
                const endSessionsQuery = `
                    UPDATE usuarios.sessao_controle 
                    SET status_sessao = 'ENCERRADA', 
                        data_logout = NOW(), 
                        motivo_logout = 'USUARIO_DESATIVADO'
                    WHERE usuario_id = $1 AND status_sessao = 'ATIVA'
                `;

                await controller.pool.query(endSessionsQuery, [userId]);
            }

            res.json({
                sucesso: true,
                mensagem: `Usuário ${novoStatus ? 'ativado' : 'desativado'} com sucesso`,
                usuario: {
                    id: userId,
                    username: user.username,
                    ativo: novoStatus
                }
            });

        } catch (error) {
            console.error('[AUTH ROUTES] Erro ao alterar status do usuário:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno no servidor',
                codigo: 'ERRO_INTERNO'
            });
        }
    });

    console.log('[PLI LOGIN SYSTEM] Rotas de autenticação configuradas com sucesso');
}

module.exports = { setupAuthRoutes };
