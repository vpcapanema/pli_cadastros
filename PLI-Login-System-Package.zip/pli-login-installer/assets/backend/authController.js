/**
 * PLI Login System - Backend Auth Controller
 * Controlador de autenticação compatível com banco pli_db
 * 
 * Tabelas utilizadas:
 * - usuarios.usuario_sistema (autenticação)
 * - usuarios.sessao_controle (controle de sessão)
 */

const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { Pool } = require('pg');

class PLIAuthController {
    constructor(dbConfig) {
        this.pool = new Pool(dbConfig);
        this.jwtSecret = process.env.JWT_SECRET || 'your-super-secret-jwt-key';
        this.jwtExpiresIn = process.env.JWT_EXPIRES_IN || '24h';
    }

    /**
     * Endpoint de login
     */
    async login(req, res) {
        try {
            const { usuario, password, tipo_usuario } = req.body;
            const logs = [];

            // Validação básica
            if (!usuario || !password || !tipo_usuario) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Usuário, senha e tipo de usuário são obrigatórios',
                    logs: ['Campos obrigatórios não preenchidos']
                });
            }

            logs.push(`[LOGIN] Tentativa de login para: ${usuario}, tipo: ${tipo_usuario}`);

            // Buscar usuário no banco
            const user = await this.findUser(usuario, tipo_usuario);
            
            if (!user) {
                logs.push('[LOGIN] Usuário não encontrado');
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Credenciais inválidas',
                    logs
                });
            }

            // Verificar se usuário está ativo
            if (!user.ativo) {
                logs.push('[LOGIN] Usuário inativo');
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Usuário inativo. Entre em contato com o administrador.',
                    logs
                });
            }

            // Verificar senha
            const senhaCorreta = await bcrypt.compare(password, user.senha_hash);
            if (!senhaCorreta) {
                logs.push('[LOGIN] Senha incorreta');
                await this.incrementFailedAttempts(user.id);
                
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Credenciais inválidas',
                    logs
                });
            }

            logs.push('[LOGIN] Autenticação bem-sucedida');

            // Gerar token JWT
            const token = jwt.sign({
                id: user.id,
                email: user.email,
                nome: user.nome_completo,
                tipo_usuario: user.tipo_usuario,
                nivel_acesso: user.nivel_acesso,
                username: user.username
            }, this.jwtSecret, { 
                expiresIn: this.jwtExpiresIn 
            });

            // Criar sessão no banco
            let sessionId = null;
            try {
                sessionId = await this.createSession(user.id, token, req);
                logs.push(`[LOGIN] Sessão criada: ${sessionId}`);
            } catch (sessionError) {
                console.error('[LOGIN] Erro ao criar sessão:', sessionError);
                logs.push('[LOGIN] Aviso: Sessão não foi registrada no banco');
            }

            // Atualizar último login
            await this.updateLastLogin(user.id);

            // Resetar tentativas de login falhadas
            await this.resetFailedAttempts(user.id);

            logs.push('[LOGIN] Login concluído com sucesso');

            // Resposta de sucesso
            res.status(200).json({
                sucesso: true,
                token,
                user: {
                    id: user.id,
                    nome: user.nome_completo,
                    email: user.email,
                    username: user.username,
                    tipo_usuario: user.tipo_usuario,
                    nivel_acesso: user.nivel_acesso,
                    departamento: user.departamento,
                    cargo: user.cargo
                },
                mensagem: 'Login realizado com sucesso',
                redirect: '/dashboard.html',
                sessionId,
                logs
            });

        } catch (error) {
            console.error('[LOGIN] Erro inesperado:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro interno do servidor',
                logs: [`Erro: ${error.message}`]
            });
        }
    }

    /**
     * Endpoint de logout
     */
    async logout(req, res) {
        try {
            const token = req.headers.authorization?.replace('Bearer ', '');
            
            if (token) {
                try {
                    await this.endSession(token, 'LOGOUT_MANUAL');
                } catch (sessionError) {
                    console.error('[LOGOUT] Erro ao encerrar sessão:', sessionError);
                }
            }

            res.status(200).json({
                sucesso: true,
                mensagem: 'Logout realizado com sucesso'
            });

        } catch (error) {
            console.error('[LOGOUT] Erro:', error);
            res.status(500).json({
                sucesso: false,
                mensagem: 'Erro ao processar logout'
            });
        }
    }

    /**
     * Endpoint de renovação de sessão
     */
    async renewSession(req, res) {
        try {
            const token = req.headers.authorization?.replace('Bearer ', '');
            
            if (!token) {
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Token não fornecido'
                });
            }

            // Verificar token atual
            const decoded = jwt.verify(token, this.jwtSecret);
            
            // Gerar novo token
            const newToken = jwt.sign({
                id: decoded.id,
                email: decoded.email,
                nome: decoded.nome,
                tipo_usuario: decoded.tipo_usuario,
                nivel_acesso: decoded.nivel_acesso,
                username: decoded.username
            }, this.jwtSecret, { 
                expiresIn: this.jwtExpiresIn 
            });

            // Atualizar sessão no banco
            try {
                await this.renewSessionInDB(token, newToken);
            } catch (sessionError) {
                console.error('[RENEW] Erro ao renovar sessão no banco:', sessionError);
            }

            res.status(200).json({
                sucesso: true,
                token: newToken,
                mensagem: 'Sessão renovada com sucesso'
            });

        } catch (error) {
            console.error('[RENEW] Erro:', error);
            res.status(401).json({
                sucesso: false,
                mensagem: 'Token inválido ou expirado'
            });
        }
    }

    /**
     * Endpoint de verificação de autenticação
     */
    async verify(req, res) {
        try {
            const token = req.headers.authorization?.replace('Bearer ', '');
            
            if (!token) {
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Token não fornecido'
                });
            }

            // Verificar token
            const decoded = jwt.verify(token, this.jwtSecret);
            
            // Verificar se sessão ainda é válida no banco
            const sessionValid = await this.isSessionValid(token);
            
            if (!sessionValid) {
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Sessão inválida ou expirada'
                });
            }

            // Atualizar último acesso
            await this.updateLastAccess(token);

            res.status(200).json({
                sucesso: true,
                user: {
                    id: decoded.id,
                    nome: decoded.nome,
                    email: decoded.email,
                    username: decoded.username,
                    tipo_usuario: decoded.tipo_usuario,
                    nivel_acesso: decoded.nivel_acesso
                },
                mensagem: 'Token válido'
            });

        } catch (error) {
            console.error('[VERIFY] Erro:', error);
            res.status(401).json({
                sucesso: false,
                mensagem: 'Token inválido'
            });
        }
    }

    /**
     * Buscar usuário no banco
     */
    async findUser(usuario, tipoUsuario) {
        const isEmail = usuario.includes('@');
        
        let query, params;
        
        if (isEmail) {
            query = `
                SELECT us.*, pf.nome_completo 
                FROM usuarios.usuario_sistema us
                LEFT JOIN usuarios.pessoa_fisica pf ON us.pessoa_fisica_id = pf.id
                WHERE us.email = $1 AND us.tipo_usuario = $2 AND us.data_exclusao IS NULL
            `;
            params = [usuario, tipoUsuario];
        } else {
            query = `
                SELECT us.*, pf.nome_completo 
                FROM usuarios.usuario_sistema us
                LEFT JOIN usuarios.pessoa_fisica pf ON us.pessoa_fisica_id = pf.id
                WHERE us.username = $1 AND us.tipo_usuario = $2 AND us.data_exclusao IS NULL
            `;
            params = [usuario, tipoUsuario];
        }

        const result = await this.pool.query(query, params);
        return result.rows[0] || null;
    }

    /**
     * Criar sessão no banco de dados
     */
    async createSession(userId, token, req) {
        const sessionId = require('crypto').randomUUID();
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            INSERT INTO usuarios.sessao_controle (
                id, session_id, usuario_id, token_hash, 
                endereco_ip, user_agent, dispositivo_info,
                data_login, data_expiracao, status_sessao
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            RETURNING session_id
        `;

        const params = [
            require('crypto').randomUUID(),
            sessionId,
            userId,
            tokenHash,
            req.ip || req.connection.remoteAddress,
            req.headers['user-agent'] || 'Unknown',
            this.getDeviceInfo(req.headers['user-agent'] || ''),
            new Date(),
            new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 horas
            'ATIVA'
        ];

        const result = await this.pool.query(query, params);
        return sessionId;
    }

    /**
     * Encerrar sessão
     */
    async endSession(token, reason = 'LOGOUT_MANUAL') {
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            UPDATE usuarios.sessao_controle 
            SET status_sessao = $1, data_logout = $2, motivo_logout = $3
            WHERE token_hash = $4 AND status_sessao = 'ATIVA'
        `;

        await this.pool.query(query, [reason, new Date(), reason, tokenHash]);
    }

    /**
     * Verificar se sessão é válida
     */
    async isSessionValid(token) {
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            SELECT id FROM usuarios.sessao_controle 
            WHERE token_hash = $1 AND status_sessao = 'ATIVA' AND data_expiracao > NOW()
        `;

        const result = await this.pool.query(query, [tokenHash]);
        return result.rows.length > 0;
    }

    /**
     * Atualizar último acesso
     */
    async updateLastAccess(token) {
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            UPDATE usuarios.sessao_controle 
            SET ultimo_acesso = $1
            WHERE token_hash = $2 AND status_sessao = 'ATIVA'
        `;

        await this.pool.query(query, [new Date(), tokenHash]);
    }

    /**
     * Renovar sessão no banco
     */
    async renewSessionInDB(oldToken, newToken) {
        const oldTokenHash = require('crypto').createHash('sha256').update(oldToken).digest('hex');
        const newTokenHash = require('crypto').createHash('sha256').update(newToken).digest('hex');
        
        const query = `
            UPDATE usuarios.sessao_controle 
            SET token_hash = $1, data_expiracao = $2, ultimo_acesso = $3
            WHERE token_hash = $4 AND status_sessao = 'ATIVA'
        `;

        const newExpiration = new Date(Date.now() + 24 * 60 * 60 * 1000); // +24 horas
        
        await this.pool.query(query, [newTokenHash, newExpiration, new Date(), oldTokenHash]);
    }

    /**
     * Atualizar último login
     */
    async updateLastLogin(userId) {
        const query = `
            UPDATE usuarios.usuario_sistema 
            SET data_ultimo_login = $1 
            WHERE id = $2
        `;

        await this.pool.query(query, [new Date(), userId]);
    }

    /**
     * Incrementar tentativas falhadas
     */
    async incrementFailedAttempts(userId) {
        const query = `
            UPDATE usuarios.usuario_sistema 
            SET tentativas_login = tentativas_login + 1
            WHERE id = $1
        `;

        await this.pool.query(query, [userId]);
    }

    /**
     * Resetar tentativas falhadas
     */
    async resetFailedAttempts(userId) {
        const query = `
            UPDATE usuarios.usuario_sistema 
            SET tentativas_login = 0
            WHERE id = $1
        `;

        await this.pool.query(query, [userId]);
    }

    /**
     * Obter informações do dispositivo
     */
    getDeviceInfo(userAgent) {
        const info = {
            browser: 'Unknown',
            os: 'Unknown',
            device: 'Desktop'
        };

        if (userAgent.includes('Chrome')) info.browser = 'Chrome';
        else if (userAgent.includes('Firefox')) info.browser = 'Firefox';
        else if (userAgent.includes('Safari')) info.browser = 'Safari';
        else if (userAgent.includes('Edge')) info.browser = 'Edge';

        if (userAgent.includes('Windows')) info.os = 'Windows';
        else if (userAgent.includes('Mac')) info.os = 'macOS';
        else if (userAgent.includes('Linux')) info.os = 'Linux';
        else if (userAgent.includes('Android')) info.os = 'Android';
        else if (userAgent.includes('iOS')) info.os = 'iOS';

        if (userAgent.includes('Mobile') || userAgent.includes('Android') || userAgent.includes('iPhone')) {
            info.device = 'Mobile';
        } else if (userAgent.includes('Tablet') || userAgent.includes('iPad')) {
            info.device = 'Tablet';
        }

        return JSON.stringify(info);
    }
}

module.exports = PLIAuthController;
