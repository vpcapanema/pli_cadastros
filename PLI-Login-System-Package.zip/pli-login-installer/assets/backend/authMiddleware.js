/**
 * PLI Login System - Backend Middleware
 * Middleware de autenticação para rotas protegidas
 */

const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

class PLIAuthMiddleware {
    constructor(dbConfig) {
        this.pool = new Pool(dbConfig);
        this.jwtSecret = process.env.JWT_SECRET || 'your-super-secret-jwt-key';
    }

    /**
     * Middleware principal de verificação de autenticação
     */
    verifyAuth() {
        return async (req, res, next) => {
            try {
                // Extrair token do header Authorization
                const authHeader = req.headers.authorization;
                
                if (!authHeader || !authHeader.startsWith('Bearer ')) {
                    return res.status(401).json({
                        sucesso: false,
                        mensagem: 'Token de acesso não fornecido',
                        codigo: 'TOKEN_AUSENTE'
                    });
                }

                const token = authHeader.split(' ')[1];

                // Verificar e decodificar token JWT
                const decoded = jwt.verify(token, this.jwtSecret);

                // Verificar se sessão ainda é válida no banco
                const sessionData = await this.getSessionData(token);
                
                if (!sessionData) {
                    return res.status(401).json({
                        sucesso: false,
                        mensagem: 'Sessão inválida ou expirada',
                        codigo: 'SESSAO_INVALIDA'
                    });
                }

                // Verificar se usuário ainda está ativo
                const userData = await this.getUserData(decoded.id);
                
                if (!userData || !userData.ativo) {
                    await this.endSession(token, 'USUARIO_INATIVO');
                    
                    return res.status(401).json({
                        sucesso: false,
                        mensagem: 'Usuário inativo',
                        codigo: 'USUARIO_INATIVO'
                    });
                }

                // Atualizar último acesso
                await this.updateLastAccess(token);

                // Adicionar dados do usuário e sessão à requisição
                req.user = {
                    id: decoded.id,
                    email: decoded.email,
                    nome: decoded.nome,
                    username: decoded.username,
                    tipo_usuario: decoded.tipo_usuario,
                    nivel_acesso: decoded.nivel_acesso
                };

                req.session = {
                    id: sessionData.id,
                    session_id: sessionData.session_id,
                    data_login: sessionData.data_login,
                    ultimo_acesso: sessionData.ultimo_acesso,
                    endereco_ip: sessionData.endereco_ip
                };

                next();

            } catch (error) {
                if (error.name === 'JsonWebTokenError') {
                    return res.status(401).json({
                        sucesso: false,
                        mensagem: 'Token inválido',
                        codigo: 'TOKEN_INVALIDO'
                    });
                } else if (error.name === 'TokenExpiredError') {
                    return res.status(401).json({
                        sucesso: false,
                        mensagem: 'Token expirado',
                        codigo: 'TOKEN_EXPIRADO'
                    });
                } else {
                    console.error('[AUTH MIDDLEWARE] Erro:', error);
                    return res.status(500).json({
                        sucesso: false,
                        mensagem: 'Erro interno de autenticação',
                        codigo: 'ERRO_INTERNO'
                    });
                }
            }
        };
    }

    /**
     * Middleware para verificar tipo específico de usuário
     */
    requireUserType(allowedTypes) {
        return (req, res, next) => {
            if (!req.user) {
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Usuário não autenticado',
                    codigo: 'NAO_AUTENTICADO'
                });
            }

            const userType = req.user.tipo_usuario;
            const types = Array.isArray(allowedTypes) ? allowedTypes : [allowedTypes];

            if (!types.includes(userType)) {
                return res.status(403).json({
                    sucesso: false,
                    mensagem: 'Acesso negado. Tipo de usuário não autorizado.',
                    codigo: 'TIPO_NAO_AUTORIZADO',
                    requerido: types,
                    atual: userType
                });
            }

            next();
        };
    }

    /**
     * Middleware para verificar nível mínimo de acesso
     */
    requireAccessLevel(minLevel) {
        return (req, res, next) => {
            if (!req.user) {
                return res.status(401).json({
                    sucesso: false,
                    mensagem: 'Usuário não autenticado',
                    codigo: 'NAO_AUTENTICADO'
                });
            }

            const userLevel = req.user.nivel_acesso || 1;

            if (userLevel < minLevel) {
                return res.status(403).json({
                    sucesso: false,
                    mensagem: 'Acesso negado. Nível de acesso insuficiente.',
                    codigo: 'NIVEL_INSUFICIENTE',
                    requerido: minLevel,
                    atual: userLevel
                });
            }

            next();
        };
    }

    /**
     * Middleware para administradores apenas
     */
    requireAdmin() {
        return this.requireUserType('ADMIN');
    }

    /**
     * Middleware para gestores e administradores
     */
    requireManager() {
        return this.requireUserType(['ADMIN', 'GESTOR']);
    }

    /**
     * Middleware para analistas, gestores e administradores
     */
    requireAnalyst() {
        return this.requireUserType(['ADMIN', 'GESTOR', 'ANALISTA']);
    }

    /**
     * Middleware para operadores e superiores
     */
    requireOperator() {
        return this.requireUserType(['ADMIN', 'GESTOR', 'ANALISTA', 'OPERADOR']);
    }

    /**
     * Middleware para todos os tipos de usuário (exceto visualizador em operações críticas)
     */
    requireActiveUser() {
        return this.requireUserType(['ADMIN', 'GESTOR', 'ANALISTA', 'OPERADOR']);
    }

    /**
     * Middleware para qualquer usuário autenticado (incluindo visualizadores)
     */
    requireAnyUser() {
        return this.requireUserType(['ADMIN', 'GESTOR', 'ANALISTA', 'OPERADOR', 'VISUALIZADOR']);
    }

    /**
     * Middleware para verificar se é sessão web (não API)
     */
    requireWebSession() {
        return (req, res, next) => {
            const userAgent = req.headers['user-agent'] || '';
            
            // Verificar se tem user agent de navegador
            const isBrowser = userAgent.includes('Mozilla') || 
                            userAgent.includes('Chrome') || 
                            userAgent.includes('Safari') || 
                            userAgent.includes('Firefox') || 
                            userAgent.includes('Edge');

            if (!isBrowser) {
                return res.status(403).json({
                    sucesso: false,
                    mensagem: 'Acesso permitido apenas via navegador web',
                    codigo: 'ACESSO_WEB_APENAS'
                });
            }

            next();
        };
    }

    /**
     * Obter dados da sessão
     */
    async getSessionData(token) {
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            SELECT sc.*, us.ativo as usuario_ativo
            FROM usuarios.sessao_controle sc
            JOIN usuarios.usuario_sistema us ON sc.usuario_id = us.id
            WHERE sc.token_hash = $1 
            AND sc.status_sessao = 'ATIVA' 
            AND sc.data_expiracao > NOW()
            AND us.data_exclusao IS NULL
        `;

        const result = await this.pool.query(query, [tokenHash]);
        return result.rows[0] || null;
    }

    /**
     * Obter dados do usuário
     */
    async getUserData(userId) {
        const query = `
            SELECT us.*, pf.nome_completo
            FROM usuarios.usuario_sistema us
            LEFT JOIN usuarios.pessoa_fisica pf ON us.pessoa_fisica_id = pf.id
            WHERE us.id = $1 AND us.data_exclusao IS NULL
        `;

        const result = await this.pool.query(query, [userId]);
        return result.rows[0] || null;
    }

    /**
     * Atualizar último acesso
     */
    async updateLastAccess(token) {
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            UPDATE usuarios.sessao_controle 
            SET ultimo_acesso = NOW()
            WHERE token_hash = $1 AND status_sessao = 'ATIVA'
        `;

        await this.pool.query(query, [tokenHash]);
    }

    /**
     * Encerrar sessão
     */
    async endSession(token, reason = 'ENCERRADA') {
        const tokenHash = require('crypto').createHash('sha256').update(token).digest('hex');
        
        const query = `
            UPDATE usuarios.sessao_controle 
            SET status_sessao = $1, data_logout = NOW(), motivo_logout = $2
            WHERE token_hash = $3 AND status_sessao = 'ATIVA'
        `;

        await this.pool.query(query, [reason, reason, tokenHash]);
    }
}

module.exports = PLIAuthMiddleware;
